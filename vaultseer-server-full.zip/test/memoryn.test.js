'use strict';
const crypto = require('crypto');
const M = require('../src/m_memory.js');
const A = require('../src/adapters.js');
const makeCore = require('../src/core');
let fails = 0; const ok = (c, m, x) => { if (!c) { fails++; if (fails < 40) console.log('FAIL', m, x === undefined ? '' : JSON.stringify(x)); } };
const S = 'abcdefghi';
(async () => {
  let t = 1000000; const core = makeCore({ now: () => t, sign: async (id, o) => 'sig:' + id + ':' + o });
  for (let n = 2; n <= 9; n++) for (let g = 0; g < 12; g++) {
    const id = 'm' + n + '_' + g, P = Array.from({ length: n }, (_, i) => '0x' + (i + 1).toString(16).padStart(2, '0').repeat(20));
    core.start(id, 'memory', P); const m = core.get(id);
    ok(core.view(id, P[0]).legal.length === 1 && core.view(id, P[0]).state.seq === null, 'ready phase: one move, no digits yet');
    for (let i = 0; i < n; i++) { const r = await core.move(id, P[i], { t: 'ready' }); ok(r.ok, 'ready ok', r); }
    ok(m.st.phase === 'play' && m.st.round === 1 && m.st.len === 5, 'round 1 has 5 digits');
    let rounds = 0;
    while (!m.over && rounds < 12) {
      const st = m.st, round = st.round, v0 = core.view(id, P[0]).state;
      ok(Array.isArray(v0.seq) && v0.seq.length === st.len, 'the row is visible at the start of the round');
      // typing during the show is refused
      const early = await core.move(id, P[0], { t: 'answer', digits: '1' }); ok(!early.ok, 'cannot type while the row is showing');
      t = st.showUntil + 600;
      ok(core.view(id, P[0]).state.seq === null, 'the row is no longer sent after it disappears');
      // everybody answers; players differ in accuracy
      for (let i = 0; i < n; i++) {
        let d = st.seq.slice(); const miss = i % 3 === 0 ? 0 : i % 3 === 1 ? 1 : 2;
        for (let k = 0; k < miss; k++) d[k] = (d[k] + 1) % 10;
        if (Math.random() < 0.1) d = d.slice(0, 3);
        const r = await core.move(id, P[i], { t: 'answer', digits: d.join('') }); ok(r.ok, 'answer accepted', r);
        const again = await core.move(id, P[i], { t: 'answer', digits: '1' }); if (!m.over && m.st.round === round) ok(!again.ok, 'second answer refused');
      }
      rounds++;
      if (!m.over) { ok(m.st.round === round + 1, 'next round starts'); ok(m.st.startAt >= t + 5000, 'a pause before the next row'); t += 100; }
    }
    ok(m.over && m.sig, 'memory match finished and signed', { n, rounds });
    ok(rounds >= 3 && rounds <= 8, 'between 3 and 8 rounds', rounds);
    const tot = m.st.totals, top = Math.max(...tot); ok(S.slice(0, n).split('').every((s, i) => ((m.outcome >> i) & 1) === (tot[i] === top ? 1 : 0)), 'winners = the players with the top total', { tot, o: m.outcome });
  }
  // all identical answers -> tie -> 5 extra rounds -> everyone shares (draw mask)
  { const P = ['0x' + 'a'.repeat(40), '0x' + 'b'.repeat(40), '0x' + 'c'.repeat(40)]; core.start('tie', 'memory', P); const m = core.get('tie');
    for (const p of P) await core.move('tie', p, { t: 'ready' });
    let r = 0; while (!m.over && r++ < 20) { t = m.st.showUntil + 600; for (const p of P) await core.move('tie', p, { t: 'answer', digits: m.st.seq.join('') }); }
    ok(m.over && m.st.round === 3 + M.MAX_EXTRA && m.outcome === 7 && m.st.rows.length > 0, 'a permanent tie ends after 5 extra rounds as a draw', { round: m.st.round, o: m.outcome });
    ok(m.st.len === 10 || m.st.rows[m.st.rows.length - 1].len === 10, 'extra rounds grow to 10 digits'); }
  // one player never answers: times out and loses; the others finish
  { const P = ['0x' + 'd'.repeat(40), '0x' + 'e'.repeat(40), '0x' + 'f'.repeat(40)]; core.start('slow', 'memory', P); const m = core.get('slow');
    for (const p of P) await core.move('slow', p, { t: 'ready' });
    t = m.st.showUntil + 600; await core.move('slow', P[0], { t: 'answer', digits: m.st.seq.join('') }); await core.move('slow', P[1], { t: 'answer', digits: '' });
    t += 100000; await core.tick();
    ok(m.out.has('c'), 'the silent player is out'); ok(m.st.round === 2 || m.over, 'the game went on without waiting for him', m.st.round);
    let r = 0; while (!m.over && r++ < 20) { t = m.st.showUntil + 600; await core.move('slow', P[0], { t: 'answer', digits: m.st.seq.join('') }); await core.move('slow', P[1], { t: 'answer', digits: '' }); }
    ok(m.over && m.outcome === 1, 'the accurate player wins alone, the silent one never', m.outcome); }
  console.log(fails ? fails + ' FAILED' : 'ALL OK'); process.exit(fails ? 1 : 0);
})();
