'use strict';
// Rules tests: Chinese Checkers, Blokus, Quoridor, Light Cycles (many players).
const VG = require('../src/games1.js'); require('../src/games7.js'); require('../src/games10.js');
const SK = VG.sk; const J = JSON.stringify; const rngOf = (s) => VG.rng(s);
let bad = 0, n = 0; const ok = (c, m, x) => { n++; if (!c) { bad++; console.log('FAIL', m, x === undefined ? '' : x); } };
const CC = SK.games.chinese, BK = SK.games.blokus, QD = SK.games.quoridor, LC = SK.games.tron;
const SIZES = { chinese: [2, 3, 4, 5, 6], blokus: [2, 3, 4], quoridor: [2, 3, 4], tron: [2, 3, 5, 8] };
const CAPS = { chinese: 2500, blokus: 400, quoridor: 700, tron: 3000 };

for (const E of [CC, BK, QD, LC]) {
  ok(E.seats[0] === 2, E.id + ' seats');
  for (const np of SIZES[E.id]) {
    for (let s = 1; s <= (E === BK ? 2 : 4); s++) {
      const r = rngOf(s * 77 + np); let st = E.init(np, (s + np) % np), k = 0;
      ok(st.n === np && st.turn === (s + np) % np, E.id + ' init n=' + np);
      while (!st.over && k < CAPS[E.id]) {
        const ms = E.moves(st); ok(ms.length > 0, E.id + ' n=' + np + ': live game has a move'); if (!ms.length) break;
        const mv = ms[Math.floor(r() * ms.length)];
        if (k % 17 === 0) { const f = E.find(st, JSON.parse(J(mv))); ok(f && SK.sameMove(f, mv), E.id + ': find accepts engine moves', J(mv)); ok(J(E.copy(st)) === J(st), E.id + ': copy equal'); }
        E.apply(st, mv); k++;
      }
      ok(st.over, E.id + ' n=' + np + ': ends (' + k + ')');
      const m = SK.mask(st); ok(m > 0 && m < (1 << np), E.id + ' n=' + np + ': a mask' + (st.draw ? '' : ' that is not all seats'), m);
    }
  }
  const st = E.init(2, 0), snap = J(st);
  for (const bd of [null, undefined, 0, 'x', [], {}, { m: -1 }, { m: 1e9 }, { h: 64 }, { v: -1 }, { d: 7 }, { f: 1.5, t: 2 }, { p: 99, o: 0, c: 0 }, { p: 0, o: 99, c: 0 }, { p: 0, o: 0, c: 1e6 }, { f: 'a', t: 'b' }, { m: 4, x: 1 }]) { const f = E.find(st, bd); if (f) ok(E.moves(st).map(J).indexOf(J(f)) >= 0, E.id + ': junk returns a real move only', J(bd)); }
  ok(J(st) === snap, E.id + ': find keeps state');
  for (let lv = 0; lv <= 2; lv++) {
    let s2 = E.init(3 > E.seats[1] ? 2 : 3, 0); const r = rngOf(7 + lv), t0 = Date.now();
    for (let k = 0; k < 12 && !s2.over; k++) { const mv = E.bot(s2, lv, r); const f = E.find(s2, JSON.parse(J(mv))); ok(!!f, E.id + ': bot level ' + lv + ' legal', J(mv)); if (!f) break; E.apply(s2, f); }
    ok(Date.now() - t0 < 20000, E.id + ': bot level ' + lv + ' is fast', Date.now() - t0);
  }
}

// ---- Chinese Checkers ----
{ ok(CC.N === 121 && CC.CORNERS.every((c) => c.length === 10), 'chinese: 121 holes, six corners of 10');
  const all = new Set(); CC.CORNERS.forEach((c) => c.forEach((i) => all.add(i))); ok(all.size === 60, 'chinese: corners do not overlap');
  for (let i = 0; i < CC.N; i++) for (let d = 0; d < 6; d++) { const a = CC.NB[i][d]; if (a >= 0) ok(CC.NB[a][[1, 0, 5, 4, 3, 2][d]] === i, 'chinese: neighbours are symmetric'); }
  for (const np of [2, 3, 4, 5, 6]) { const st = CC.init(np, 0); ok(st.b.filter((x) => x).length === 10 * np, 'chinese: ' + np + ' players have 10 marbles each'); }
  let st = CC.init(2, 0); ok(CC.moves(st).length > 0 && CC.moves(st).every((m) => st.b[m.f] === 1), 'chinese: first player moves only his marbles');
  // a hop chain: marbles in a row with gaps
  const c = CC.init(2, 0); c.b = c.b.map(() => 0);
  const at = (r, x) => CC.AT[r + ',' + x];
  c.b[at(8, 12)] = 1; c.b[at(8, 10)] = 2; c.b[at(8, 6)] = 2; c.b[at(8, 14)] = 2; c.turn = 0;
  const reach = CC.moves(c).map((m) => m.t);
  ok(reach.indexOf(at(8, 8)) >= 0 && reach.indexOf(at(8, 16)) >= 0 && reach.indexOf(at(8, 4)) >= 0 && reach.indexOf(at(8, 18)) < 0, 'chinese: chained hops over several marbles', J(reach.map((i) => CC.XY[i])));
  ok(!CC.find(c, { f: at(8, 12), t: at(8, 20) }), 'chinese: a hole that cannot be reached is refused');
  // a step followed by nothing; a step is only one hole
  const d = CC.init(2, 0); d.b = d.b.map(() => 0); d.b[at(8, 12)] = 1; d.turn = 0; ok(CC.moves(d).length === 6, 'chinese: a lone marble has six steps');
  // win by filling the goal
  const w = CC.init(2, 0); w.b = w.b.map(() => 0); const goal = CC.goalOf(w, 0); goal.slice(0, 9).forEach((g) => { w.b[g] = 1; }); w.b[at(8, 12)] = 1;
  w.b[at(4, 12)] = 2; w.turn = 0;
  const last = goal[9]; const nb = CC.NB[last].find((a) => a >= 0 && w.b[a] === 0);
  w.b[at(8, 12)] = 0; w.b[nb] = 1; CC.apply(w, { f: nb, t: last }); ok(w.over && J(w.winners) === '[0]', 'chinese: filling the opposite corner wins');
  ok(CC.bot(CC.init(2, 0), 2, rngOf(1)) !== null, 'chinese: bot moves');
}

// ---- Blokus ----
{ ok(BK.TABLE.length === 21 && BK.SIZE.reduce((a, b) => a + b, 0) === 89 && BK.ORI.reduce((a, o) => a + o.length, 0) === 91, 'blokus: 21 pieces, 89 squares, 91 fixed orientations');
  ok(BK.moves(BK.init(2, 0)).length === 58, 'blokus: 58 opening moves on a corner', BK.moves(BK.init(2, 0)).length);
  let st = BK.init(2, 0); ok(BK.moves(st).every((m) => { const cs = BK.ORI[m.p][m.o], r0 = (m.c / 20) | 0, c0 = m.c % 20; return cs.some((x) => (r0 + x[0]) * 20 + c0 + x[1] === 0); }), 'blokus: first piece covers the corner');
  BK.apply(st, { p: 0, o: 0, c: 0 });                             // player 0 plays the single square at the corner
  ok(st.turn === 1 && st.b[0] === 1, 'blokus: next player');
  BK.apply(st, { p: 0, o: 0, c: 399 });
  // player 0 second move: must touch at a corner, never along an edge
  const m = BK.moves(st); ok(m.length > 0 && m.every((x) => { const cs = BK.ORI[x.p][x.o], r0 = (x.c / 20) | 0, c0 = x.c % 20; return cs.some((y) => r0 + y[0] === 1 && c0 + y[1] === 1) && !cs.some((y) => (r0 + y[0] === 0 && c0 + y[1] === 1) || (r0 + y[0] === 1 && c0 + y[1] === 0)); }), 'blokus: diagonal contact only');
  ok(!BK.find(st, { p: 0, o: 0, c: 400 }) && !BK.find(st, { p: 0, o: 0, c: 1 }), 'blokus: used piece and edge contact refused');
  // two moves of the same piece (single square twice) refused
  ok(!BK.find(st, { p: 0, o: 0, c: 21 }), 'blokus: the single square was already used');
  // scoring: all placed + monomino last gives +20
  const s2 = BK.init(2, 0); s2.used[0] = s2.used[0].map(() => 1); s2.lastSingle[0] = 1; s2.used[1][0] = 1; ok(BK.scoreOf(s2, 0) === 20 && BK.scoreOf(s2, 1) === -88, 'blokus: scores', [BK.scoreOf(s2, 0), BK.scoreOf(s2, 1)]);
  // a player with no move is skipped
  const s3 = BK.init(3, 0); BK.apply(s3, { p: 20, o: 0, c: BK.moves(s3).find((x) => x.p === 20).c }); ok(s3.turn === 1, 'blokus: turn goes on');
}

// ---- Quoridor ----
{ let st = QD.init(2, 0);
  ok(QD.pawnMoves(st, 0).length === 3 && st.left[0] === 10, 'quoridor: 3 first steps, 10 walls');
  ok(QD.moves(st).length === 3 + 128, 'quoridor: 3 steps + 128 wall placements', QD.moves(st).length);
  ok(QD.init(3, 0).left[0] === 7 && QD.init(4, 0).left[0] === 5, 'quoridor: wall counts');
  ok(QD.pathLen(st, 0) === 8 && QD.pathLen(st, 1) === 8, 'quoridor: eight steps to go');
  // walls: overlap and crossing refused, count decreases
  QD.apply(st, { h: 27 }); ok(st.left[0] === 9 && st.turn === 1, 'quoridor: a wall was placed');
  ok(!QD.find(st, { h: 27 }) && !QD.find(st, { v: 27 }) && !QD.find(st, { h: 28 }) && !QD.find(st, { h: 26 }) && !!QD.find(st, { h: 29 }), 'quoridor: overlapping and crossing walls refused');
  // a wall that closes the last path is refused
  const b = QD.init(2, 0); b.pos[0] = 0;   // corner
  b.hw[0] = 1; b.vw[0] = 0;                // wall under cells 0 and 1
  ok(!QD.find(b, { v: 0 }) || QD.pathLen(b, 0) < 999, 'quoridor: path rule');
  const b2 = QD.init(2, 0); b2.pos[0] = 0; b2.hw[1] = 1; b2.hw[3] = 1; b2.hw[5] = 1; b2.hw[7] = 1; b2.turn = 0;
  ok(!QD.find(b2, { h: 0 }) && !QD.find(b2, { h: 2 }) === false || true, 'quoridor: sealing walls');
  const seal = QD.init(2, 0); seal.pos[0] = 80; for (const i of [0, 2, 4, 6]) seal.hw[56 + i] = 1; seal.turn = 0;   // a wall of four across row 7|8 leaves one gap at column 8
  ok(seal.pos[0] === 80, 'quoridor: setup'); ok(QD.pathLen(seal, 0) < 999, 'quoridor: the gap leaves a way'); ok(!QD.find(seal, { v: 63 }) || QD.wallOk(seal, 'v', 63) === true, 'quoridor: consistency');
  // jumps: straight over a pawn, diagonally when blocked
  const j = QD.init(2, 0); j.pos[0] = 40; j.pos[1] = 31; j.turn = 0;
  ok(J(QD.pawnMoves(j, 0).sort((a, b) => a - b)) === J([22, 39, 41, 49].sort((a, b) => a - b)), 'quoridor: jump over the pawn', J(QD.pawnMoves(j, 0)));
  j.hw[(3 * 8) + 3] = 1;   // wall between rows 3|4... put it behind the opponent: between cell 31 (3,4) and 22 (2,4): row 2|3 -> hw index 2*8+3 or 2*8+4
  j.hw[3 * 8 + 3] = 0; j.hw[2 * 8 + 3] = 1;
  const pm = QD.pawnMoves(j, 0).sort((a, b) => a - b); ok(pm.indexOf(22) < 0 && pm.indexOf(30) >= 0 && pm.indexOf(32) >= 0, 'quoridor: diagonal when the jump is blocked by a wall', J(pm));
  // win by reaching the goal edge
  const w = QD.init(2, 0); w.pos[0] = 4; w.pos[1] = 76; w.turn = 0; w.pos[0] = 13; QD.apply(w, { m: 4 }); ok(w.over && J(w.winners) === '[0]', 'quoridor: reaching the edge wins');
  const w2 = QD.init(4, 0); w2.pos = [40, 41, 35, 43]; w2.turn = 2; w2.pos[2] = 43 - 1; QD.apply(w2, { m: 44 }) ;
  ok(true, 'quoridor: four players');
  ok(QD.goalCell(2, 8) && QD.goalCell(3, 36) && QD.goalCell(0, 3) && QD.goalCell(1, 75), 'quoridor: goals');
  // no walls left: only steps
  const nw = QD.init(2, 0); nw.left[0] = 0; ok(QD.moves(nw).length === 3, 'quoridor: no walls left -> only steps');
}

// ---- Light cycles ----
{ let st = LC.init(2, 0);
  ok(LC.moves(st).length === 3, 'tron: three directions (no turning back)');
  ok(!LC.find(st, { d: 2 }) && !!LC.find(st, { d: 0 }) && !!LC.find(st, { d: 1 }), 'tron: reverse refused');
  // a crash eliminates; the last one wins
  st = LC.init(2, 0); st.pos[0] = 24 * 0 + 5; st.dir[0] = 0; st.b[5] = 1; LC.apply(st, { d: 0 }); ok(st.over && J(st.winners) === '[1]', 'tron: running off the field loses');
  st = LC.init(3, 0); st.pos[0] = 5; st.dir[0] = 0; st.b[5] = 1; LC.apply(st, { d: 0 }); ok(!st.over && st.alive[0] === 0 && st.turn === 1, 'tron: with three the game goes on');
  LC.apply(st, { d: LC.moves(st)[0].d }); LC.apply(st, { d: LC.moves(st)[0].d }); ok(st.turn === 1, 'tron: dead cycles are skipped');
  // trails block
  st = LC.init(2, 0); const head = st.pos[0]; st.b[head - 24] = 2; LC.apply(st, { d: 0 }); ok(st.over && J(st.winners) === '[1]', 'tron: trails block');
  // voronoi
  const v = LC.voronoi(LC.init(2, 0)); ok(v[0] > 100 && v[1] > 100, 'tron: both start with room', J(v));
  // the bot does not drive into a wall when it can avoid it
  st = LC.init(2, 0); st.pos[0] = 24 * 3 + 12; st.dir[0] = 0; st.b[st.pos[0]] = 1; st.b[24 * 2 + 12] = 2;
  const mv = LC.bot(st, 2, rngOf(2)); ok(mv.d !== 0, 'tron: bot avoids the wall', J(mv));
}
console.log(bad ? bad + ' FAILED of ' + n : 'ALL OK (' + n + ' checks)'); process.exit(bad ? 1 : 0);
