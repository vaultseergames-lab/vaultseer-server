'use strict';
// The player table rebuilt from the REAL Arena bytecode (JS EVM): play, settle, read the events back through chain.js + ratings.js.
const fs = require('fs'); const EV = '/home/claude/vaultseer-contracts/tests-evm/';
const { Chain, Contract, encodeCall } = require(EV + 'evm.js'); const secp = require(EV + 'secp.js');
const B = JSON.parse(fs.readFileSync(EV + 'build.json', 'utf8'));
const C = require('../src/crypto.js'), makeSigner = require('../src/signer.js'), makeChain = require('../src/chain.js'), makeRatings = require('../src/ratings.js');
let bad = 0; const ok = (c, m) => { console.log(c ? 'ok  ' : 'FAIL', m); if (!c) bad++; };
const KEY = 0x5160e005n, keyHex = '0x' + KEY.toString(16), ADDR = secp.addrOf(secp.mul(KEY));
const ch = new Chain(); ch.time = Math.floor(Date.now() / 1000); const OWN = secp.addrOf(secp.mul(0xa11ce001n)), TRE = secp.addrOf(secp.mul(0x7ea50004n));
function dep(name, args = []) { const abi = B[name].abi, c = abi.find((x) => x.type === 'constructor'); let init = Buffer.from(B[name].bin, 'hex'); if (c && c.inputs.length) init = Buffer.concat([init, encodeCall({ name: 'x', inputs: c.inputs }, args).subarray(4)]); return new Contract(ch, ch.deploy(OWN, init), abi); }
const usdt = dep('MockUSDT'); const arena = dep('Arena', [OWN, ADDR, TRE, [usdt.addr], [5000000n], [500000n]]);
const PA = secp.addrOf(secp.mul(0xa11ce00an)), PB = secp.addrOf(secp.mul(0xb0b0000bn));
for (const p of [PA, PB]) { usdt.send('mint', [p, 100000000n], OWN); usdt.as(p).send('approve', [arena.addr, 10n ** 12n]); }
const signer = makeSigner({ privateKey: keyHex, chainId: 31337, arena: arena.addr });
const hexOf = (b) => '0x' + Buffer.from(b).toString('hex');
(async () => {
  // three matches: A wins, B wins, draw
  const play = async (id, mask) => { arena.as(PA).send('open', [usdt.addr, 5000000n, 0, 2]); arena.as(PB).send('join', [BigInt(id)]); const s = Buffer.from((await signer.sign(id, mask)).slice(2), 'hex'); arena.as(PB).send('settle', [BigInt(id), mask, s]); };
  await play(1, 1); await play(2, 2); await play(3, 3);
  // a JSON-RPC front for the in-process chain
  const fetchFn = async (url, opt) => { const b = JSON.parse(opt.body), p = b.params; const r = (result) => ({ json: async () => ({ result }) });
    if (b.method === 'eth_blockNumber') return r('0x' + (ch.block + 10).toString(16));
    if (b.method === 'eth_getLogs') { const t0 = p[0].topics[0]; const out = ch.logs.filter((l) => l.addr.toLowerCase() === p[0].address.toLowerCase() && '0x' + l.topics[0].toString(16).padStart(64, '0') === t0)
      .map((l, i) => ({ blockNumber: '0x' + ch.block.toString(16), logIndex: '0x' + i.toString(16), topics: l.topics.map((t) => '0x' + t.toString(16).padStart(64, '0')), data: hexOf(l.data) })); return r(out); }
    if (b.method === 'eth_call') { const data = Buffer.from(p[0].data.slice(2), 'hex'); const rr = ch.call(OWN, arena.addr, data, 0n, true); return r(hexOf(rr.ret)); }
    throw new Error('unexpected ' + b.method); };
  const chain = makeChain({ rpcUrl: 'http://x', arena: arena.addr, fetchFn });
  const ev = await chain.getSettled(0, ch.block + 5);
  ok(ev.length === 3 && ev.map((e) => e.mask).join() === '1,2,3', 'the three MatchSettled events of the real contract are decoded (masks 1, 2, 3)');
  const rt = makeRatings({ chain, fromBlock: 0, chunk: 1000, log: (e) => console.log('log', e) }); await rt.sync();
  ok(rt.status().counted === 3, 'three matches counted, status: ' + JSON.stringify(rt.status()));
  const a = rt.profile(PA), b = rt.profile(PB);
  ok(a.games === 3 && b.games === 3 && a.wins === 1 && b.wins === 1 && a.draws === 1, 'A: 1 win, 1 loss, 1 draw; B: the same the other way round');
  console.log(a.rating, b.rating); process.exit(bad ? 1 : 0);
})();
