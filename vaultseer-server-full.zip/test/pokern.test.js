'use strict';
// N-handed hold'em: chips are conserved, side pots are right, games end, hidden cards stay hidden.
const crypto = require('crypto');
const P = require('../src/m_poker.js');
const A = require('../src/adapters.js');
let fails = 0; const ok = (c, m, x) => { if (!c) { fails++; if (fails < 60) console.log('FAIL', m, x === undefined ? '' : JSON.stringify(x)); } };
const chips = (st) => st.stacks.reduce((a, b) => a + b, 0) + (st.h && !st.h.done ? st.h.committed.reduce((a, b) => a + b, 0) : 0);
// random playouts
let hands = 0, games = 0, shows = 0, splits = 0, sidepots = 0;
for (let n = 2; n <= 9; n++) {
  for (let g = 0; g < 60; g++) {
    const st = P.create(n); let moves = 0;
    while (!st.over && moves < 4000) {
      const who = P.actors(st); ok(who.length === 1, 'one actor');
      const s = who[0], l = P.legal(st, s); ok(l.length > 0, 'actor has moves', { n, street: st.h.street });
      if (!l.length) break;
      // aggressive random: raise often, sometimes all-in
      let mv;
      const r = Math.random();
      const rs = l.find((m) => m.t === 'raise');
      if (rs && r < 0.35) mv = { t: 'raise', to: r < 0.08 ? rs.max : rs.min + crypto.randomInt(0, rs.max - rs.min + 1) };
      else if (r < 0.7) mv = l.find((m) => m.t === 'call') || l.find((m) => m.t === 'check');
      else mv = l.find((m) => m.t === 'fold') || l.find((m) => m.t === 'check');
      ok(P.find(st, mv, s), 'move is found', mv);
      const before = st.hand;
      P.apply(st, mv); moves++;
      ok(chips(st) === n * 1000, 'chips conserved', { n, chips: chips(st), hand: st.hand });
      ok(st.stacks.every((x) => x >= 0), 'no negative stacks');
      if (st.hand !== before || st.over) { hands++; const lh = st.lastHand; if (lh.showdown) shows++; if (lh.pots.some((p) => p.winners.length > 1)) splits++; if (lh.pots.length > 1) sidepots++; ok(lh.won.reduce((a, b) => a + b, 0) === lh.pots.reduce((a, p) => a + p.amount, 0), 'all pots paid out'); }
    }
    ok(st.over && st.winners.length >= 1, 'game over with winners', { n, moves, hand: st.hand });
    if (st.over) { const top = Math.max(...st.stacks); st.winners.forEach((w) => ok(st.stacks[w] === top, 'winner has the top stack')); }
    games++;
  }
}
console.log('poker playouts:', games, 'games,', hands, 'hands,', shows, 'showdowns,', splits, 'split pots,', sidepots, 'hands with side pots');
// deterministic checks
const D = (cards) => { const deck = Array.from({ length: 52 }, (_, i) => i); const used = new Set(cards); return cards.concat(deck.filter((c) => !used.has(c))); };
const c = (r, s) => s * 13 + r;   // rank 0=2 ... 12=A
{ // heads-up: button is small blind and acts first preflop; blinds 10/20
  const st = P.create(2); const h = st.h;
  ok(h.sb === st.dealer && h.turn === st.dealer, 'heads-up: button posts SB and acts first', { sb: h.sb, dealer: st.dealer, turn: h.turn });
  ok(h.bets[h.sb] === 10 && h.bets[h.bb] === 20, 'blinds posted');
  ok(P.legal(st, h.turn).some((m) => m.t === 'call' && m.amount === 10), 'SB must add 10 to call');
}
{ // 3 players, UTG = left of BB; everybody folds to BB: BB wins SB+own
  const st = P.create(3); const h = st.h;
  const order = [h.turn]; ok(h.turn === st.dealer, '3 handed: the button acts first preflop (UTG)', { turn: h.turn, d: st.dealer });
  P.apply(st, { t: 'fold' }); P.apply(st, { t: 'fold' });
  ok(st.hand === 2 && st.lastHand.won.reduce((a, b) => a + b, 0) === 30 && st.lastHand.won[h.bb] === 30, 'BB wins the blinds when all fold', st.lastHand.won);
  ok(!st.lastHand.showdown && st.lastHand.hole === null, 'no showdown: cards stay hidden');
}
const cd = (r, s) => s * 13 + r;
{ // side pots: stacks 100 / 300 / 1000, all-in preflop; seat 0 AA, seat 1 KK, seat 2 QQ
  const deck = D([cd(12, 0), cd(11, 0), cd(10, 0), cd(12, 1), cd(11, 1), cd(10, 1), cd(0, 2), cd(5, 3), cd(7, 1), cd(2, 2), cd(3, 3)]);
  const st = P.create(3, { deck, stacks: [100, 300, 1000], dealer: 2 });
  ok(st.h.sb === 0 && st.h.bb === 1 && st.h.turn === 2, 'dealer 2: SB seat 0, BB seat 1, seat 2 first');
  P.apply(st, { t: 'raise', to: 1000 });
  ok(P.legal(st, 0).some((m) => m.t === 'call') && !P.legal(st, 0).some((m) => m.t === 'raise'), 'short stack can only call/fold');
  P.apply(st, { t: 'call' }); P.apply(st, { t: 'call' });
  const lh = st.lastHand;
  ok(lh && lh.pots.length === 3, 'three pots', lh && lh.pots);
  ok(lh.pots[0].amount === 300 && lh.pots[0].winners.join() === '0', 'main pot 300 -> AA', lh.pots[0]);
  ok(lh.pots[1].amount === 400 && lh.pots[1].winners.join() === '1', 'side pot 400 -> KK', lh.pots[1]);
  ok(lh.pots[2].amount === 700 && lh.pots[2].winners.join() === '2', 'uncalled 700 returns to the big stack', lh.pots[2]);
  ok(lh.won.join() === '300,400,700', 'payouts 300/400/700', lh.won);
  ok(lh.showdown && lh.hole[0] && lh.hole[1] && lh.hole[2], 'all hands shown at the all-in showdown');
}
{ // a short all-in does not re-open the betting
  const deck = D([]);
  const st = P.create(3, { deck, stacks: [1000, 150, 1000], dealer: 2 });
  P.apply(st, { t: 'raise', to: 100 });                      // seat 2 raises (full raise: 80 over the blind)
  P.apply(st, { t: 'call' });                                 // seat 0 (SB) calls 100
  const r1 = P.legal(st, 1); ok(r1.some((m) => m.t === 'raise') && P.legal(st, 1).find((m) => m.t === 'raise').max === 150, 'BB may shove 150', r1);
  P.apply(st, { t: 'raise', to: 150 });                       // seat 1 all-in: raise of only 50 (< 80): short
  ok(st.h.turn === 2, 'back to seat 2', st.h.turn);
  const l2 = P.legal(st, 2); ok(l2.length === 2 && l2.some((m) => m.t === 'call') && l2.some((m) => m.t === 'fold') && !l2.some((m) => m.t === 'raise'), 'seat 2 acted already: call or fold only', l2);
  P.apply(st, { t: 'call' });
  const l0 = P.legal(st, 0); ok(!l0.some((m) => m.t === 'raise') && l0.some((m) => m.t === 'call'), 'seat 0 also cannot raise', l0);
}
{ // a full raise DOES re-open; min raise = last raise size
  const st = P.create(3, { deck: D([]), dealer: 2 });
  P.apply(st, { t: 'raise', to: 100 });                      // raise size 80
  const l0 = P.legal(st, 0).find((m) => m.t === 'raise'); ok(l0.min === 180, 'min re-raise is 180 (100 + 80)', l0);
  P.apply(st, { t: 'raise', to: 300 });                      // raise size 200
  const l1 = P.legal(st, 1).find((m) => m.t === 'raise'); ok(l1.min === 500, 'next min re-raise 500 (300 + 200)', l1);
  ok(!P.find(st, { t: 'raise', to: 400 }, 1), 'raise below the minimum refused');
  ok(!P.find(st, { t: 'raise', to: 99999 }, 1), 'raise above the stack refused');
}
{ // heads-up: the player after the button (BB) acts first after the flop
  const st = P.create(2, { deck: D([]), dealer: 0 });
  ok(st.h.turn === 0, 'heads-up button acts first preflop');
  P.apply(st, { t: 'call' }); P.apply(st, { t: 'check' });
  ok(st.h.street === 'flop' && st.h.turn === 1, 'heads-up postflop: BB acts first', { street: st.h.street, turn: st.h.turn });
}
{ // split pot, odd chip goes to the first player left of the button
  // level 1 blinds 15/30. seat0 (SB) folds, seats 1 and 2 tie with the same board
  const deck = [42, 39, 13, 30, 27, 28, 12, 37, 49, 22, 7].concat(Array.from({ length: 52 }, (_, i) => i).filter((c) => ![42, 39, 13, 30, 27, 28, 12, 37, 49, 22, 7].includes(c)));
  const st = P.create(3, { deck, dealer: 2, hand0: 3 });
  ok(st.h.sbAmt === 15 && st.h.bbAmt === 30, 'blinds went up to 15/30 at hand 4', { sb: st.h.sbAmt });
  P.apply(st, { t: 'call' }); P.apply(st, { t: 'fold' }); P.apply(st, { t: 'check' });
  let g = 0; while (st.hand === 4 && g++ < 20) P.apply(st, { t: 'check' });
  const lh = st.lastHand; ok(lh.won.join() === '0,38,37', 'pot 75 split: odd chip to seat 1 (first left of the button)', lh.won);
}
{ // the game ends after maxHands with the chip leader as winner; all-check games play to the end
  const st = P.create(4, { hands: 6 }); let g = 0;
  while (!st.over && g++ < 2000) { const s = P.actors(st)[0], l = P.legal(st, s); P.apply(st, l.find((m) => m.t === 'call') || l.find((m) => m.t === 'check')); }
  ok(st.over && st.hand === 6, 'ends after maxHands (6)', st.hand);
}
{ const st = P.create(4); const h = st.h; ok(h.inHand.every(Boolean), 'all dealt in'); ok(h.hole.every((x) => x.length === 2), 'two hole cards each'); const all = h.hole.flat(); ok(new Set(all).size === 8, 'distinct cards'); }
// the commitment: sha256(nonce|deck) shown at the start is checked at the end
{ const st = P.create(3); const first = st.h.commit; const VG = require('../src/games1.js'); const nonce = st.h.nonce, deck = st.h.deck.slice();
  ok(VG.sha256(nonce + '|' + deck.join(',')) === first, 'commitment matches (nonce+deck)');
  let g = 0; while (!st.over && st.hand === 1 && g++ < 100) { const w = P.actors(st)[0]; P.apply(st, P.auto(st, w)); }
  ok(st.lastHand && VG.sha256(st.lastHand.nonce + '|' + st.lastHand.deck.join(',')) === st.lastHand.commit && st.lastHand.commit === first, 'revealed deck matches the commitment'); }
// adapters: views never leak other players' cards
{ const ad = A.byId.poker; ok(ad.seats[1] === 9, 'poker seats 2-9'); const st = ad.init(5);
  const v = ad.view(st, 'c'); const hs = JSON.stringify(v);
  ok(Array.isArray(v.hole) && v.hole.length === 2, 'own hole cards visible');
  const others = [0, 1, 3, 4].flatMap((i) => st.h.hole[i]);
  ok(!hs.includes('"deck"') && !hs.includes('"nonce"'), 'deck and nonce hidden during the hand');
  ok(ad.view(st, null).hole === undefined, 'spectator sees no hole cards');
  ok(ad.result(Object.assign({}, st, { over: false }), 0) === null, 'no result while playing'); }
// the core with 5 players: one leaves, one times out: they fold out; the rest finish; winner is never an out player
(async () => {
  const makeCore = require('../src/core');
  let t = 0; const core = makeCore({ now: () => t, sign: async (id, o) => 'sig:' + id + ':' + o });
  const PL = Array.from({ length: 5 }, (_, i) => '0x' + (i + 1).toString(16).repeat(40));
  for (let g = 0; g < 25; g++) {
    const id = 'p' + g; core.start(id, 'poker', PL); const m = core.get(id); let guard = 0;
    while (!m.over && guard++ < 6000) {
      t += 300;
      if (guard === 9) await core.leave(id, PL[1]);
      if (m.over) break;
      const a = m.actors[0]; const addr = PL['abcde'.indexOf(a)];
      if (guard === 40 && a !== 'b') { t += 50000; await core.tick(); continue; }
      const l = core.view(id, addr).legal; if (!l.length) { ok(false, 'live actor without moves'); break; }
      const rs = l.find((x) => x.t === 'raise'); const r = Math.random();
      const mv = rs && r < 0.3 ? { t: 'raise', to: rs.min } : (l.find((x) => x.t === 'call') || l.find((x) => x.t === 'check')) ;
      const res = await core.move(id, addr, mv); ok(res.ok, 'move accepted', res);
    }
    ok(m.over && m.sig, 'poker match finished and signed', { why: m.why, guard });
    ok(!(m.outcome & 2), 'the player who left is not a winner', m.outcome);
    ok(m.outcome > 0 && m.outcome < 32, 'mask in range', m.outcome);
  }
  console.log(fails ? fails + ' FAILED' : 'ALL OK'); process.exit(fails ? 1 : 0);
})();
