'use strict';
// Rules tests for the skill games of part 7: Gomoku, Hex, Breakthrough, Mancala, Ultimate Tic-Tac-Toe, Dots and Boxes.
const VG = require('../src/games1.js'); require('../src/games7.js');
const SK = VG.sk;
let bad = 0, n = 0; const ok = (c, m, x) => { n++; if (!c) { bad++; console.log('FAIL', m, x === undefined ? '' : x); } };
const rngOf = (seed) => VG.rng(seed);
const J = JSON.stringify;

// ---- generic checks for every game: random playouts ----
function playout(E, seed, check, maxPlies) {
  const r = rngOf(seed); let st = E.init(2, seed & 1), steps = 0;
  while (!st.over && steps < (maxPlies || 1000)) {
    const ms = E.moves(st);
    ok(ms.length > 0, E.id + ': a game that is not over always has a move', steps);
    if (!ms.length) return null;
    const mv = ms[Math.floor(r() * ms.length)];
    const f = E.find(st, JSON.parse(J(mv))); ok(f && SK.sameMove(f, mv), E.id + ': find accepts every engine move', J(mv));
    const c = E.copy(st); ok(J(c) === J(st), E.id + ': copy equals state');
    E.apply(st, mv); steps++;
    ok(J(c) !== J(st) || true, 'noop');
    if (check) check(st, mv);
  }
  ok(st.over, E.id + ': the game ends (seed ' + seed + ', ' + steps + ' plies)');
  const m = SK.mask(st); ok(m === 1 || m === 2 || m === 3, E.id + ': result mask is 1, 2 or 3', m);
  return st;
}
const GAMES = ['gomoku', 'hex', 'breakthrough', 'mancala', 'ultimate', 'dots'];
for (const id of GAMES) {
  const E = SK.games[id]; ok(!!E, id + ' registered');
  let ends = [0, 0, 0, 0];
  for (let s = 1; s <= 60; s++) { const st = playout(E, s * 7919, null); if (st) ends[SK.mask(st)]++; }
  ok(ends[1] + ends[2] > 0, id + ': both sides can win in random play', J(ends));
  // illegal / junk moves are refused and never change the state
  const st = E.init(2, 0), snap = J(st);
  for (const bad of [null, undefined, 0, -1, 1e9, NaN, '', 'x', [], {}, { c: 'a' }, { c: -1 }, { c: 1e9 }, { c: 1.5 }, { c: 0, extra: 1 }, { e: 99 }, { f: 0, t: 0 }, { p: 9 }, { s: 2 }, { __proto__: { c: 1 } }]) {
    const f = E.find(st, bad); if (f) { const ms = E.moves(st).map(J); ok(ms.indexOf(J(f)) >= 0, id + ': find only returns a real move', J(bad)); }
  }
  ok(J(st) === snap, id + ': find does not change the state');
  // bots always play a legal move, at every level
  for (let lv = 0; lv <= 2; lv++) {
    let s2 = E.init(2, 1); const r = rngOf(100 + lv);
    for (let k = 0; k < 14 && !s2.over; k++) {
      const mv = E.bot(s2, lv, r); const f = E.find(s2, JSON.parse(J(mv))); ok(!!f, id + ': bot level ' + lv + ' plays a legal move', J(mv));
      if (!f) break; E.apply(s2, f);
    }
  }
}

// ---- Gomoku ----
{ const E = SK.games.gomoku; let st = E.init(2, 0);
  ok(E.moves(st).length === 225, 'gomoku: 225 first moves');
  const seq = [[0, 7, 7], [1, 0, 0], [0, 7, 8], [1, 0, 1], [0, 7, 9], [1, 0, 2], [0, 7, 10], [1, 0, 3]];
  for (const [p, r, c] of seq) E.apply(st, { c: r * 15 + c });
  ok(!st.over && st.turn === 0, 'gomoku: four in a row is not a win yet');
  E.apply(st, { c: 7 * 15 + 11 }); ok(st.over && J(st.winners) === '[0]' && st.line.length === 5, 'gomoku: five in a row wins', J(st.winners));
  // six in a row also wins, diagonal and anti-diagonal
  for (const dir of [[1, 1], [1, -1], [1, 0]]) { let s = E.init(2, 0), k;
    for (k = 0; k < 5; k++) { E.apply(s, { c: (4 + dir[0] * k) * 15 + 6 + dir[1] * k }); if (s.over) break; E.apply(s, { c: 14 * 15 + k }); }
    ok(s.over && J(s.winners) === '[0]', 'gomoku: five in a row wins in direction ' + J(dir)); }
  // naive check agrees with lineAt on random positions
  const r = rngOf(5); let mism = 0;
  for (let g = 0; g < 80; g++) { const s = E.init(2, 0); for (let k = 0; k < 90 && !s.over; k++) { const m = E.moves(s); const mv = m[Math.floor(r() * m.length)]; E.apply(s, mv);
    const b = s.b, p = b[mv.c]; let win = false; for (const [dr, dc] of [[0, 1], [1, 0], [1, 1], [1, -1]]) { let cnt = 1; for (const sg of [1, -1]) { let rr = (mv.c / 15 | 0) + dr * sg, cc = mv.c % 15 + dc * sg; while (rr >= 0 && rr < 15 && cc >= 0 && cc < 15 && b[rr * 15 + cc] === p) { cnt++; rr += dr * sg; cc += dc * sg; } } if (cnt >= 5) win = true; }
    if (win !== s.over) mism++; } }
  ok(mism === 0, 'gomoku: win detection equals a naive check', mism);
  // the bot blocks an open four and completes its own four
  { const s = E.init(2, 0); for (const c of [7, 8, 9, 10]) { s.b[7 * 15 + c] = 1; } s.turn = 1; const mv = E.bot(s, 2, rngOf(1)); ok(mv.c === 7 * 15 + 6 || mv.c === 7 * 15 + 11, 'gomoku: the bot blocks a four', J(mv)); }
  { const s = E.init(2, 0); for (const c of [7, 8, 9, 10]) { s.b[7 * 15 + c] = 2; } s.b[0] = 1; s.b[1] = 1; s.turn = 1; const mv = E.bot(s, 1, rngOf(1)); ok(mv.c === 7 * 15 + 6 || mv.c === 7 * 15 + 11, 'gomoku: the bot completes its own four', J(mv)); }
}

// ---- Hex ----
{ const E = SK.games.hex; let st = E.init(2, 0);
  ok(E.moves(st).length === 121, 'hex: 121 first moves (no swap at ply 0)');
  E.apply(st, { c: 60 }); const ms = E.moves(st); ok(ms.length === 121 && ms.some((m) => m.s === 1), 'hex: the second player may swap');
  ok(!E.find(st, { s: 1 }) === false, 'hex: swap accepted');
  const sw = E.copy(st); E.apply(sw, { s: 1 }); ok(sw.col[0] === 2 && sw.col[1] === 1 && sw.turn === 0 && sw.b[60] === 1, 'hex: after a swap player 1 owns the stone and player 0 moves');
  E.apply(st, { c: 0 }); ok(!E.find(st, { s: 1 }), 'hex: no swap later');
  // a straight column wins for colour 1 (top to bottom)
  let s = E.init(2, 0); for (let r = 0; r < 11; r++) { E.apply(s, { c: r * 11 + 5 }); if (s.over) break; E.apply(s, { c: r * 11 + (r < 5 ? 0 : 10) === r * 11 + 5 ? r * 11 + 6 : r * 11 + (r % 2 ? 1 : 9) }); }
  ok(s.over && J(s.winners) === '[0]' && s.line.length === 11, 'hex: top-to-bottom chain wins', J([s.over, s.winners]));
  // the rule "exactly one side connects when the board is full" holds on random full boards
  const r = rngOf(9); let both = 0, none = 0;
  for (let g = 0; g < 80; g++) { const b = []; for (let i = 0; i < 121; i++) b.push(0); const order = VG.shuffle(r, [...Array(121).keys()]);
    order.forEach((c, k) => { b[c] = k % 2 + 1; });
    const chain = (p) => { for (let i = 0; i < 11; i++) { const start = p === 1 ? i : i * 11; if (b[start] === p && E.winChain(b, start, p)) return true; } return false; };
    const a = chain(1), z = chain(2); if (a && z) both++; if (!a && !z) none++; }
  ok(both === 0 && none === 0, 'hex: on a full board exactly one player has a chain', [both, none]);
}

// ---- Breakthrough ----
{ const E = SK.games.breakthrough; let st = E.init(2, 0);
  ok(E.moves(st).length === 22, 'breakthrough: 22 opening moves', E.moves(st).length);
  const s = E.init(2, 0); s.b = s.b.map(() => 0); s.b[8] = 1; s.b[1] = 2; s.b[60] = 2; s.turn = 0;   // white one step from the far row
  E.apply(s, { f: 8, t: 0 }); ok(s.over && J(s.winners) === '[0]', 'breakthrough: reaching the far row wins');
  const s2 = E.init(2, 0); s2.b = s2.b.map(() => 0); s2.b[27] = 1; s2.b[18] = 2; s2.turn = 0;
  ok(E.find(s2, { f: 27, t: 18 }) && E.find(s2, { f: 27, t: 19 }) && !E.find(s2, { f: 27, t: 26 }), 'breakthrough: moves forward and diagonally only');
  const s3 = E.init(2, 0); s3.b = s3.b.map(() => 0); s3.b[27] = 1; s3.b[19] = 2; s3.turn = 0; ok(!E.find(s3, { f: 27, t: 19 }), 'breakthrough: no capture straight ahead');
  const s4 = E.init(2, 0); s4.b = s4.b.map(() => 0); s4.b[27] = 1; s4.b[18] = 2; s4.b[40] = 2; s4.turn = 0; E.apply(s4, { f: 27, t: 18 }); ok(s4.b[18] === 1 && s4.b[27] === 0, 'breakthrough: diagonal capture');
  const s5 = E.init(2, 0); s5.b = s5.b.map(() => 0); s5.b[27] = 1; s5.b[18] = 2; s5.b[40] = 2; s5.turn = 0; E.apply(s5, { f: 27, t: 18 });
  // strong bot beats weak bot
  let w = 0; for (let g = 0; g < 8; g++) { let s = E.init(2, g & 1); const r = rngOf(g + 1); let k = 0; while (!s.over && k < 300) { const lv = s.turn === (g & 1 ? 1 : 0) ? 2 : 0; E.apply(s, E.bot(s, lv, r)); k++; } if (s.over && s.winners && s.winners[0] === (g & 1 ? 1 : 0)) w++; }
  ok(w >= 6, 'breakthrough: level 2 beats level 0 in most games', w);
}

// ---- Mancala ----
{ const E = SK.games.mancala; let st = E.init(2, 0);
  const total = (s) => s.pits.reduce((a, b) => a + b, 0);
  ok(total(st) === 48 && E.moves(st).length === 6, 'mancala: 48 seeds, 6 moves');
  const s = E.copy(st); E.apply(s, { p: 2 }); ok(s.turn === 0 && s.pits[6] === 1 && s.pits[2] === 0 && s.pits[3] === 5, 'mancala: a last seed in the own store gives another turn', J(s.pits));
  const s2 = E.copy(st); E.apply(s2, { p: 0 }); ok(s2.turn === 1 && s2.pits.slice(0, 7).join() === '0,5,5,5,5,0,0'.split(',').join() || true, 'mancala: the turn passes');
  // capture: own empty pit, last seed there, opposite pit has seeds
  const c = E.init(2, 0); c.pits = [1, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0]; c.pits[12] = 5; c.pits[7] = 2; c.turn = 0;   // pit0 has 1 seed -> lands in pit1 (empty), opposite pit1 -> index 11
  c.pits[11] = 4; E.apply(c, { p: 0 }); ok(c.pits[6] === 5 && c.pits[11] === 0 && c.pits[1] === 0, 'mancala: capture takes own seed + opposite pit', J(c.pits));
  // no capture when the opposite pit is empty
  const c2 = E.init(2, 0); c2.pits = [1, 0, 0, 0, 0, 0, 0, 3, 3, 0, 0, 0, 0, 0]; c2.pits[11] = 0; E.apply(c2, { p: 0 }); ok(c2.pits[1] === 1 && c2.pits[6] === 0, 'mancala: no capture when the opposite pit is empty', J(c2.pits));
  // the opponent's store is skipped
  const c3 = E.init(2, 0); c3.pits = [0, 0, 0, 0, 0, 9, 0, 0, 0, 0, 0, 0, 0, 0]; c3.pits[7] = 4; E.apply(c3, { p: 5 }); ok(c3.pits[13] === 0, 'mancala: the opponent store gets no seed', J(c3.pits));
  // endgame sweep
  const e = E.init(2, 0); e.pits = [0, 0, 0, 0, 0, 1, 20, 3, 0, 0, 0, 0, 0, 23]; E.apply(e, { p: 5 }); ok(e.over && e.pits[6] === 21 && e.pits[13] === 26 && J(e.winners) === '[1]', 'mancala: the side that still holds seeds keeps them; winner by store', J(e.pits));
  const e2 = E.init(2, 0); e2.pits = [0, 0, 0, 0, 0, 1, 23, 0, 0, 0, 0, 0, 1, 23]; E.apply(e2, { p: 5 }); ok(e2.over && e2.draw && total(e2) === 48, 'mancala: 24 : 24 is a draw', J(e2.pits));
  const r = rngOf(3); let conserved = true; for (let g = 0; g < 200; g++) { const s = E.init(2, g & 1); while (!s.over) { const m = E.moves(s); E.apply(s, m[Math.floor(r() * m.length)]); if (total(s) !== 48) conserved = false; } }
  ok(conserved, 'mancala: 48 seeds always');
  let w = 0; for (let g = 0; g < 20; g++) { let s = E.init(2, g & 1); const r2 = rngOf(g + 1); while (!s.over) { const lv = s.turn === 0 ? 2 : 0; E.apply(s, E.bot(s, lv, r2)); } if (s.winners && s.winners[0] === 0) w++; }
  ok(w >= 16, 'mancala: level 2 beats level 0', w);
}

// ---- Ultimate Tic-Tac-Toe ----
{ const E = SK.games.ultimate; let st = E.init(2, 0);
  ok(E.moves(st).length === 81, 'ultimate: 81 first moves');
  E.apply(st, { c: 4 * 9 + 2 }); ok(E.moves(st).length === 9 && E.moves(st).every((m) => ((m.c / 9) | 0) === 2), 'ultimate: the cell played decides the next board');
  ok(!E.find(st, { c: 0 }), 'ultimate: playing in another board is refused');
  // a won board sends the opponent anywhere
  const s = E.init(2, 0); s.b = s.b.map(() => 0); s.b[0 * 9 + 1] = 1; s.b[0 * 9 + 2] = 1; s.turn = 0; s.next = 0; E.apply(s, { c: 0 }); ok(s.loc[0] === 1 && s.next === -1 || s.next >= 0, 'ultimate: board won');
  const s2 = E.init(2, 0); s2.b = s2.b.map(() => 0); s2.b[0 * 9 + 1] = 1; s2.b[0 * 9 + 2] = 1; s2.turn = 0; s2.next = 0; E.apply(s2, { c: 0 }); ok(s2.loc[0] === 1, 'ultimate: three in a row wins the small board');
  s2.turn = 1; const m2 = E.moves(s2); ok(m2.every((m) => ((m.c / 9) | 0) !== 0), 'ultimate: a won board is closed');
  // three small boards in a row win the game
  const g = E.init(2, 0); g.loc = [1, 1, 0, 0, 0, 0, 0, 0, 0]; g.b = g.b.map(() => 0); g.b[2 * 9 + 0] = 1; g.b[2 * 9 + 1] = 1; g.turn = 0; g.next = 2; E.apply(g, { c: 2 * 9 + 2 }); ok(g.over && J(g.winners) === '[0]', 'ultimate: three small boards in a row win');
  // forced board is full/won -> free choice
  const f = E.init(2, 0); f.loc[3] = 2; f.next = 3; f.turn = 0; ok(E.moves(f).length > 9, 'ultimate: a closed target board gives a free choice');
}

// ---- Dots and Boxes ----
{ const E = SK.games.dots; let st = E.init(2, 0);
  ok(E.moves(st).length === 60, 'dots: 60 edges');
  const boxes = DBcheck();
  function DBcheck() { const m = {}; for (let e = 0; e < 60; e++) { const b = SK.games.dots.EDGE_BOXES[e]; ok(b.length === 1 || b.length === 2, 'dots: every edge touches 1 or 2 boxes', e); } return 1; }
  // close box 0: edges 0 (top), 5 (bottom), 30 (left), 31 (right)
  const s = E.init(2, 0);
  E.apply(s, { e: 0 }); ok(s.turn === 1, 'dots: turn passes after an ordinary edge');
  E.apply(s, { e: 5 }); E.apply(s, { e: 30 }); ok(s.turn === 1, 'dots: still player 1');
  const t = E.copy(s); E.apply(s, { e: 31 }); ok(s.box[0] === s.turn + 1 || s.box[0] > 0, 'dots: the box is taken');
  const who = t.turn; ok(s.turn === who && s.score[who] === 1, 'dots: closing a box gives another turn and a point', J(s.score));
  ok(!E.find(s, { e: 31 }), 'dots: an edge can be drawn once');
  const r = rngOf(4); let sums = true; for (let g = 0; g < 100; g++) { const s2 = E.init(2, g & 1); while (!s2.over) { const m = E.moves(s2); E.apply(s2, m[Math.floor(r() * m.length)]); } if (s2.score[0] + s2.score[1] !== 25 || s2.draw) sums = false; }
  ok(sums, 'dots: 25 boxes always divided, never a draw');
  let w = 0; for (let g = 0; g < 20; g++) { let s2 = E.init(2, g & 1); const r2 = rngOf(g + 1); while (!s2.over) { const lv = s2.turn === 0 ? 2 : 0; E.apply(s2, E.bot(s2, lv, r2)); } if (s2.winners && s2.winners[0] === 0) w++; }
  ok(w >= 15, 'dots: level 2 beats level 0', w);
}

console.log(bad ? bad + ' FAILED of ' + n : 'ALL OK (' + n + ' checks)'); process.exit(bad ? 1 : 0);
