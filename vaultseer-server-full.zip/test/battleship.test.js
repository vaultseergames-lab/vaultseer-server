'use strict';
const makeCore = require('../src/core');
const { fleetOk } = require('../src/adapters');
const VG = require('../src/games1.js'); require('../src/games2.js');
const A = '0x' + 'a'.repeat(40), B = '0x' + 'b'.repeat(40);
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log('FAIL', m); } else console.log('ok  ', m); };
const fleet = (seed) => VG.battleship.place(VG.rng(seed)).map((s) => s.cells);
(async () => {
  let good = 0; for (let i = 1; i <= 200; i++) if (fleetOk(fleet(i))) good++;
  ok(good === 200, 'fleets made by the game itself are accepted (200/200)');
  const f = fleet(5);
  const bad = {
    'ship too short': f.map((s, i) => (i === 0 ? s.slice(1) : s)),
    'a ship missing': f.slice(1),
    'two ships touch at a corner': f.map((s, i) => (i === 0 ? [0, 1, 2, 3] : i === 1 ? [14, 15, 16] : s)),
    'ship wraps to next row': f.map((s, i) => (i === 0 ? [8, 9, 10, 11] : s)),
    'cell out of board': f.map((s, i) => (i === 6 ? [100] : s)),
    'ship not straight': f.map((s, i) => (i === 0 ? [0, 1, 11, 12] : s)),
    'not an array': 'x',
  };
  for (const [k, v] of Object.entries(bad)) ok(!fleetOk(v), 'refused: ' + k);
  let t = 0; const core = makeCore({ now: () => t, sign: async (id, o) => 'sig' + o });
  core.start(1, 'battleship', A, B);
  ok(core.view(1, A).actors.length === 2, 'both place fleets at the same time');
  ok((await core.move(1, A, { fleet: bad['a ship missing'] })).err === 'illegal move', 'bad fleet refused by the server');
  const fa = fleet(11), fb = fleet(12);
  ok((await core.move(1, A, { fleet: fa })).waiting, 'A ready, waiting');
  ok(core.view(1, B).state.phase === 'setup' && !JSON.stringify(core.view(1, B)).includes(JSON.stringify(fa[0])), 'B cannot see A\'s fleet');
  await core.move(1, B, { fleet: fb });
  ok(core.view(1, A).state.phase === 'play' && core.view(1, A).actors[0] === 'a' && core.view(1, A).legal.length === 100, 'battle starts, A shoots first');
  ok(!JSON.stringify(core.view(1, A).state).includes(JSON.stringify(fb[0])), 'B\'s ships are not in A\'s view');
  // shoot a known ship cell
  const hitCell = fb[0][0]; const r = await core.move(1, A, { cell: hitCell });
  ok(r.ok && core.view(1, A).actors[0] === 'a', 'a hit gives another shot');
  ok((await core.move(1, A, { cell: hitCell })).err === 'illegal move', 'same cell twice refused');
  ok((await core.move(1, B, { cell: 0 })).err === 'not your turn', 'B cannot shoot out of turn');
  // full random games
  let aw = 0, bw = 0;
  for (let g = 0; g < 30; g++) {
    const id = 100 + g; core.start(id, 'battleship', A, B);
    await core.move(id, A, { fleet: fleet(g * 2 + 1) }); await core.move(id, B, { fleet: fleet(g * 2 + 2) });
    for (let i = 0; i < 400 && !core.get(id).over; i++) {
      const who = core.get(id).actors[0] === 'a' ? A : B, l = core.view(id, who).legal;
      const rr = await core.move(id, who, l[Math.floor(Math.random() * l.length)]); if (!rr.ok) { fails++; console.log('FAIL', rr.err); break; }
    }
    const o = core.get(id).outcome; if (!core.get(id).over) { fails++; console.log('FAIL no end'); } else (o === 1 ? aw++ : bw++);
  }
  ok(aw + bw === 30, 'battleship: 30 random games finished with a winner (' + aw + ' / ' + bw + ')');
  core.start(2, 'battleship', A, B); await core.move(2, A, { fleet: fa }); t += 61000; await core.tick();
  ok(core.get(2).outcome === 1 && core.get(2).why === 'timeout', 'B did not place in 60s -> A wins');
  console.log(fails ? fails + ' FAILED' : 'ALL OK'); process.exit(fails ? 1 : 0);
})();
