'use strict';
// Durak for 2-6 players: random playouts check the rules, card conservation, hidden hands and that games always end.
const crypto = require('crypto');
const D = require('../src/m_durak.js');
const A = require('../src/adapters.js');
let fails = 0; const ok = (c, m, x) => { if (!c) { fails++; console.log('FAIL', m, x === undefined ? '' : JSON.stringify(x)); } };
const total = (st) => st.discarded + st.deck.length + st.hands.reduce((a, h) => a + h.length, 0) + st.table.reduce((a, p) => a + 1 + (p.d != null ? 1 : 0), 0);
let rounds = 0, games = 0, maxMoves = 0;
for (let n = 2; n <= 6; n++) {
  for (let g = 0; g < 150; g++) {
    const st = D.create(n); let moves = 0;
    ok(total(st) === 36 && st.hands.every((h) => h.length === 6), 'deal ' + n);
    const first = st.att, trumps = st.hands.map((h) => Math.min(...h.filter((c) => D.suit(c) === st.trump).map(D.rank), 99));
    ok(trumps[first] === Math.min(...trumps) || Math.min(...trumps) === 99, 'lowest trump leads (' + n + ')');
    while (!st.over && moves < 3000) {
      const who = D.actors(st); ok(who.length === 1, 'exactly one actor');
      const l = D.legal(st, who[0]); ok(l.length > 0, 'actor always has a legal move', { n, st: st.stage });
      if (!l.length) break;
      // random, but sometimes strategic so rounds are not endless
      const mv = Math.random() < 0.15 ? D.auto(st, who[0]) : l[crypto.randomInt(0, l.length)];
      ok(D.find(st, mv, who[0]), 'legal move is found');
      // nobody else may move
      for (let s = 0; s < n; s++) if (s !== who[0]) ok(D.legal(st, s).length === 0, 'only the actor has moves');
      ok(D.apply(st, mv, who[0]), 'move applies');
      ok(total(st) === 36, 'cards are conserved'); moves++;
      if (st.stage === 'attack' && st.table.length) ok(st.table.length <= 6, 'table <= 6');
    }
    ok(st.over && st.winners && st.winners.length >= 1, 'game ended with winners (n=' + n + ', moves ' + moves + ')');
    if (st.over) { ok(st.deck.length === 0, 'deck empty at the end'); st.winners.forEach((w) => ok(st.hands[w].length === 0, 'winner has no cards')); ok(st.winners.length < n || n === 2, 'everybody can only win together (a draw) in a 2-player game'); }
    rounds += st.round; games++; maxMoves = Math.max(maxMoves, moves);
  }
}
console.log('durak playouts:', games, 'games, avg rounds', (rounds / games).toFixed(1), 'longest', maxMoves, 'moves');
// rules on a fixed deal, 3 players
{
  // deck so that: seat0 holds trump six (leads); build by hand
  const deck = Array.from({ length: 36 }, (_, i) => i);
  const st = D.create(3, deck);
  ok(st.trumpCard === 35 && st.trump === 3, 'trump is the last card');
  ok(JSON.stringify(st.hands) === JSON.stringify([[0, 3, 6, 9, 12, 15], [1, 4, 7, 10, 13, 16], [2, 5, 8, 11, 14, 17]]), 'deal order');
  ok(st.def === (st.att + 1) % 3, 'defender is the player after the attacker');
}
{
  // hand-built: attacker leads 7♠ (card 1 = suit0 rank1); defender beats with 8♠(2); third player may throw in a 7
  const st = D.create(3);
  st.deck = [20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31]; st.trump = 3; st.trumpCard = 31;
  st.hands = [[1, 10, 19, 28, 7, 16], [2, 11, 20, 29, 8, 17], [10 - 10 + 9 + 1, 3, 4, 5, 6, 0]];
  st.att = 0; st.def = 1; st.table = []; st.stage = 'attack'; st.thrower = 0; st.passed = []; st.taking = false; st.startHand = 6; st.limit = 6;
  // seat0 leads card 1 (rank1 suit0)
  ok(D.apply(st, { t: 'attack', card: 1 }, 0) && st.stage === 'defend', 'lead goes to defend stage');
  ok(D.legal(st, 0).length === 0 && D.legal(st, 2).length === 0 && D.legal(st, 1).some((m) => m.t === 'take'), 'only the defender may act');
  ok(D.apply(st, { t: 'defend', idx: 0, card: 2 }, 1), 'defender beats');
  ok(st.stage === 'attack' && st.thrower === 0, 'attacker first to add');
  const l0 = D.legal(st, 0); ok(l0.some((m) => m.t === 'finish'), 'attacker may pass');
  ok(D.apply(st, { t: 'finish' }, 0) || true, 'attacker passes');
  ok(st.thrower === 2 || st.stage === 'defend', 'next thrower is seat 2 (or round ended)', { th: st.thrower, stg: st.stage });
}
{
  // defender takes: cards go to the defender, next attacker is the player AFTER the defender
  const st = D.create(4);
  const att = st.att, def = st.def, c = D.legal(st, att).find((m) => m.t === 'attack');
  D.apply(st, c, att); ok(st.stage === 'defend', 'defend stage');
  const hdef = st.hands[def].length;
  D.apply(st, { t: 'take' }, def); ok(st.taking || st.round === 2, 'taking (or nobody could add, so the round already ended)');
  let guard = 0; while (!st.over && st.round === 1 && guard++ < 50) { const w = D.actors(st)[0]; D.apply(st, D.auto(st, w), w); }
  ok(st.round === 2 && st.att === (def + 1) % 4, 'after a take the player left of the defender attacks', { att: st.att, def });
  ok(st.hands[def].length >= hdef + 1, 'defender holds the taken card(s)');
}
// the adapters
{
  const ad = A.byId.durak;
  ok(ad.seats[0] === 2 && ad.seats[1] === 6, 'durak seats 2-6');
  ok(A.byId.chess.seats[0] === 2 && A.byId.chess.seats[1] === 2, 'chess seats 2');
  const st = ad.init(5);
  const v = ad.view(st, 'c'), vs = ad.view(st, null);
  ok(v.hand.length === 6 && v.counts.length === 5 && vs.hand === null, 'view: own hand only');
  ok(!JSON.stringify(v).includes('"hands"'), 'view does not leak all hands');
  ok(ad.actors(st).length === 1 && 'abcde'.includes(ad.actors(st)[0]), 'actors are seat letters');
}
// the core: 4-player durak, one leaves, one times out, rest play on; winners are paid by mask
(async () => {
  const makeCore = require('../src/core');
  let t = 0; const core = makeCore({ now: () => t, sign: async (id, o) => 'sig:' + id + ':' + o });
  const P = ['0x' + 'a1'.repeat(20), '0x' + 'b2'.repeat(20), '0x' + 'c3'.repeat(20), '0x' + 'd4'.repeat(20)];
  for (let g = 0; g < 40; g++) {
    const id = 'g' + g; core.start(id, 'durak', P);
    const m = core.get(id); let guard = 0;
    while (!m.over && guard++ < 4000) {
      t += 500;
      if (guard === 7) await core.leave(id, P[1]);               // seat b leaves
      if (m.over) break;
      const a = m.actors[0]; const addr = P['abcd'.indexOf(a)];
      if (m.out.has(a)) { ok(false, 'an out player should never block the game'); break; }
      if (guard === 30 && !m.out.has('c') && a === 'c') { t += 61000; await core.tick(); continue; }   // seat c is too slow
      const l = core.view(id, addr).legal; if (!l.length) { ok(false, 'live actor without moves'); break; }
      const r = await core.move(id, addr, l[crypto.randomInt(0, l.length)]); ok(r.ok, 'move accepted', r);
    }
    ok(m.over && m.sig === 'sig:' + id + ':' + m.outcome, 'finished and signed ' + id, { why: m.why });
    ok(m.outcome > 0 && m.outcome < 16, 'outcome is a mask of 4 seats', m.outcome);
    ok(!(m.outcome & 2), 'the player who left (seat b) is never a winner', m.outcome);
    if (m.out.has('c')) ok(!(m.outcome & 4), 'the slow player never wins');
  }
  // everybody but one leaves -> the last wins at once
  core.start('z', 'durak', P.slice(0, 3)); await core.leave('z', P[0]); ok(!core.get('z').over, 'one of three left: play goes on');
  await core.leave('z', P[2]); ok(core.get('z').over && core.get('z').outcome === 2 && core.get('z').why === 'left', 'last player standing wins (seat b = mask 2)');
  // a refused table size
  let threw = false; try { core.start('y', 'durak', [P[0]]); } catch (e) { threw = true; } ok(threw, 'one player cannot start a durak');
  threw = false; try { core.start('x', 'chess', P.slice(0, 3)); } catch (e) { threw = true; } ok(threw, 'three players cannot start chess');
  threw = false; try { core.start('w', 'durak', [P[0], P[0]]); } catch (e) { threw = true; } ok(threw, 'same player twice refused');
  console.log(fails ? fails + ' FAILED' : 'ALL OK'); process.exit(fails ? 1 : 0);
})();
