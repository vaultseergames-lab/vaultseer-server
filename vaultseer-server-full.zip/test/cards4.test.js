'use strict';
const makeCore = require('../src/core');
const A = '0x' + 'a'.repeat(40), B = '0x' + 'b'.repeat(40), U = (x) => (x === 'a' ? A : B);
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log('FAIL', m); } else console.log('ok  ', m); };
(async () => {
  const core = makeCore({ sign: async (id, o) => 'sig' + o });
  for (const [game, n, hand] of [['gin', 40, 10], ['sixtysix', 60, 6], ['scopa', 40, 3]]) {
    core.start(game, game, A, B);
    const va = core.view(game, A), vb = core.view(game, B);
    ok(va.state.hand.length === hand && vb.state.hand.length === hand && JSON.stringify(va.state.hand) !== JSON.stringify(vb.state.hand), game + ': each player sees only own ' + hand + ' cards');
    ok(!JSON.stringify(va).includes(JSON.stringify(vb.state.hand)), game + ': B\'s cards are not in A\'s view');
    const mover = core.get(game).actors[0], other = mover === 'a' ? 'b' : 'a';
    ok((await core.move(game, U(other), core.view(game, U(mover)).legal[0])).err === 'not your turn', game + ': out of turn refused');
    ok((await core.move(game, U(mover), { t: 'play', card: 999, cap: [] })).err === 'illegal move', game + ': made-up move refused');
    const res = [0, 0, 0]; let deals = 0;
    for (let g = 0; g < n; g++) {
      const id = game + g; core.start(id, game, A, B);
      for (let i = 0; i < 20000 && !core.get(id).over; i++) {
        const who = U(core.get(id).actors[0]), l = core.view(id, who).legal;
        if (!l.length) { fails++; console.log('FAIL stuck', game, JSON.stringify(core.view(id, who).state).slice(0, 300)); break; }
        const r = await core.move(id, who, l[Math.floor(Math.random() * l.length)]); if (!r.ok) { fails++; console.log('FAIL', game, r.err); break; }
      }
      if (!core.get(id).over) { fails++; console.log('FAIL not finished', game); } else { res[core.get(id).outcome - 1]++; deals += core.get(id).st.deal; }
    }
    ok(res[0] + res[1] + res[2] === n, game + ': ' + n + ' random matches finished (A ' + res[0] + ' / B ' + res[1] + ' / draw ' + res[2] + ', avg ' + (deals / n).toFixed(1) + ' deals)');
  }
  console.log(fails ? fails + ' FAILED' : 'ALL OK'); process.exit(fails ? 1 : 0);
})();
