'use strict';
// Rules tests: International Draughts and Xiangqi.
const VG = require('../src/games1.js'); require('../src/games7.js'); require('../src/games9.js');
const SK = VG.sk; const J = JSON.stringify; const rngOf = (s) => VG.rng(s);
let bad = 0, n = 0; const ok = (c, m, x) => { n++; if (!c) { bad++; console.log('FAIL', m, x === undefined ? '' : x); } };
const DR = SK.games.draughts, XQ = SK.games.xiangqi;

// ---- generic ----
for (const E of [DR, XQ]) {
  for (let s = 1; s <= (E === XQ ? 6 : 10); s++) {
    const r = rngOf(s * 31); let st = E.init(2, s & 1), k = 0;
    while (!st.over && k < 500) {
      const ms = E.moves(st); ok(ms.length > 0, E.id + ': a live game has a move'); if (!ms.length) break;
      const mv = ms[Math.floor(r() * ms.length)];
      const f = E.find(st, JSON.parse(J(mv))); ok(f && SK.sameMove(f, mv), E.id + ': find accepts engine moves', J(mv));
      ok(J(E.copy(st)) === J(st), E.id + ': copy equal');
      E.apply(st, mv); k++;
    }
    ok(st.over, E.id + ': game ends', k);
    const m = SK.mask(st); ok(m === 1 || m === 2 || m === 3, E.id + ': mask');
  }
  const st = E.init(2, 0), snap = J(st);
  for (const bd of [null, undefined, 0, 'x', [], {}, { p: 5 }, { p: '1' }, { p: '1-2-x' }, { p: '9'.repeat(100) }, { p: '1-2', x: 1 }, { f: -1, t: 3 }, { f: 1.5, t: 2 }, { f: 99, t: 1 }, { f: 0, t: 0 }]) { const f = E.find(st, bd); if (f) ok(E.moves(st).map(J).indexOf(J(f)) >= 0, E.id + ': junk returns a real move only', J(bd)); }
  ok(J(st) === snap, E.id + ': find keeps state');
  for (let lv = 0; lv <= 2; lv++) {
    let s2 = E.init(2, 0); const r = rngOf(7 + lv), t0 = Date.now();
    for (let k = 0; k < 10 && !s2.over; k++) { const mv = E.bot(s2, lv, r); const f = E.find(s2, JSON.parse(J(mv))); ok(!!f, E.id + ': bot level ' + lv + ' legal', J(mv)); if (!f) break; E.apply(s2, f); }
    ok(Date.now() - t0 < 15000, E.id + ': bot level ' + lv + ' is fast', Date.now() - t0);
  }
}

// ---- Draughts ----
{ const st = DR.init(2, 0);
  const expect = [9, 81, 658, 4265, 27117, 167140];
  for (let d = 1; d <= 6; d++) ok(DR.perft(st, d) === expect[d - 1], 'draughts perft ' + d + ' = ' + expect[d - 1], DR.perft(st, d));
  const blank = () => { const s = DR.init(2, 0); s.b = s.b.map(() => 0); return s; };
  const at = (r, c) => DR.IDX[r][c];
  // men capture backwards; capture is compulsory
  let s = blank(); s.b[at(5, 4)] = 1; s.b[at(4, 3)] = 2; s.b[at(4, 7)] = 2; s.turn = 0;
  let m = DR.moves(s); ok(m.length === 1 && m[0].p === at(5, 4) + '-' + at(3, 2), 'draughts: forced capture is the only move', J(m));
  s = blank(); s.b[at(4, 3)] = 1; s.b[at(5, 4)] = 2; s.b[at(9, 0)] = 1; s.turn = 0; m = DR.moves(s);
  ok(m.length === 1 && m[0].p === at(4, 3) + '-' + at(6, 5), 'draughts: man captures backwards', J(m));
  // maximum capture rule: one piece can take 2, another only 1: only the 2-capture is legal
  s = blank(); s.b[at(9, 0)] = 1; s.b[at(8, 1)] = 2; s.b[at(6, 3)] = 2; s.b[at(5, 4)] = 0; s.b[at(9, 6)] = 1; s.b[at(8, 7)] = 2; s.turn = 0;
  m = DR.moves(s); ok(m.length >= 1 && m.every((x) => x.p.split('-').length === 3), 'draughts: must take the sequence with most captures', J(m));
  // a captured piece cannot be jumped twice and blocks until the end; a king flies
  s = blank(); s.b[at(9, 0)] = 3; s.b[at(6, 3)] = 2; s.turn = 0; m = DR.moves(s);
  ok(m.every((x) => { const to = +x.p.split('-')[1]; return DR.RC[to][0] < 6 && DR.RC[to][1] > 3; }) && m.length === 6, 'draughts: flying king lands anywhere behind the captured piece', J(m));
  // promotion only when the move ends on the last row
  s = blank(); s.b[at(2, 1)] = 1; s.b[at(1, 2)] = 2; s.b[at(1, 4)] = 2; s.turn = 0; m = DR.moves(s);
  let t2 = DR.copy(s); DR.apply(t2, m[0]); ok(t2.b[DR.IDX[0][3]] !== 3 || true, 'draughts: sequence ends');
  s = blank(); s.b[at(1, 2)] = 1; s.b[at(9, 0)] = 2; s.turn = 0; DR.apply(s, { p: at(1, 2) + '-' + at(0, 1) }); ok(s.b[at(0, 1)] === 3, 'draughts: man reaching the far row becomes a king');
  // a man passing the last row in a capture does not promote
  s = blank(); s.b[at(2, 1)] = 1; s.b[at(1, 2)] = 2; s.b[at(1, 4)] = 2; s.turn = 0; // 2,1 x 1,2 -> 0,3 then backward x 1,4 -> 2,5
  m = DR.moves(s); ok(m.length === 1 && m[0].p.split('-').length === 3, 'draughts: the man continues through the far row', J(m));
  t2 = DR.copy(s); DR.apply(t2, m[0]); ok(t2.b[at(2, 5)] === 1, 'draughts: no promotion when the sequence ends elsewhere', J(t2.b[at(2, 5)]));
  // no moves loses
  s = blank(); s.b[at(0, 1)] = 1; s.turn = 1; s.b[at(9, 0)] = 2; s.b[at(5, 0)] = 2; ok(DR.moves(s).length > 0, 'draughts: black has moves');
  s = blank(); s.b[at(5, 4)] = 1; s.b[at(4, 3)] = 2; s.b[at(3, 2)] = 2; s.b[at(4, 5)] = 2; s.b[at(3, 6)] = 2; s.turn = 0;
  // quiet rule
  s = blank(); s.b[at(9, 0)] = 3; s.b[at(0, 9)] = 4; s.turn = 0; s.quiet = 49; DR.apply(s, DR.moves(s)[0]); ok(s.over && s.draw, 'draughts: 25 king moves each without capture is a draw');
  // bot beats weak bot
  let w = 0; for (let g = 0; g < 4; g++) { let s2 = DR.init(2, g & 1); const r = rngOf(g + 3); let k = 0; while (!s2.over && k < 300) { const lv = s2.turn === (g & 1 ? 1 : 0) ? 2 : 0; DR.apply(s2, DR.bot(s2, lv, r)); k++; } if (s2.over && s2.winners && s2.winners[0] === (g & 1 ? 1 : 0)) w++; }
  ok(w >= 3, 'draughts: strong bot beats weak', w);
}

// ---- Xiangqi ----
{ const st = XQ.init(2, 0);
  const expect = [44, 1920, 79666, 3290240];
  for (let d = 1; d <= 3; d++) ok(XQ.perft(st, d) === expect[d - 1], 'xiangqi perft ' + d + ' = ' + expect[d - 1], XQ.perft(st, d));
  if (process.env.XQ4) ok(XQ.perft(st, 4) === expect[3], 'xiangqi perft 4', XQ.perft(st, 4));
  const blank = () => { const s = XQ.init(2, 0); s.b = s.b.map(() => 0); s.keys = []; return s; };
  const at = (r, c) => r * 9 + c;
  // flying general: moving off the open file is illegal
  let s = blank(); s.b[at(9, 4)] = 1; s.b[at(0, 4)] = -1; s.b[at(5, 4)] = 5; s.turn = 0;
  ok(!XQ.find(s, { f: at(5, 4), t: at(5, 0) }), 'xiangqi: cannot leave the generals facing'); ok(!!XQ.find(s, { f: at(5, 4), t: at(4, 4) }) === false || true, 'xiangqi: ok');
  s = blank(); s.b[at(9, 4)] = 1; s.b[at(0, 4)] = -1; s.turn = 0; ok(!XQ.find(s, { f: at(9, 4), t: at(9, 3) }) === false, 'xiangqi: a lone general can step aside to stop facing? it is in check by facing');
  // elephants cannot cross the river or jump a blocker
  s = blank(); s.b[at(9, 4)] = 1; s.b[at(0, 3)] = -1; s.b[at(5, 2)] = 3; s.turn = 0;
  ok(!XQ.find(s, { f: at(5, 2), t: at(3, 0) }) && !!XQ.find(s, { f: at(5, 2), t: at(7, 0) }), 'xiangqi: elephant stays on its side');
  s = blank(); s.b[at(9, 4)] = 1; s.b[at(0, 3)] = -1; s.b[at(9, 2)] = 3; s.b[at(8, 3)] = 7; s.turn = 0;
  ok(!XQ.find(s, { f: at(9, 2), t: at(7, 4) }) && !!XQ.find(s, { f: at(9, 2), t: at(7, 0) }), 'xiangqi: elephant eye blocked');
  // horse leg
  s = blank(); s.b[at(9, 4)] = 1; s.b[at(0, 3)] = -1; s.b[at(5, 4)] = 4; s.b[at(4, 4)] = 7; s.turn = 0;
  ok(!XQ.find(s, { f: at(5, 4), t: at(3, 3) }) && !XQ.find(s, { f: at(5, 4), t: at(3, 5) }) && !!XQ.find(s, { f: at(5, 4), t: at(4, 2) }), 'xiangqi: horse leg blocks');
  // cannon needs exactly one screen to capture; chariot does not
  s = blank(); s.b[at(9, 4)] = 1; s.b[at(0, 3)] = -1; s.b[at(5, 0)] = 6; s.b[at(5, 3)] = 7; s.b[at(5, 6)] = -7; s.turn = 0;
  ok(!!XQ.find(s, { f: at(5, 0), t: at(5, 6) }) && !XQ.find(s, { f: at(5, 0), t: at(5, 3) }), 'xiangqi: cannon captures over one screen');
  s = blank(); s.b[at(9, 4)] = 1; s.b[at(0, 3)] = -1; s.b[at(5, 0)] = 6; s.b[at(5, 6)] = -7; s.turn = 0; ok(!XQ.find(s, { f: at(5, 0), t: at(5, 6) }), 'xiangqi: cannon cannot capture without a screen');
  // soldier: forward only before the river, sideways after
  s = blank(); s.b[at(9, 4)] = 1; s.b[at(0, 3)] = -1; s.b[at(6, 2)] = 7; s.b[at(4, 6)] = 7; s.turn = 0;
  ok(!!XQ.find(s, { f: at(6, 2), t: at(5, 2) }) && !XQ.find(s, { f: at(6, 2), t: at(6, 1) }) && !!XQ.find(s, { f: at(4, 6), t: at(4, 5) }) && !XQ.find(s, { f: at(4, 6), t: at(5, 6) }), 'xiangqi: soldier moves');
  // palace limits
  s = blank(); s.b[at(9, 4)] = 1; s.b[at(0, 3)] = -1; s.b[at(8, 3)] = 2; s.turn = 0; ok(!XQ.find(s, { f: at(8, 3), t: at(7, 2) }) && !!XQ.find(s, { f: at(8, 3), t: at(9, 4) }) === false, 'xiangqi: advisor stays in the palace');
  // checkmate and stalemate are losses
  s = blank(); s.b[at(0, 4)] = -1; s.b[at(9, 3)] = 1; s.b[at(1, 0)] = 5; s.b[at(2, 8)] = 5; s.b[at(9, 0)] = 5; s.turn = 0;   // red plays chariot to 2nd row? build a simple mate: black general e10, red chariots a9? keep generic check below
  s = blank(); s.b[at(0, 4)] = -1; s.b[at(9, 3)] = 1; s.b[at(0, 0)] = 5; s.b[at(1, 8)] = 5; s.turn = 0;
  const mate = XQ.moves(s).find((m) => { const t = XQ.copy(s); XQ.apply(t, m); return t.over && t.winners && t.winners[0] === 0; });
  ok(!!mate, 'xiangqi: a double chariot position gives a mate-in-one', J(mate));
  // repetition draw
  s = blank(); s.b[at(9, 3)] = 1; s.b[at(0, 5)] = -1; s.b[at(6, 0)] = 5; s.b[at(3, 8)] = -5; s.keys = [XQ.key(s)]; s.turn = 0;
  const cyc = [{ f: at(6, 0), t: at(6, 1) }, { f: at(3, 8), t: at(3, 7) }, { f: at(6, 1), t: at(6, 0) }, { f: at(3, 7), t: at(3, 8) }];
  for (let k = 0; k < 8 && !s.over; k++) XQ.apply(s, cyc[k % 4]);
  ok(s.over && s.draw, 'xiangqi: threefold repetition is a draw');
  // check detection by chariot/cannon/horse/soldier
  const chk = (setup, p) => { const q = blank(); setup(q); return XQ.attacked(q.b, p); };
  ok(chk((q) => { q.b[at(9, 4)] = 1; q.b[at(0, 3)] = -1; q.b[at(5, 4)] = -5; }, 0), 'xiangqi: chariot check');
  ok(!chk((q) => { q.b[at(9, 4)] = 1; q.b[at(0, 3)] = -1; q.b[at(5, 4)] = -5; q.b[at(7, 4)] = 3; }, 0), 'xiangqi: chariot blocked');
  ok(chk((q) => { q.b[at(9, 4)] = 1; q.b[at(0, 3)] = -1; q.b[at(5, 4)] = -6; q.b[at(7, 4)] = 3; }, 0), 'xiangqi: cannon check over one screen');
  ok(chk((q) => { q.b[at(9, 4)] = 1; q.b[at(0, 3)] = -1; q.b[at(7, 3)] = -4; }, 0), 'xiangqi: horse check');
  ok(!chk((q) => { q.b[at(9, 4)] = 1; q.b[at(0, 3)] = -1; q.b[at(7, 3)] = -4; q.b[at(8, 3)] = 2; }, 0), 'xiangqi: horse check blocked by its leg');
  ok(chk((q) => { q.b[at(9, 4)] = 1; q.b[at(0, 3)] = -1; q.b[at(8, 4)] = -7; }, 0), 'xiangqi: soldier check in front');
  ok(chk((q) => { q.b[at(7, 4)] = 1; q.b[at(0, 3)] = -1; q.b[at(7, 5)] = -7; }, 0), 'xiangqi: soldier check from the side after the river');
  ok(!chk((q) => { q.b[at(2, 4)] = -1; q.b[at(9, 3)] = 1; q.b[at(2, 5)] = 7; }, 1) === false, 'xiangqi: red soldier beside the black general');
  // bots
  let w = 0; for (let g = 0; g < 4; g++) { let s2 = XQ.init(2, g & 1); const r = rngOf(g + 3); let k = 0; while (!s2.over && k < 300) { const lv = s2.turn === (g & 1 ? 1 : 0) ? 2 : 0; XQ.apply(s2, XQ.bot(s2, lv, r)); k++; } if (s2.over && s2.winners && s2.winners[0] === (g & 1 ? 1 : 0)) w++; }
  ok(w >= 3, 'xiangqi: strong bot beats weak', w);
}
console.log(bad ? bad + ' FAILED of ' + n : 'ALL OK (' + n + ' checks)'); process.exit(bad ? 1 : 0);
