'use strict';
// Full matches through the server core for every skill game: random legal moves, time-out, leave.
const makeCore = require('../src/core.js'); const { byId } = require('../src/adapters.js'); const VG = require('../src/games1.js');
let bad = 0, n = 0; const ok = (c, m) => { n++; if (!c) { bad++; console.log('FAIL', m); } };
const A = '0x' + 'a'.repeat(40), B = '0x' + 'b'.repeat(40);
(async () => {
  for (const g of VG.sk.list) {
    const ad = byId[g]; ok(!!ad, g + ' adapter'); if (!ad) continue;
    let t = 1000; const core = makeCore({ now: () => t, sign: async (id, o) => 'S' + o });
    const m = core.start('m' + g, g, A, B); const r = VG.rng(5); let k = 0;
    ok(ad.view(m.st, 'a').turn !== undefined, g + ' view');
    while (!m.over && k++ < 2000) {
      const E = VG.sk.games[g], who = m.actors[0], addr = who === 'a' ? A : B;
      const mv = E.moves(m.st); const pick = mv[Math.floor(r() * mv.length)];
      const res = await core.move('m' + g, addr, JSON.parse(JSON.stringify(pick)));
      ok(res.ok, g + ' legal move accepted');
      if (!res.ok) break;
      const wrong = await core.move('m' + g, addr === A ? A : A, { c: -5 }); // junk never accepted
      ok(!wrong.ok, g + ' junk refused');
    }
    ok(m.over && (m.outcome === 1 || m.outcome === 2 || m.outcome === 3), g + ' match ends with a result ' + m.outcome + ' after ' + k);
    const m2 = core.start('x' + g, g, A, B);
    const l = await core.leave('x' + g, A); ok(m2.over && m2.outcome === 2, g + ' leaving loses');
    const m3 = core.start('y' + g, g, A, B); t += 10 * 60000; await core.tick('y' + g);
    ok(m3.over || m3.out.size > 0, g + ' timeout: player dropped or auto-moved');
  }
  console.log(bad ? bad + ' FAILED of ' + n : 'ALL OK (' + n + ' checks)'); process.exit(bad ? 1 : 0);
})();
