'use strict';
// Slot duel and roulette: fairness, verification, core integration (spins, timeouts, leaving, signing).
const crypto = require('crypto');
const VG = require('../src/games1.js'); require('../src/games5.js');
const CH = VG.chance;
const M = require('../src/m_chance.js');
const A = require('../src/adapters.js');
const makeCore = require('../src/core');
let fails = 0, checks = 0; const ok = (c, m, x) => { checks++; if (!c) { fails++; if (fails < 40) console.log('FAIL', m, x === undefined ? '' : JSON.stringify(x)); } };
const seed = () => crypto.randomBytes(8).toString('hex');
const P = (n) => Array.from({ length: n }, (_, i) => '0x' + (i + 1).toString(16).padStart(2, '0').repeat(20));
const S = 'abcdefghi';

(async () => {
  // ---- registered with the right table sizes ----
  ok(A.byId.slots && A.byId.slots.seats[0] === 2 && A.byId.slots.seats[1] === 2, 'slots: exactly 2 seats');
  ok(A.byId.roulette && A.byId.roulette.seats[0] === 2 && A.byId.roulette.seats[1] === 9, 'roulette: 2 to 9 seats');
  ok(require('../src/chain.js').GAME_IDS[13] === 'slots' && require('../src/chain.js').GAME_IDS[14] === 'roulette', 'game ids 13 and 14 match the contract');

  // ---- pure helpers ----
  ok(CH.score([6, 6, 6]) > CH.score([6, 6, 5]) && CH.score([0, 0, 0]) > CH.score([6, 6, 5]), 'three of a kind beats any pair');
  ok(CH.score([0, 0, 1]) > CH.score([6, 5, 4]), 'a pair beats high card');
  ok(CH.score([3, 3, 1]) === CH.score([1, 3, 3]) && CH.score([3, 3, 1]) === CH.score([3, 1, 3]), 'order of reels does not matter for the score');
  ok(CH.score([4, 4, 2]) > CH.score([3, 3, 6]), 'higher pair wins');
  ok(CH.score([4, 4, 2]) > CH.score([4, 4, 1]), 'same pair, higher kicker wins');
  ok(CH.score([6, 5, 1]) > CH.score([6, 4, 3]), 'high card: compare in order');
  ok(CH.kind([2, 2, 2]) === 'three' && CH.kind([2, 2, 1]) === 'pair' && CH.kind([3, 2, 1]) === 'high', 'combination names');
  const mx = CH.mix('abc', 1, ['11111111', '22222222']);
  ok(mx === CH.mix('abc', 1, ['11111111', '22222222']) && mx !== CH.mix('abc', 2, ['11111111', '22222222']) && mx !== CH.mix('abd', 1, ['11111111', '22222222']) && mx !== CH.mix('abc', 1, ['11111111', '22222223']), 'the result depends on the nonce, the round and every seed');
  ok(CH.okSeed('0123abcd') && !CH.okSeed('xyz') && !CH.okSeed('0123ABCD') && !CH.okSeed(5) && !CH.okSeed('1234567') && !CH.okSeed('a'.repeat(33)), 'seed format');
  for (let n = 2; n <= 9; n++) { ok(CH.pockets(n) === n * 6, 'pockets'); const cnt = Array(n).fill(0); for (let p = 0; p < CH.pockets(n); p++) cnt[CH.owner(p, n)]++; ok(cnt.every((c) => c === 6), 'every player owns the same number of pockets', { n, cnt }); }

  // ---- fairness by simulation ----
  { const N = 40000, wins = [0, 0], tie = { c: 0 };
    for (let i = 0; i < N; i++) { const mix = CH.mix(crypto.randomBytes(8).toString('hex'), 1, [seed(), seed()]); const sc = [0, 1].map((s) => CH.score(CH.reels(mix, s))); if (sc[0] === sc[1]) tie.c++; else wins[sc[0] > sc[1] ? 0 : 1]++; }
    const d = Math.abs(wins[0] - wins[1]) / (wins[0] + wins[1]);
    ok(d < 0.03, 'slots: both seats win equally often', { wins, d }); ok(tie.c / N > 0.003 && tie.c / N < 0.25, 'slots: ties are not too rare nor too common', tie.c / N); }
  for (const n of [2, 3, 5, 7, 9]) { const N = 30000, cnt = Array(n).fill(0);
    for (let i = 0; i < N; i++) cnt[CH.owner(CH.pocket(CH.mix(crypto.randomBytes(8).toString('hex'), 1, Array.from({ length: n }, seed)), n), n)]++;
    const exp = N / n, worst = Math.max(...cnt.map((c) => Math.abs(c - exp) / exp)); ok(worst < 0.07, 'roulette ' + n + ' players: every seat wins about 1/n', { cnt, worst }); }
  // symbols are all reachable and about uniform
  { const cnt = Array(7).fill(0); for (let i = 0; i < 21000; i++) CH.reels(crypto.randomBytes(8).toString('hex'), 0).forEach((x) => cnt[x]++); ok(cnt.every((c) => Math.abs(c - 9000) < 450), 'every symbol appears about equally often', cnt); }

  // ---- engine: commitments and the reveal ----
  for (const [kind, n] of [['slots', 2], ['roulette', 2], ['roulette', 5], ['roulette', 9]]) {
    const st = M.create(kind, n), v0 = M.view(st);
    ok(v0.commit === CH.commit(st.nonce) && v0.nonce === null && !JSON.stringify(v0).includes(st.nonce), kind + n + ': the commitment is shown, the nonce is not');
    ok(M.actors(st).length === n && M.legal(st).length === 1, 'everybody may spin');
    ok(!M.find(st, { t: 'spin' }) && !M.find(st, { t: 'spin', seed: 'zz' }) && !M.find(st, { t: 'draw', seed: seed() }) && M.find(st, { t: 'spin', seed: seed() }), 'only a spin with a good seed is accepted');
    let guard = 0; while (!st.over && guard++ < 20) M.apply(st, Object.fromEntries(Array.from({ length: n }, (_, i) => [S[i], { t: 'spin', seed: seed() }])));
    ok(st.over && st.winners.length >= 1, kind + n + ': ends');
    const v = M.view(st); ok(v.nonce === st.nonce && CH.commit(v.nonce) === v.commit, 'after the game the nonce matches the commitment');
    // recompute every row from the public data only
    for (const r of v.rows) { const mix = CH.mix(v.nonce, r.round, r.seeds);
      if (kind === 'roulette') { const pk = CH.pocket(mix, n); ok(pk === r.pocket && CH.owner(pk, n) === r.owner && S[r.owner] === v.winners[0], 'roulette result can be recomputed'); }
      else { const rl = [0, 1].map((s) => CH.reels(mix, s)); ok(JSON.stringify(rl) === JSON.stringify(r.reels) && JSON.stringify(rl.map(CH.score)) === JSON.stringify(r.scores), 'slot reels can be recomputed'); } }
  }

  // ---- the browser-side check (CH.verify) accepts the real thing and rejects every kind of tampering ----
  { const r = M.create('roulette', 3); ok(CH.verify('roulette', 3, M.view(r)) === null, 'nothing to verify before the game ends');
    M.apply(r, { a: { t: 'spin', seed: seed() }, b: { t: 'spin', seed: seed() }, c: { t: 'spin', seed: seed() } });
    const v = M.view(r); ok(CH.verify('roulette', 3, v) === true, 'verify accepts a real roulette game');
    const t1 = JSON.parse(JSON.stringify(v)); t1.rows[0].pocket = (t1.rows[0].pocket + 1) % 18; t1.rows[0].owner = t1.rows[0].pocket % 3; ok(CH.verify('roulette', 3, t1) === false, 'verify rejects a changed pocket');
    const t2 = JSON.parse(JSON.stringify(v)); t2.rows[0].seeds[0] = '00000000'; ok(CH.verify('roulette', 3, t2) === false || t2.rows[0].seeds[0] === v.rows[0].seeds[0], 'verify rejects a changed seed');
    const t3 = JSON.parse(JSON.stringify(v)); t3.nonce = 'f'.repeat(32); ok(CH.verify('roulette', 3, t3) === false, 'verify rejects a nonce that does not match the commitment');
    const s2 = M.create('slots', 2); let g = 0; while (!s2.over && g++ < 20) M.apply(s2, { a: { t: 'spin', seed: seed() }, b: { t: 'spin', seed: seed() } });
    const sv = M.view(s2); ok(CH.verify('slots', 2, sv) === true, 'verify accepts a real slot duel');
    const t4 = JSON.parse(JSON.stringify(sv)); t4.rows[0].reels[0][0] = (t4.rows[0].reels[0][0] + 1) % 7; ok(CH.verify('slots', 2, t4) === false, 'verify rejects changed reels'); }

  // ---- slots rules ----
  { const st = M.create('slots', 2); let r = 0;
    while (!st.over && r++ < 20) M.apply(st, { a: { t: 'spin', seed: seed() }, b: { t: 'spin', seed: seed() } });
    ok(st.over && (st.wins[0] === 2 || st.wins[1] === 2 || st.rows.length === 8), 'slots: first to two rounds (or the round limit)');
    ok(st.rows.every((x, i) => x.round === i + 1), 'round numbers go up by one, a level round is replayed with a new round number');
    ok(st.wins[0] + st.wins[1] === st.rows.filter((x) => x.winner >= 0).length, 'wins = rounds that were not level');
    if (st.wins[0] !== st.wins[1]) ok(st.winners.length === 1 && st.winners[0] === (st.wins[0] > st.wins[1] ? 0 : 1), 'the one with more rounds wins'); }
  { // after 8 rounds that all end level the duel is a draw: force it
    const st = M.create('slots', 2); st.rows = Array.from({ length: 7 }, (_, i) => ({ round: i + 1, winner: -1 })); st.round = 8; st.wins = [1, 1];
    let k = 0, done = false; while (!done && k++ < 5000) { const probe = JSON.parse(JSON.stringify(st)); M.apply(probe, { a: { t: 'spin', seed: seed() }, b: { t: 'spin', seed: seed() } }); if (probe.rows[probe.rows.length - 1].winner === -1) { Object.assign(st, probe); done = true; } }
    ok(done && st.over && st.winners.length === 2 && M.result(st) === 3, 'eight rounds without a decision is a draw (both bits)', { done, winners: st.winners }); }

  // ---- inside the match manager ----
  let t = 1000000; const sig = async (id, o) => 'sig:' + id + ':' + o;
  const core = makeCore({ now: () => t, sign: sig });
  // slots duel through the core
  { const p = P(2); core.start('s1', 'slots', p); const m = core.get('s1');
    const v = core.view('s1', p[0]); ok(v.state.nonce === null && v.legal.length === 1 && v.actors.length === 2, 'slots start: both may spin');
    const bad = await core.move('s1', p[0], { t: 'spin' }); ok(!bad.ok, 'a spin without a seed is illegal');
    const r1 = await core.move('s1', p[0], { t: 'spin', seed: seed() }); ok(r1.ok && r1.waiting, 'first spin waits for the other player');
    const w0 = core.view('s1', p[0]); ok(w0.waiting && w0.state.rows.length === 0, 'no result before both have spun');
    const again = await core.move('s1', p[0], { t: 'spin', seed: seed() }); ok(!again.ok, 'cannot spin twice in a round');
    const r2 = await core.move('s1', p[1], { t: 'spin', seed: seed() }); ok(r2.ok, 'second spin completes the round');
    ok(core.view('s1', p[0]).state.rows.length === 1, 'the round result is visible to both');
    let g = 0; while (!m.over && g++ < 12) { await core.move('s1', p[0], { t: 'spin', seed: seed() }); await core.move('s1', p[1], { t: 'spin', seed: seed() }); }
    ok(m.over && m.sig && (m.outcome === 1 || m.outcome === 2 || m.outcome === 3), 'slots match is over and signed', { o: m.outcome, sig: m.sig });
    const fv = core.view('s1', p[1]); ok(CH.commit(fv.state.nonce) === fv.state.commit, 'verification data is in the final view'); }
  // roulette through the core for 2..9
  for (let n = 2; n <= 9; n++) { const p = P(n), id = 'r' + n; core.start(id, 'roulette', p); const m = core.get(id);
    for (let i = 0; i < n; i++) { const r = await core.move(id, p[i], { t: 'spin', seed: seed() }); ok(r.ok, 'spin ok'); if (i < n - 1) ok(!m.over, 'waits for everybody'); }
    ok(m.over && m.sig, 'roulette ' + n + ' finished and signed');
    const bits = m.outcome.toString(2).split('1').length - 1; ok(bits === 1, 'exactly one winner', m.outcome);
    const v = core.view(id, p[0]).state, pk = v.rows[0].pocket; ok(pk >= 0 && pk < n * 6 && v.winners.length === 1, 'pocket in range'); }
  // a player who does not spin in time is out; the others still get a fair result
  { const p = P(4); core.start('rt', 'roulette', p); const m = core.get('rt');
    for (let i = 0; i < 3; i++) await core.move('rt', p[i], { t: 'spin', seed: seed() });
    t += 31000; await core.tick(); ok(m.over && m.sig, 'timeout: the wheel still turns for the rest');
    ok((m.outcome & 8) === 0 && m.outcome !== 0, 'the player who timed out cannot win', m.outcome); }
  { const p = P(2); core.start('lv', 'slots', p); await core.leave('lv', p[0]); const m = core.get('lv'); ok(m.over && m.outcome === 2, 'leaving a slot duel gives the win to the other player'); }
  { const p = P(5); core.start('lv5', 'roulette', p); await core.leave('lv5', p[4]); const m = core.get('lv5'); ok(!m.over, 'one player leaving a roulette table does not end it'); 
    for (let i = 0; i < 4; i++) await core.move('lv5', p[i], { t: 'spin', seed: seed() });
    ok(m.over && (m.outcome & 16) === 0 && m.outcome !== 0, 'the one who left cannot win'); }
  // everybody times out -> draw
  { const p = P(3); core.start('all', 'roulette', p); t += 31000; await core.tick(); const m = core.get('all'); ok(m.over && m.outcome === 7, 'nobody spins: draw, everybody gets the stake back', m.outcome); }
  // wrong player count
  { let e = null; try { core.start('bad1', 'slots', P(3)); } catch (x) { e = x; } ok(e, 'slots refuses 3 players'); e = null; try { core.start('bad2', 'roulette', P(10)); } catch (x) { e = x; } ok(e, 'roulette refuses 10 players'); }

  console.log(fails ? 'FAILED ' + fails + ' of ' + checks : 'chance tests passed: ' + checks);
  process.exit(fails ? 1 : 0);
})();
