'use strict';
const makeCore = require('../src/core');
const A = '0x' + 'a'.repeat(40), B = '0x' + 'b'.repeat(40);
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log('FAIL', m); } else console.log('ok  ', m); };
(async () => {
  const core = makeCore({ sign: async (id, o) => 'sig' + o });
  core.start(1, 'backgammon', A, B);
  const v = core.view(1, core.get(1).actors[0] === 'a' ? A : B);
  ok(v.state.dice.length === 2 && v.state.opening && v.state.opening[0] !== v.state.opening[1], 'opening roll: different dice, the higher starts');
  ok(v.legal.length > 0, 'the starter has legal moves');
  const other = core.get(1).actors[0] === 'a' ? B : A;
  ok((await core.move(1, other, { t: 'move', o: 24, d: 1 })).err === 'not your turn', 'wrong player refused');
  ok((await core.move(1, core.get(1).actors[0] === 'a' ? A : B, { t: 'move', o: 3, d: 6 })).err === 'illegal move', 'illegal move refused');
  let wins = [0, 0], doubles = 0, steps = 0;
  for (let g = 0; g < 60; g++) {
    const id = 10 + g; core.start(id, 'backgammon', A, B);
    for (let i = 0; i < 4000 && !core.get(id).over; i++) {
      const who = core.get(id).actors[0] === 'a' ? A : B, l = core.view(id, who).legal;
      if (!l.length) { fails++; console.log('FAIL stuck', JSON.stringify(core.view(id, who).state.dice)); break; }
      const r = await core.move(id, who, l[Math.floor(Math.random() * l.length)]); steps++;
      if (!r.ok) { fails++; console.log('FAIL', r.err); break; }
    }
    if (!core.get(id).over) { fails++; console.log('FAIL game not finished'); } else wins[core.get(id).outcome - 1]++;
  }
  ok(wins[0] + wins[1] === 60, 'backgammon: 60 random games finished (' + wins.join(' / ') + ', ' + steps + ' moves)');
  const st = core.get(10).st; ok(st.off[0] === 15 || st.off[1] === 15, 'winner has borne off 15 checkers');
  console.log(fails ? fails + ' FAILED' : 'ALL OK'); process.exit(fails ? 1 : 0);
})();
