'use strict';
const crypto = require('crypto');
const D = require('../src/m_domino.js');
const A = require('../src/adapters.js');
let fails = 0; const ok = (c, m, x) => { if (!c) { fails++; if (fails < 40) console.log('FAIL', m, x === undefined ? '' : JSON.stringify(x)); } };
const count = (st) => st.yard.length + st.hands.reduce((a, h) => a + h.length, 0) + st.chain.length;
let blocked = 0, emptied = 0, ties = 0;
for (let n = 2; n <= 4; n++) for (let g = 0; g < 400; g++) {
  const st = D.create(n); let moves = 0;
  ok(count(st) === 28, 'tiles conserved at start'); ok(st.yard.length === 28 - 7 * n, 'boneyard size');
  const all = st.hands.flat().concat(st.yard, st.chain.map((c) => c.t)).map((t) => t.slice().sort().join(''));
  ok(new Set(all).size === 28, 'all 28 tiles distinct');
  while (!st.over && moves < 400) {
    const who = D.actors(st)[0], l = D.legal(st, who); ok(l.length > 0, 'actor always has a move');
    for (let s = 0; s < n; s++) if (s !== who) ok(D.legal(st, s).length === 0, 'only the actor moves');
    const mv = l[crypto.randomInt(0, l.length)]; ok(D.find(st, mv, who), 'found'); ok(D.apply(st, mv), 'applied'); moves++;
    ok(count(st) === 28, 'tiles conserved');
    // chain is a valid line of dominoes
    for (let i = 1; i < st.chain.length; i++) if (st.chain[i - 1].t[1] !== st.chain[i].t[0]) ok(false, 'chain broken', st.chain.map((c) => c.t));
  }
  ok(st.over && st.winners.length >= 1, 'ends with winners', { n, moves });
  if (st.why === 'empty') { emptied++; ok(st.hands[st.winners[0]].length === 0, 'empty-hand winner'); } else { blocked++; const p = st.hands.map(D.pips); ok(st.winners.every((w) => p[w] === Math.min(...p)), 'blocked: lowest pips win'); if (st.winners.length > 1) ties++; }
}
console.log('domino playouts: emptied', emptied, 'blocked', blocked, 'ties', ties);
{ // hand-built blocked game with a tie: 3 players
  const st = D.create(3);
  st.hands = [[[0, 1]], [[0, 2]], [[1, 0]]]; st.yard = []; st.chain = [{ t: [6, 6], by: 0 }]; st.ends = [6, 6]; st.turn = 0; st.passes = 0; st.over = false;
  D.apply(st, { t: 'pass' }); D.apply(st, { t: 'pass' }); D.apply(st, { t: 'pass' });
  ok(st.over && st.why === 'blocked' && st.winners.join() === '0,2', 'blocked: seats 0 and 2 tie on 1 pip', st.winners);
  ok(A.byId.domino.result(st, 0) === 5, 'mask 0b101 for seats a and c');
}
{ const ad = A.byId.domino; ok(ad.seats[1] === 4, 'domino seats 2-4'); const st = ad.init(4); const v = ad.view(st, 'b'); ok(v.hand.length === 7 || v.hand.length === 6, 'own hand'); ok(!JSON.stringify(v).includes('"hands"') && v.pips === null, 'others hidden'); }
console.log(fails ? fails + ' FAILED' : 'ALL OK'); process.exit(fails ? 1 : 0);
