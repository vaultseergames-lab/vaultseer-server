'use strict';
const P = require('../src/events_providers.js');
let pass = 0, fail = 0; const ok = (c, m, x) => { if (c) pass++; else { fail++; console.log('FAIL', m, x === undefined ? '' : x); } };
let T = Date.parse('2026-10-24T12:00:00Z'), calls = [];
const mk = (routes) => async (url, o) => { calls.push(url); for (const [re, body] of routes) if (re.test(url)) return { ok: true, status: 200, json: async () => (typeof body === 'function' ? body(url, o) : body) }; return { ok: false, status: 404, json: async () => ({}) }; };
(async () => {
  const k = Math.floor(T / 1000) + 7200;
  const m = (id, over = {}) => Object.assign({ id, utcDate: new Date(k * 1000).toISOString(), status: 'SCHEDULED', competition: { name: 'Premier League' }, homeTeam: { name: 'Arsenal FC', shortName: 'Arsenal' }, awayTeam: { name: 'Chelsea FC', shortName: 'Chelsea' }, score: { duration: 'REGULAR', fullTime: { home: null, away: null } } }, over);
  let finished = m(101, { status: 'FINISHED', score: { duration: 'REGULAR', fullTime: { home: 3, away: 1 } } });
  const fd = P.footballData({ key: 'K', now: () => T, fetchFn: mk([[/\/matches\?dateFrom/, { matches: [m(101), m(102, { homeTeam: null }), { id: 'x' }] }], [/\/matches\/101/, () => finished]]) });
  const l = await fd.list(k - 1000, k + 1000);
  ok(l.length === 1 && l[0].id === '101' && l[0].home === 'Arsenal' && l[0].league === 'Premier League' && l[0].kickoff === k, 'football-data: only complete matches listed', l);
  ok(calls[0].includes('dateFrom=2026-10-24'), 'date range in request');
  let r = await fd.result(l[0]); ok(r.final && r.value === 2, 'finished 3-1 -> +2', r);
  finished = m(101, { status: 'IN_PLAY' }); T += 9 * 60e3; r = await fd.result(l[0]); ok(!r.final, 'in play -> not final');
  finished = m(101, { status: 'FINISHED', score: { duration: 'EXTRA_TIME', fullTime: { home: 3, away: 2 }, regularTime: { home: 2, away: 2 } } }); T += 9 * 60e3; r = await fd.result(l[0]);
  ok(r.final && r.value === 0, 'extra time: regular-time score used (2-2 -> 0)', r);
  finished = m(101, { status: 'FINISHED', score: { duration: 'PENALTY_SHOOTOUT', fullTime: { home: 3, away: 2 } } }); T += 9 * 60e3; r = await fd.result(l[0]); ok(r === null, 'no regular-time score: no answer');
  finished = m(101, { status: 'FINISHED', score: { duration: 'REGULAR', fullTime: { home: -1, away: 2 } } }); T += 9 * 60e3; r = await fd.result(l[0]); ok(r === null, 'nonsense score refused');
  finished = m(999, { status: 'FINISHED' }); T += 9 * 60e3; r = await fd.result(l[0]); ok(!r.final, 'answer for another match refused');
  // cache: two lists within 30 minutes make one request
  calls = []; await fd.list(k - 1000, k + 1000); await fd.list(k - 1000, k + 1000); ok(calls.length <= 1, 'list answers are cached', calls);

  // API-Sports basketball
  const g = (id, st, h, a) => ({ id, timestamp: k, status: { short: st }, league: { name: 'NBA' }, teams: { home: { name: 'Lakers' }, away: { name: 'Celtics' } }, scores: { home: { total: h }, away: { total: a } } });
  let games = [g(7, 'NS', null, null)];
  const nb = P.nba({ key: 'K', now: () => T, fetchFn: mk([[/basketball\.api-sports\.io\/games/, () => ({ response: games })]]) });
  const nl = await nb.list(Math.floor(T / 1000), Math.floor(T / 1000) + 86400);
  ok(nl.length === 1 && nl[0].id === '7' && nl[0].home === 'Lakers', 'nba listed once even when asked for several days', nl.length);
  games = [g(7, 'AOT', 121, 118)]; T += 11 * 60e3; r = await nb.result(nl[0]); ok(r.final && r.value === 3, 'overtime final counts', r);
  games = [g(7, 'Q3', 80, 70)]; T += 11 * 60e3; r = await nb.result(nl[0]); ok(!r.final, 'live game not final');
  games = [g(7, 'FT', null, 70)]; T += 11 * 60e3; r = await nb.result(nl[0]); ok(r === null, 'missing score -> no answer');
  games = []; T += 11 * 60e3; r = await nb.result(nl[0]); ok(!r.final, 'game missing from answer -> not final');
  // American football nests the game; hockey has plain numbers
  const nf = P.nfl({ key: 'K', now: () => T, fetchFn: mk([[/american-football/, { response: [{ game: { id: 55, date: { timestamp: k }, status: { short: 'FT' } }, league: { name: 'NFL' }, teams: { home: { name: 'A' }, away: { name: 'B' } }, scores: { home: { total: 27 }, away: { total: 30 } } }] }]]) });
  const fl = await nf.list(Math.floor(T / 1000), Math.floor(T / 1000)); r = await nf.result(fl[0]); ok(fl.length === 1 && r.final && r.value === -3, 'nfl nested shape, negative difference', [fl, r]);
  const nh = P.nhl({ key: 'K', now: () => T, fetchFn: mk([[/hockey/, { response: [{ id: 9, timestamp: k, status: { short: 'AP' }, league: { name: 'NHL' }, teams: { home: { name: 'A' }, away: { name: 'B' } }, scores: { home: 4, away: 3 } }] }]]) });
  const hl = await nh.list(Math.floor(T / 1000), Math.floor(T / 1000)); r = await nh.result(hl[0]); ok(r.final && r.value === 1, 'nhl plain numbers, shootout final', r);
  // bad shapes and daily cap
  const bad = P.nba({ key: 'K', now: () => T, fetchFn: mk([[/basketball/, { oops: 1 }]]) });
  let err = null; try { await bad.list(Math.floor(T / 1000), Math.floor(T / 1000) + 86400); } catch (e) { err = e.message; } ok(/unexpected/.test(err || ''), 'unexpected answer for a future day is an error', err);
  const cap = P.makeHttp({ fetchFn: mk([[/./, { a: 1 }]]), now: () => T, dailyCap: 3 });
  for (let i = 0; i < 3; i++) await cap('http://x/' + i, {}, 0);
  err = null; try { await cap('http://x/9', {}, 0); } catch (e) { err = e.message; } ok(/cap/.test(err || ''), 'daily request cap stops calls', err);
  console.log((fail ? 'FAIL ' : 'PASS ') + pass + ' checks, ' + fail + ' failed'); process.exit(fail ? 1 : 0);
})().catch((e) => { console.log('CRASH', e.stack); process.exit(1); });
