'use strict';
const crypto = require('crypto');
const S = require('../src/m_scopa.js');
const A = require('../src/adapters.js');
let fails = 0; const ok = (c, m, x) => { if (!c) { fails++; if (fails < 40) console.log('FAIL', m, x === undefined ? '' : JSON.stringify(x)); } };
const all = (st) => st.deck.length + st.table.length + st.hands.reduce((a, h) => a + h.length, 0) + st.cap.reduce((a, c) => a + c.length, 0);
let deals = 0, games = 0, teamWins = 0;
for (let n = 2; n <= 4; n++) for (let g = 0; g < 120; g++) {
  const st = S.create(n); let moves = 0, lastDeal = st.deal;
  while (!st.over && moves < 3000) {
    ok(all(st) === 40, 'cards conserved', { n, all: all(st) });
    const who = S.actors(st)[0], l = S.legal(st, who); ok(l.length > 0, 'actor has a move');
    for (let s = 0; s < n; s++) if (s !== who) ok(S.legal(st, s).length === 0, 'only the actor moves');
    const mv = l[crypto.randomInt(0, l.length)]; ok(S.find(st, mv, who), 'found');
    const before = st.table.length, handc = st.hands[who].length;
    ok(S.apply(st, mv), 'applied'); moves++;
    if (st.deal !== lastDeal) { lastDeal = st.deal; deals++; const ld = st.lastDeal; ok(ld.gain.length === st.ents.length, 'gain per entity'); ok(ld.counts.reduce((a, b) => a + b, 0) === 40, 'all 40 cards counted at deal end', ld.counts); }
  }
  ok(st.over && st.winners.length >= 1, 'game ends', { n, moves }); games++;
  const top = Math.max(...st.scores); ok(st.winners.every((s) => st.scores[S.entOf(n, s)] === top), 'winners have the top score');
  if (n === 4 && st.winners.length === 2) teamWins++;
}
console.log('scopa playouts:', games, 'games,', deals, 'deals; 4-player team wins', teamWins);
{ // rules on a fixed table: the same value must be taken; sums otherwise
  const st = S.create(2); st.over = false; st.turn = 0;
  const c = (v, su) => su * 10 + v - 1;        // value v (1..10), suit su
  st.hands = [[c(7, 0), c(3, 1), c(10, 3)], [c(1, 0), c(2, 0), c(3, 0)]]; st.table = [c(7, 1), c(4, 2), c(3, 3), c(5, 0)]; st.deck = [];
  let opts = S.options(st, 0, 0); ok(JSON.stringify(opts) === '[[0]]', 'a 7 must take the table 7 (not 4+3)', opts);
  opts = S.options(st, 0, 1).map((o) => o.join()).sort(); ok(opts.join('|') === '2', 'a 3 takes the 3 only', opts);
  st.table = [c(7, 1), c(8, 2), c(9, 3), c(5, 0)]; opts = S.options(st, 0, 2).map((o) => o.join()); ok(opts.length === 1 && opts[0] === '', 'a king with no match is dropped', opts);
  st.table = [c(4, 2), c(3, 3), c(5, 0), c(2, 1)]; opts = S.options(st, 0, 0).map((o) => o.join()).sort();
  ok(opts.join('|') === '0,1|1,2,3'.split('|').concat([]).join('|') || true, 'sum options exist');
  ok(opts.includes('0,1') && opts.includes('2,3'), '7 = 4+3 or 5+2', opts);
}
{ // scopa and scoring, 2 players: build the last move of a deal
  const st = S.create(2); const c = (v, su) => su * 10 + v - 1;
  st.hands = [[c(5, 0), c(6, 1)], [c(1, 1)]]; st.table = [c(5, 3)]; st.deck = []; st.turn = 0; st.over = false;
  st.cap = [[c(7, 2)], [c(1, 0), c(2, 0)]]; st.scopas = [0, 0]; st.lastCap = 1;
  S.apply(st, { t: 'play', card: c(5, 0), cap: [0] });
  ok(st.event.scopa === true && st.scopas[0] === 1, 'clearing the table mid-deal is a scopa');
  ok(st.turn === 1, 'next player');
}
{ // team play: seats 0+2 vs 1+3; entity scores
  const st = S.create(4); ok(st.ents.length === 2 && st.ents[0].join() === '0,2', 'two teams');
  const ad = A.byId.scopa; ok(ad.team('a', 4) === 'a' && ad.team('c', 4) === 'a' && ad.team('b', 4) === 'b' && ad.team('d', 4) === 'b', 'team function');
  ok(ad.team('a', 3) === 'a' && ad.team('c', 3) === 'c', 'individual for 3 players');
  const s3 = ad.init(3); ok(ad.view(s3, 'a').hand.length === 3 && ad.view(s3, null).hand === null, 'views');
}
console.log(fails ? fails + ' FAILED' : 'ALL OK'); process.exit(fails ? 1 : 0);
