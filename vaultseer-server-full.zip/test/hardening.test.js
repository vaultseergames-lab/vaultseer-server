'use strict';
// Audit tests: abuse protection of the server, memory cleanup, restart guard, and junk input against every game.
const createServer = require('../src/server');
const makeCore = require('../src/core');
const { byId } = require('../src/adapters');
const C = require('../src/crypto.js');
const WebSocket = require('ws');
let bad = 0, n = 0; const ok = (c, m, x) => { n++; if (!c) { bad++; console.log('FAIL', m, x === undefined ? '' : x); } };
const A = '0x' + 'a'.repeat(40), B = '0x' + 'b'.repeat(40);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
(async () => {
  // ---- 1. restart guard, negative cache, rate limits ----
  let calls = 0; const nowSec = () => Math.floor(Date.now() / 1000);
  const chain = { getMatch: async (id) => { calls++; if (id === 1n) return { players: [A, B], game: 'chess', status: 2, joinedAt: nowSec() - 5 };
    if (id === 2n) return { players: [A, B], game: 'chess', status: 2, joinedAt: nowSec() - 4000 };   // started long ago, server does not know it
    if (id === 3n) return { players: [A, B], game: 'chess', status: 2 };                                // old mocks without joinedAt
    return { status: 1 }; } };
  const s = createServer({ chain, signer: { address: '0xs', sign: async () => 'SIG' }, port: 0, verify: (id, sig) => sig });
  const port = await s.listen();
  const open = (who, id, keep) => new Promise((res) => {
    const ws = new WebSocket('ws://127.0.0.1:' + port); const inbox = []; let closed = null;
    ws.on('message', (d) => inbox.push(JSON.parse(String(d)))); ws.on('close', (code) => { closed = code; });
    ws.on('open', () => { ws.send(JSON.stringify({ t: 'hello', id: String(id), sig: who })); setTimeout(() => res({ ws, inbox, closed: () => closed }), 120); });
  });
  const last = (c) => c.inbox[c.inbox.length - 1];
  let c = await open(A, 1); ok(last(c).t === 'state', 'fresh match starts');
  c = await open(A, 2); ok(/lost when the server restarted/.test(last(c).err), 'old unknown match is NOT restarted', last(c));
  ok(!s.core.get('2'), 'no game was created for the old match');
  c = await open(A, 3); ok(last(c).t === 'state', 'match without joinedAt (test chain) still works');
  calls = 0; for (let i = 0; i < 5; i++) await open(A, 99); ok(calls === 1, 'inactive id: the chain is asked once, then remembered', calls);
  // too many messages -> connection closed
  c = await open(A, 1); for (let i = 0; i < 80; i++) c.ws.send(JSON.stringify({ t: 'sync' })); await sleep(300);
  ok(c.closed() === 1008, 'message flood closes the connection', c.closed());
  // too many hellos on one connection
  c = await open(A, 1); for (let i = 0; i < 10; i++) c.ws.send(JSON.stringify({ t: 'hello', id: '1', sig: A })); await sleep(300);
  ok(c.closed() === 1008, 'hello spam closes the connection', c.closed());
  // garbage frames do not crash the server
  c = await open(A, 1); for (const g of ['{', 'null', '[]', '"x"', '{"t":"move"}', '{"t":"move","mv":null}', '{"t":"hello","id":{}}', '{"t":"hello","id":"1","sig":5}', JSON.stringify({ t: 'move', mv: { from: 'x' } })]) c.ws.send(g);
  await sleep(300); const h = await fetch('http://127.0.0.1:' + port + '/health').then((r) => r.json()); ok(h.ok, 'server alive after garbage');
  // oversized frame
  c = await open(A, 1); c.ws.on('error', () => {}); c.ws.send('x'.repeat(10000)); await sleep(200); ok(c.closed() !== null, 'oversized frame closes the connection');
  s.close();

  // ---- 2. purge ----
  { let t = 1000; const core = makeCore({ now: () => t, sign: async () => 'S' });
    core.start('1', 'chess', A, B); core.start('2', 'chess', A, B); await core.leave('1', B);
    ok(core.purge(1000) === 0, 'recent finished match kept'); t += 5000;
    ok(core.purge(1000) === 1 && !core.get('1') && core.get('2'), 'old finished match removed, running match kept'); }

  // ---- 3. crypto: Jacobian multiplication equals the plain affine formulas ----
  { const P = 2n ** 256n - 2n ** 32n - 977n, Nn = 0xfffffffffffffffffffffffffffffffebaaedce6af48a03bbfd25e8cd0364141n;
    const G = [0x79be667ef9dcbbac55a06295ce870b07029bfcdb2dce28d959f2815b16f81798n, 0x483ada7726a3c4655da4fbfc0e1108a8fd17b448a68554199c47d08ffb10d4b8n];
    const mod = (a, m = P) => ((a % m) + m) % m; const inv = (a) => { let [o, r] = [P, mod(a)], [x0, x1] = [0n, 1n]; while (r) { const q = o / r; [o, r] = [r, o - q * r]; [x0, x1] = [x1, x0 - q * x1]; } return mod(x0); };
    const add = (p, q) => { if (!p) return q; if (!q) return p; if (p[0] === q[0]) { if (mod(p[1] + q[1]) === 0n) return null; const l = mod(3n * p[0] * p[0] * inv(2n * p[1])); const x = mod(l * l - 2n * p[0]); return [x, mod(l * (p[0] - x) - p[1])]; } const l = mod((q[1] - p[1]) * inv(q[0] - p[0])); const x = mod(l * l - p[0] - q[0]); return [x, mod(l * (p[0] - x) - p[1])]; };
    const mulA = (k, p = G) => { let r = null, a = p; while (k > 0n) { if (k & 1n) r = add(r, a); a = add(a, a); k >>= 1n; } return r; };
    const rnd = () => BigInt('0x' + require('crypto').randomBytes(32).toString('hex'));
    let mism = 0; for (let i = 0; i < 150; i++) { const k = rnd() % Nn, p = mulA(rnd() % Nn || 1n); const a = mulA(k, p), b = C.mul(k, p); if (!a || !b || a[0] !== b[0] || a[1] !== b[1]) mism++; }
    for (const k of [1n, 2n, 3n, 4n, 5n, Nn - 1n, Nn - 2n, 1n << 200n]) { const a = mulA(k), b = C.mul(k); if (a[0] !== b[0] || a[1] !== b[1]) mism++; }
    ok(mism === 0, 'fast multiplication equals the plain one (random + edge scalars)', mism);
    ok(C.mul(Nn) === null && C.mul(0n) === null, 'n*G and 0*G are the point at infinity');
    const t0 = Date.now(); const key = rnd() % Nn || 1n; const hh = C.keccak(Buffer.from('speed')); let g; for (let i = 0; i < 30; i++) g = C.sign(hh, key); const per = (Date.now() - t0) / 30;
    ok(per < 15, 'signing takes ' + per.toFixed(1) + ' ms', per);
    ok(C.recover(hh, g.v, g.r, g.s) === C.addrOf(C.mul(key)), 'sign -> recover round trip'); }

  // ---- 4. junk input against every game: never throws, never changes the state, never leaks other seats ----
  const junk = [null, undefined, 0, -1, 1e99, NaN, '', 'x', '__proto__', [], [[]], {}, { from: -5, to: 99999 }, { __proto__: { evil: 1 } }, { t: { t: { t: 1 } } }, { from: '1', to: '2' }, { n: 'NaN' }, { col: 1.5 }, { idx: -0 }, { a: [1, 2, 3] }, { bid: { q: 1e9, f: 7 } }, { card: {} }, 'a'.repeat(5000), new Array(300).fill(7), { toString: 1 }, { constructor: { prototype: 1 } }];
  let games = 0, tries = 0;
  for (const gid of Object.keys(byId)) {
    const ad = byId[gid]; const [lo, hi] = ad.seats || [2, 2];
    for (const players of [lo, hi]) {
      let t = 5000; const core = makeCore({ now: () => t, sign: async () => 'S' });
      const addrs = Array.from({ length: players }, (_, i) => '0x' + (i + 1).toString(16).padStart(40, '0'));
      core.start('m', gid, addrs); games++;
      for (let r = 0; r < 60; r++) {
        const seat = addrs[r % players];
        for (const mv of junk) {
          const snap = JSON.stringify(core.get('m').st); const outBefore = core.get('m').out.size; tries++;
          let res; try { res = await core.move('m', seat, mv); } catch (e) { ok(false, gid + ': junk move threw ' + e.message, JSON.stringify(mv)); continue; }
          if (!res.ok && core.get('m').out.size === outBefore) ok(JSON.stringify(core.get('m').st) === snap, gid + ': rejected junk changed state', JSON.stringify(mv));
        }
        // a legal move now and then, so the game moves on
        const v = core.view('m', seat); if (v.legal && v.legal.length) await core.move('m', seat, v.legal[r % v.legal.length]);
        for (const a of addrs) { try { const vv = core.view('m', a); JSON.stringify(vv); } catch (e) { ok(false, gid + ': view threw ' + e.message); } }
        if (core.get('m').over) break;
        t += 1000;
      }
      // an outsider can never act or see a seat
      const ro = await core.move('m', '0x' + 'f'.repeat(40), junk[12]); ok(!ro.ok, gid + ': outsider refused');
    }
  }
  console.log('junk tries', tries, 'games', games);
  console.log(bad ? bad + ' FAILED of ' + n : 'ALL OK (' + n + ' checks)'); process.exit(bad ? 1 : 0);
})();
