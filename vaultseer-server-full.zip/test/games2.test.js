'use strict';
const makeCore = require('../src/core');
const A = '0x' + 'a'.repeat(40), B = '0x' + 'b'.repeat(40);
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log('FAIL', m); } else console.log('ok  ', m); };
(async () => {
  let t = 0; const core = makeCore({ now: () => t, sign: async (id, o) => 'sig' + o });
  // ---- penalty ----
  core.start(1, 'penalty', A, B);
  let va = core.view(1, A);
  ok(va.actors.length === 2 && va.legal.length === 6, 'penalty: both choose, 6 zones each');
  ok((await core.move(1, A, { zone: 9 })).err === 'illegal move', 'zone 9 refused');
  ok((await core.move(1, A, { zone: 2 })).waiting, 'A chooses, waits for B');
  ok((await core.move(1, A, { zone: 3 })).err === 'already chosen', 'A cannot change choice');
  ok(core.view(1, B).state.log.length === 0 && core.view(1, A).waiting, 'B sees nothing of A\'s choice; A is waiting');
  await core.move(1, B, { zone: 2 });                    // A shoots to 2, B keeper dives to 2 -> save
  ok(core.view(1, A).state.log[0].goal === false && core.view(1, A).state.shooter === 'b', 'same zone = save; now B shoots');
  // full match: A always shoots 0, keeps 1; B always shoots 0, keeps 0 -> A scores as shooter? random check below
  let wins = [0, 0, 0];
  for (let g = 0; g < 30; g++) {
    const id = 50 + g; core.start(id, 'penalty', A, B);
    for (let i = 0; i < 60 && !core.get(id).over; i++) { await core.move(id, A, { zone: Math.floor(Math.random() * 6) }); await core.move(id, B, { zone: Math.floor(Math.random() * 6) }); t += 10; }
    const o = core.get(id).outcome; ok(core.get(id).over && (o === 1 || o === 2) && core.get(id).sig === 'sig' + o, 'penalty game ' + g + ' ends with a signed winner');
    wins[o - 1]++;
  }
  // timeout: only A chose -> B loses; nobody chose -> draw
  core.start(2, 'penalty', A, B); await core.move(2, A, { zone: 0 }); t += 21000; await core.tick();
  ok(core.get(2).outcome === 1 && core.get(2).why === 'timeout', 'penalty: B did not choose in 20s -> A wins');
  core.start(3, 'penalty', A, B); t += 21000; await core.tick(); ok(core.get(3).outcome === 3, 'penalty: nobody chose -> draw');
  // ---- domino ----
  for (let g = 0; g < 40; g++) {
    const id = 200 + g; core.start(id, 'domino', A, B);
    const va0 = core.view(id, A), vb0 = core.view(id, B);
    if (g === 0) ok(va0.state.hand && vb0.state.hand && JSON.stringify(va0.state.hand) !== JSON.stringify(vb0.state.hand) && va0.state.counts[1] === vb0.state.hand.length, 'domino: each player sees only own tiles');
    if (g === 0) ok(!JSON.stringify(va0).includes(JSON.stringify(core.get(id).st.hands[1])) || core.get(id).st.hands[1].length === 0, 'domino: B\'s tiles are not in A\'s view');
    for (let i = 0; i < 300 && !core.get(id).over; i++) {
      const who = core.get(id).actors[0] === 'a' ? A : B, l = core.view(id, who).legal;
      if (!l.length) { fails++; console.log('FAIL domino stuck, no legal move'); break; }
      const r = await core.move(id, who, l[Math.floor(Math.random() * l.length)]); if (!r.ok) { fails++; console.log('FAIL', r.err); break; }
    }
    if (!core.get(id).over) { fails++; console.log('FAIL domino did not end'); }
  }
  ok(true, 'domino: 40 random games played to the end');
  core.start(300, 'domino', A, B);
  ok((await core.move(300, core.get(300).actors[0] === 'a' ? B : A, { t: 'draw' })).err === 'not your turn', 'domino: wrong player refused');
  ok((await core.move(300, core.get(300).actors[0] === 'a' ? A : B, { t: 'play', i: 99, end: 'L' })).err === 'illegal move', 'domino: tile that does not exist refused');
  console.log(fails ? fails + ' FAILED' : 'ALL OK'); process.exit(fails ? 1 : 0);
})();
