'use strict';
// Gas drip: the signed transaction is valid and every protection rule works.
const makeGas = require('../src/gas'); const C = require('../src/crypto'); const http = require('http'); const createServer = require('../src/server');
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log('FAIL', m); } else console.log('ok  ', m); };
const KEY = '0x' + (0xc0ffee1234n).toString(16).padStart(64, '0'), ME = C.addressOfKey(KEY);
const A = '0x' + 'a'.repeat(40), B = '0x' + 'b'.repeat(40), TOK = '0x' + '7'.repeat(40);
function node(state) {
  state.sent = []; return async (url, o) => { const r = JSON.parse(o.body); let result;
    switch (r.method) {
      case 'eth_getBalance': result = '0x' + (state.native[r.params[0]] || 0n).toString(16); break;
      case 'eth_getCode': result = state.code && state.code[r.params[0]] || '0x'; break;
      case 'eth_call': result = '0x' + (state.token[r.params[0].data.slice(-40).replace(/^/, '0x')] || 0n).toString(16); break;
      case 'eth_getTransactionCount': result = '0x5'; break;
      case 'eth_gasPrice': result = '0x' + (30n * 10n ** 9n).toString(16); break;
      case 'eth_sendRawTransaction': if (state.fail) return { json: async () => ({ error: { message: 'x' } }) }; state.sent.push(r.params[0]); result = '0x' + 'ee'.repeat(32); break;
      default: return { json: async () => ({ error: { message: 'no' } }) };
    }
    return { json: async () => ({ jsonrpc: '2.0', id: 1, result }) }; };
}
(async () => {
  let t = 1e12; const st = { native: {}, token: { [A]: 5000000n, [B]: 0n } };
  const g = makeGas({ rpcUrl: 'x', privateKey: KEY, chainId: 137, tokens: [TOK], dripWei: 2n * 10n ** 17n, now: () => t, fetchFn: node(st), ipPerHour: 3, perDay: 4 });
  ok(g.address === ME, 'drip wallet address');
  let r = await g.drip(A, '1.1.1.1'); ok(r.ok && /^0x[0-9a-f]{64}$/.test(r.tx), 'wallet with tokens and no gas gets a drip');
  // decode the raw tx: type 2, signature recovers to our wallet
  const raw = Buffer.from(st.sent[0].slice(2), 'hex'); ok(raw[0] === 2, 'EIP-1559 type');
  const { rlp } = makeGas; ok(typeof rlp === 'function', 'rlp exported');
  ok((await g.drip(A, '1.1.1.1')).err === 'already sent', 'same wallet twice -> refused');
  ok((await g.drip(B, '2.2.2.2')).err === 'no tokens', 'wallet without tokens -> refused');
  st.native[A] = 10n ** 18n; t += 2 * 86400000; ok((await g.drip(A, '3.3.3.3')).err === 'has gas', 'wallet that has gas -> refused');
  st.code = { [B]: '0x6000' }; st.token[B] = 9000000n; ok((await g.drip(B, '4.4.4.4')).err === 'not a plain wallet', 'contract address -> refused');
  ok((await g.drip('nonsense', '5.5.5.5')).err === 'bad address', 'bad address -> refused');
  // per-IP limit
  const g2 = makeGas({ rpcUrl: 'x', privateKey: KEY, chainId: 137, tokens: [TOK], dripWei: 10n ** 17n, now: () => t, fetchFn: node(st), ipPerHour: 2 });
  const mk = (n) => '0x' + n.toString(16).padStart(40, '0'); for (let i = 1; i <= 5; i++) st.token[mk(i)] = 5000000n;
  ok((await g2.drip(mk(1), 'ip')).ok && (await g2.drip(mk(2), 'ip')).ok && (await g2.drip(mk(3), 'ip')).err === 'too many requests', 'per-IP limit');
  // daily cap
  const g3 = makeGas({ rpcUrl: 'x', privateKey: KEY, chainId: 137, tokens: [TOK], dripWei: 10n ** 17n, now: () => t, fetchFn: node(st), perDay: 2, ipPerHour: 99 });
  const rs = []; for (let i = 1; i <= 3; i++) rs.push((await g3.drip(mk(i), 'x' + i)).err || 'ok'); ok(rs.join() === 'ok,ok,daily limit', 'daily cap: ' + rs.join());
  // the same wallet asked 20 times at once (different IPs): exactly one drip
  st.token[mk(77)] = 5000000n;
  const g3b = makeGas({ rpcUrl: 'x', privateKey: KEY, chainId: 137, tokens: [TOK], dripWei: 10n ** 17n, now: () => t, fetchFn: node(st), ipPerHour: 99 });
  const many = await Promise.all(Array.from({ length: 20 }, (_, i) => g3b.drip(mk(77), 'z' + i))); ok(many.filter((r) => r.ok).length === 1, 'parallel requests for one wallet: ' + many.filter((r) => r.ok).length + ' sent');
  // failed send gives the slot back
  const g4 = makeGas({ rpcUrl: 'x', privateKey: KEY, chainId: 137, tokens: [TOK], dripWei: 10n ** 17n, now: () => t, fetchFn: node(Object.assign(st, { fail: true })), ipPerHour: 99 });
  ok((await g4.drip(mk(4), 'y')).err === 'send failed', 'node refuses -> reported'); st.fail = false;
  // transaction fields: signature recovers to the drip wallet
  const raw2 = makeGas.rawTransfer({ key: BigInt(KEY), chainId: 137n, nonce: 5, tip: 6n, maxFee: 70n, gas: 21000, to: A, value: 10n ** 17n });
  const b = Buffer.from(raw2.slice(2), 'hex'); ok(b[0] === 2 && raw2.includes('aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'), 'raw tx carries the recipient');
  // RLP against the official examples, and the signed transaction decoded and its sender recovered independently
  const hx = (x) => makeGas.rlp(x).toString('hex'), B_ = (t) => Buffer.from(t);
  ok(hx(B_('dog')) === '83646f67' && hx([B_('cat'), B_('dog')]) === 'c88363617483646f67' && hx(Buffer.alloc(0)) === '80' && hx([]) === 'c0' && hx(Buffer.from([0x04, 0x00])) === '820400' && hx(Buffer.from([0x0f])) === '0f', 'RLP matches the official examples');
  ok(hx(B_('Lorem ipsum dolor sit amet, consectetur adipisicing elit')) === 'b8384c6f72656d20697073756d20646f6c6f722073697420616d65742c20636f6e7365637465747572206164697069736963696e6720656c6974', 'RLP long string example');
  function dec(b, o) { const c = b[o]; if (c < 0x80) return [b.subarray(o, o + 1), o + 1]; if (c < 0xb8) { const n = c - 0x80; return [b.subarray(o + 1, o + 1 + n), o + 1 + n]; }
    if (c < 0xc0) { const l = c - 0xb7, n = parseInt(b.subarray(o + 1, o + 1 + l).toString('hex'), 16); return [b.subarray(o + 1 + l, o + 1 + l + n), o + 1 + l + n]; }
    let n, st; if (c < 0xf8) { n = c - 0xc0; st = o + 1; } else { const l = c - 0xf7; n = parseInt(b.subarray(o + 1, o + 1 + l).toString('hex'), 16); st = o + 1 + l; }
    const out = []; let p = st; while (p < st + n) { const [v, q] = dec(b, p); out.push(v); p = q; } return [out, st + n]; }
  const [f] = dec(b, 1), num = (x) => BigInt('0x' + (x.toString('hex') || '0'));
  ok(f.length === 12 && num(f[0]) === 137n && num(f[1]) === 5n && num(f[2]) === 6n && num(f[3]) === 70n && num(f[4]) === 21000n && f[5].toString('hex') === 'a'.repeat(40) && num(f[6]) === 10n ** 17n && f[7].length === 0, 'all fields decode back correctly');
  const unsigned = f.slice(0, 9), hh = C.keccak(Buffer.concat([Buffer.from([2]), makeGas.rlp(unsigned)]));
  ok(C.recover(hh, 27 + Number(num(f[9])), num(f[10]), num(f[11])) === ME, 'signature recovers to the drip wallet');
  // reserve for the keeper: when the service wallet is nearly empty, drips pause
  const st5 = { native: {}, token: { [mk(60)]: 5000000n } }; const nd = node(st5);
  const lowNode = async (url, o) => { const r = JSON.parse(o.body); if (r.method === 'eth_getBalance' && r.params[0] === ME) return { json: async () => ({ result: '0x' + (3n * 10n ** 17n).toString(16) }) }; return nd(url, o); };
  const g6 = makeGas({ rpcUrl: 'x', privateKey: KEY, chainId: 137, tokens: [TOK], dripWei: 2n * 10n ** 17n, reserveWei: 10n ** 18n, now: () => t, fetchFn: lowNode, ipPerHour: 99 });
  ok((await g6.drip(mk(60), 'r1')).err === 'paused', 'service wallet below the keeper reserve -> drips pause');
  // HTTP endpoint
  const g5 = makeGas({ rpcUrl: 'x', privateKey: KEY, chainId: 137, tokens: [TOK], dripWei: 10n ** 17n, now: () => t, fetchFn: node(st) });
  const s = createServer({ chain: { getMatch: async () => ({}) }, signer: { address: '0xs', sign: async () => 'S' }, port: 0, gas: g5 }); const port = await s.listen();
  const post = (body, method = 'POST') => new Promise((res) => { const q = http.request({ port, path: '/gas', method, headers: { 'content-type': 'text/plain' } }, (rs2) => { let d = ''; rs2.on('data', (c) => d += c); rs2.on('end', () => res({ code: rs2.statusCode, cors: rs2.headers['access-control-allow-origin'], body: d })); }); q.end(body); });
  const h = await post(JSON.stringify({ addr: mk(5) })); ok(h.code === 200 && h.cors === '*' && JSON.parse(h.body).ok === true, 'HTTP /gas works with CORS: ' + h.body);
  ok((await post('', 'OPTIONS')).code === 204, 'preflight answered');
  ok(JSON.parse((await post('garbage')).body).ok === false, 'garbage body -> refused, no crash');
  s.close(); console.log(fails ? fails + ' FAILED' : 'ALL OK'); process.exit(fails ? 1 : 0);
})();
