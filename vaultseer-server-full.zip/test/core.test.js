'use strict';
const makeCore = require('../src/core');
const A = '0x' + 'a'.repeat(40), B = '0x' + 'b'.repeat(40);
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log('FAIL', m); } else console.log('ok  ', m); };
(async () => {
  let t = 0; const now = () => t;
  const core = makeCore({ now, sign: async (id, o) => 'sig:' + id + ':' + o });
  // chess: fool's mate -> black (B) wins, outcome 2
  core.start(1, 'chess', A, B);
  const sq = (s) => (8 - Number(s[1])) * 8 + 'abcdefgh'.indexOf(s[0]);
  const mv = (u, f, to) => core.move(1, u, { from: sq(f), to: sq(to) });
  ok((await mv(B, 'e7', 'e5')).err === 'not your turn', 'black cannot start');
  ok((await mv(A, 'e2', 'e5')).err === 'illegal move', 'illegal move refused');
  ok((await core.move(1, '0x' + 'c'.repeat(40), { from: 0, to: 1 })).err === 'you are not in this match', 'stranger refused');
  await mv(A, 'f2', 'f3'); await mv(B, 'e7', 'e5'); await mv(A, 'g2', 'g4');
  const r = await mv(B, 'd8', 'h4');
  ok(r.over && core.get(1).outcome === 2 && core.get(1).sig === 'sig:1:2', 'fool\'s mate: B wins, result signed');
  ok((await mv(A, 'a2', 'a3')).err === 'match is over', 'no moves after the end');
  // legal list only for the player to move
  core.start(2, 'chess', A, B);
  ok(core.view(2, A).legal.length === 20 && core.view(2, B).legal.length === 0, 'only the mover sees legal moves (20 at start)');
  // chess clock: 3 minutes, runs only on own turn
  t = 100000; await mv2(); async function mv2() { return core.move(2, A, { from: sq('e2'), to: sq('e4') }); }
  ok(Math.round(core.view(2, A).clocks.a / 1000) === 80 && Math.round(core.view(2, A).clocks.b / 1000) === 180, 'white spent 100s, black clock untouched');
  t = 100000 + 181000; const done = await core.tick();
  ok(done.includes(2) && core.get(2).outcome === 1 && core.get(2).why === 'timeout', 'black out of time -> A wins');
  // leaving = loss
  core.start(3, 'chess', A, B); ok((await core.leave(3, A)).ok && core.get(3).outcome === 2 && core.get(3).why === 'left', 'A leaves -> B wins');
  // late move after timeout is rejected
  core.start(4, 'chess', A, B); t += 200000;
  ok((await core.move(4, A, { from: sq('e2'), to: sq('e4') })).err === 'match is over' && core.get(4).outcome === 2, 'late move loses on time');
  // checkers: 60s per move
  core.start(5, 'checkers', A, B);
  const first = core.view(5, A).legal[0];
  ok(first && (await core.move(5, A, first)).ok, 'checkers move accepted');
  ok(core.view(5, A).actors[0] === 'b' && Math.round(core.view(5, B).clocks.b / 1000) === 60, 'checkers: 60s for the next mover');
  t += 61000; await core.tick(); ok(core.get(5).outcome === 1 && core.get(5).why === 'timeout', 'checkers timeout -> A wins');
  // promotion choice + random full chess playouts agree with the engine
  let games = 0;
  for (let g = 0; g < 20; g++) {
    const id = 100 + g; core.start(id, g % 2 ? 'chess' : 'checkers', A, B);
    for (let i = 0; i < 400 && !core.get(id).over; i++) {
      const m = core.get(id), who = m.actors[0] === 'a' ? A : B, l = core.view(id, who).legal;
      if (!l.length) break;
      t += 50; await core.move(id, who, l[Math.floor(Math.random() * l.length)]);
    }
    if (core.get(id).over) games++;
  }
  ok(games >= 5, 'random playouts finish (' + games + '/20 within 400 plies)');
  console.log(fails ? fails + ' FAILED' : 'ALL OK'); process.exit(fails ? 1 : 0);
})();
