'use strict';
const makeCore = require('../src/core');
const VG = require('../src/games1.js');
const A = '0x' + 'a'.repeat(40), B = '0x' + 'b'.repeat(40);
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log('FAIL', m); } else console.log('ok  ', m); };
(async () => {
  const core = makeCore({ sign: async (id, o) => 'sig' + o });
  core.start(1, 'poker', A, B);
  const va = core.view(1, A), vb = core.view(1, B);
  ok(va.state.hole.length === 2 && vb.state.hole.length === 2 && JSON.stringify(va.state.hole) !== JSON.stringify(vb.state.hole), 'each player sees only own 2 cards');
  ok(!JSON.stringify(va).includes('"deck"') && !JSON.stringify(vb).includes('"deck"'), 'the deck is not sent to players during a hand');
  const sbSide = core.get(1).actors[0], U = (x) => (x === 'a' ? A : B);
  const l = core.view(1, U(sbSide)).legal; ok(l.some((x) => x.t === 'call') && l.some((x) => x.t === 'fold') && l.some((x) => x.t === 'raise'), 'small blind may fold / call / raise');
  ok((await core.move(1, U(sbSide === 'a' ? 'b' : 'a'), { t: 'fold' })).err === 'not your turn', 'out of turn refused');
  ok((await core.move(1, U(sbSide), { t: 'raise', to: 5 })).err === 'illegal move', 'raise below the minimum refused');
  ok((await core.move(1, U(sbSide), { t: 'check' })).err === 'illegal move', 'check when there is a bet to call refused');
  const r = await core.move(1, U(sbSide), { t: 'fold' });
  const v2 = core.view(1, A);
  ok(r.ok && v2.state.lastHand && v2.state.lastHand.hole === null && v2.state.lastHand.deck.length === 52 && v2.state.table.board.length === 0 && v2.state.hand === 2, 'fold: next hand dealt, last hand revealed only as deck order (no hole cards shown)');
  // commitment check: sha256(seedStr|deck) must equal the commit that was shown at the start of that hand
  ok(VG.sha256(v2.state.lastHand.seedStr + '|' + v2.state.lastHand.deck.join(',')) === v2.state.lastHand.commit, 'revealed deck matches the SHA-256 commitment');
  // many full matches with random legal actions
  let tot = [0, 0, 0], showdowns = 0, chipsOk = true;
  for (let g = 0; g < 60; g++) {
    const id = 10 + g; core.start(id, 'poker', A, B);
    for (let i = 0; i < 2000 && !core.get(id).over; i++) {
      const who = U(core.get(id).actors[0]), lg = core.view(id, who).legal;
      if (!lg.length) { fails++; console.log('FAIL stuck'); break; }
      let mv = lg[Math.floor(Math.random() * lg.length)];
      if (mv.t === 'raise') mv = { t: 'raise', to: mv.min + Math.floor(Math.random() * (mv.max - mv.min + 1)) };
      const rr = await core.move(id, who, mv); if (!rr.ok) { fails++; console.log('FAIL', rr.err, JSON.stringify(mv)); break; }
      const st = core.get(id).st; if (st.stacks[0] + st.stacks[1] + (st.h.done ? 0 : st.h.pot + st.h.bets[0] + st.h.bets[1] + st.h.stk[0] + st.h.stk[1] - st.stacks[0] - st.stacks[1]) !== 2000) chipsOk = false;
    }
    const m = core.get(id); if (!m.over) { fails++; console.log('FAIL not finished'); continue; }
    tot[m.outcome - 1]++; if (m.st.history.length) showdowns++;
  }
  ok(tot[0] + tot[1] + tot[2] === 60 && chipsOk, 'poker: 60 random matches finished, chips always add up to 2000 (A ' + tot[0] + ' / B ' + tot[1] + ' / draw ' + tot[2] + ')');
  console.log(fails ? fails + ' FAILED' : 'ALL OK'); process.exit(fails ? 1 : 0);
})();
