'use strict';
const makeCore = require('../src/core');
const A = '0x' + 'a'.repeat(40), B = '0x' + 'b'.repeat(40);
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log('FAIL', m); } else console.log('ok  ', m); };
(async () => {
  const core = makeCore({ sign: async (id, o) => 'sig' + o });
  core.start(1, 'durak', A, B);
  const att = core.get(1).actors[0], U = (x) => (x === 'a' ? A : B), oth = att === 'a' ? 'b' : 'a';
  const va = core.view(1, A), vb = core.view(1, B);
  ok(va.state.hand.length === 6 && vb.state.hand.length === 6 && va.state.deck === 24, '6 cards each, 24 in the deck');
  ok(!JSON.stringify(va).includes(JSON.stringify(vb.state.hand)), 'A cannot see B\'s cards');
  ok((await core.move(1, U(oth), { t: 'take' })).err === 'not your turn', 'defender cannot act before the attack');
  ok((await core.move(1, U(att), { t: 'attack', card: 99 })).err === 'illegal move', 'card not in hand refused');
  const first = core.view(1, U(att)).legal[0];
  ok((await core.move(1, U(att), first)).ok && core.get(1).actors[0] === oth, 'attack moves the turn to the defender');
  ok(core.view(1, U(oth)).legal.some((m) => m.t === 'take'), 'defender may take');
  let res = [0, 0, 0];
  for (let g = 0; g < 80; g++) {
    const id = 10 + g; core.start(id, 'durak', A, B);
    for (let i = 0; i < 3000 && !core.get(id).over; i++) {
      const who = U(core.get(id).actors[0]), l = core.view(id, who).legal;
      if (!l.length) { fails++; console.log('FAIL stuck'); break; }
      const r = await core.move(id, who, l[Math.floor(Math.random() * l.length)]); if (!r.ok) { fails++; console.log('FAIL', r.err); break; }
    }
    if (!core.get(id).over) { fails++; console.log('FAIL not finished'); } else res[core.get(id).outcome - 1]++;
  }
  ok(res[0] + res[1] + res[2] === 80, 'durak: 80 random games finished (A ' + res[0] + ' / B ' + res[1] + ' / draw ' + res[2] + ')');
  console.log(fails ? fails + ' FAILED' : 'ALL OK'); process.exit(fails ? 1 : 0);
})();
