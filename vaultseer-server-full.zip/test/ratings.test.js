'use strict';
// Player table: Elo maths, rebuilding from chain events, and the public HTTP routes.
const { applyMatch, newProfile, START } = require('../src/ledger');
const makeRatings = require('../src/ratings'); const makeChain = require('../src/chain'); const createServer = require('../src/server'); const C = require('../src/crypto');
const A = '0x' + 'a'.repeat(40), B = '0x' + 'b'.repeat(40), D = '0x' + 'd'.repeat(40), E = '0x' + 'e'.repeat(40);
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log('FAIL', m); } else console.log('ok  ', m); };
(async () => {
  // --- maths
  let book = new Map();
  ok(applyMatch(book, { players: [A, B], game: 'chess', mask: 1 }), 'a result is counted');
  ok(book.get(A).rating === 1012 && book.get(B).rating === 988, 'equal players: winner +12, loser -12 (K 24)');
  ok(book.get(A).wins === 1 && book.get(B).losses === 1 && book.get(A).games === 1 && book.get(A).byGame.chess.wins === 1, 'wins / losses / games / per game');
  applyMatch(book, { players: [A, B], game: 'chess', mask: 3 });
  ok(book.get(A).draws === 1 && book.get(B).draws === 1 && book.get(A).rating < 1012 && book.get(B).rating > 988, 'a draw counts as a draw and moves the stronger player down a little');
  book = new Map(); applyMatch(book, { players: [A, B], game: 'chess', mask: 3 });
  ok(book.get(A).rating === START && book.get(B).rating === START, 'a draw between equals changes nothing');
  book = new Map(); applyMatch(book, { players: [A, B, D, E], game: 'poker', mask: 4 });
  ok(book.get(D).rating === 1024 - 0 + 0 || book.get(D).rating > 1000, 'four players: the winner gains');
  const sum = [A, B, D, E].reduce((s, a) => s + book.get(a).rating, 0); ok(sum === 4000, 'rating points are only moved around, not created (4 players)');
  ok(book.get(A).rating === book.get(B).rating && book.get(A).rating < 1000, 'the three losers lose the same');
  ok(!applyMatch(new Map(), { players: [A, A], game: 'chess', mask: 1 }), 'the same wallet twice at a table is never rated');
  ok(!applyMatch(new Map(), { players: [A, B], game: 'chess', mask: 0 }), 'an empty result is ignored');
  book = new Map(); applyMatch(book, { players: [A, B, D], game: 'dominoes', mask: 3 });
  ok(book.get(A).rating === book.get(B).rating && book.get(A).wins === 1 && book.get(D).losses === 1, 'a shared win: both winners are treated the same');
  // --- chain events
  const SETTLED = '0x' + C.keccak(Buffer.from('MatchSettled(uint256,uint16,uint256,uint256)')).toString('hex');
  const word = (n) => BigInt(n).toString(16).padStart(64, '0');
  const logs = [
    { blockNumber: '0x65', logIndex: '0x1', topics: [SETTLED, '0x' + word(2)], data: '0x' + word(2) + word(0) + word(0) },     // match 2: seat b wins
    { blockNumber: '0x64', logIndex: '0x0', topics: [SETTLED, '0x' + word(1)], data: '0x' + word(1) + word(0) + word(0) },     // match 1: seat a wins
    { blockNumber: '0x66', logIndex: '0x0', removed: true, topics: [SETTLED, '0x' + word(9)], data: '0x' + word(1) + word(0) + word(0) },
  ];
  const calls = [];
  const fetchFn = async (url, opt) => { const b = JSON.parse(opt.body); calls.push(b.method);
    const r = (result) => ({ json: async () => ({ result }) });
    if (b.method === 'eth_blockNumber') return r('0x70');
    if (b.method === 'eth_getLogs') { const f = parseInt(b.params[0].fromBlock, 16), t = parseInt(b.params[0].toBlock, 16); return r(logs.filter((l) => parseInt(l.blockNumber, 16) >= f && parseInt(l.blockNumber, 16) <= t)); }
    if (b.method === 'eth_call') { const id = Number(BigInt('0x' + b.params[0].data.slice(10)));
      const h = [word(0), word(5000000), word(0), word(0), word(2), word(3), word(1), word(8 * 32), word(2), word(BigInt(A)), word(BigInt(B))]; return r('0x' + h.join('')); }
    throw new Error('unexpected ' + b.method); };
  const chain = makeChain({ rpcUrl: 'http://x', arena: '0x' + '1'.repeat(40), fetchFn });
  const got = await chain.getSettled(0x60, 0x70);
  ok(got.length === 2 && got[0].id === '1' && got[0].mask === 1 && got[1].id === '2' && got[1].mask === 2, 'events are decoded, ordered by block, removed ones dropped');
  const rt = makeRatings({ chain, fromBlock: 0x60, confirmations: 4, chunk: 5, log: () => {} });
  await rt.sync();
  ok(rt.status().counted === 2 && rt.status().error === '', 'two settled matches counted, no error');
  ok(rt.profile(A).games === 2 && rt.profile(A).wins === 1 && rt.profile(B).wins === 1, 'each player won one of two');
  const before = JSON.stringify(rt.top(5)); await rt.sync(); ok(JSON.stringify(rt.top(5)) === before && rt.status().counted === 2, 'syncing again counts nothing twice');
  const rt2 = makeRatings({ chain, fromBlock: 0x60, chunk: 1000, log: () => {} }); await rt2.sync();
  ok(JSON.stringify(rt2.top(5)) === before, 'a fresh server rebuilds exactly the same table from the chain (nothing is stored on disk)');
  ok(rt.profile(A.toUpperCase().replace('0X', '0x')).games === 2 && rt.profile('0x' + 'f'.repeat(40)).rating === 1000, 'lookup is case-insensitive; an unknown wallet starts at 1000');
  // a node that refuses big ranges: the chunk shrinks by itself
  let tries = 0; const picky = { ...chain, getSettled: async (f, t) => { tries++; if (t - f > 20) throw new Error('block range too large'); return chain.getSettled(f, t); } };
  const rt3 = makeRatings({ chain: picky, fromBlock: 0x60, chunk: 1000, log: () => {} }); await rt3.sync();
  ok(rt3.status().counted === 2 && rt3.status().error === '', 'a node with a small range limit still works (chunk shrinks)');
  // --- HTTP
  const s = createServer({ chain: { getMatch: async () => ({}) }, signer: { address: '0xs', sign: async () => 'S' }, port: 0, ratings: rt });
  const port = await s.listen();
  let j = await (await fetch('http://127.0.0.1:' + port + '/profile/' + A)).json();
  ok(j.games === 2 && j.rating > 0 && j.addr === A, 'GET /profile/<address>');
  const r2 = await fetch('http://127.0.0.1:' + port + '/top?n=1'); const t = await r2.json();
  ok(t.length === 1 && t[0].rating >= 1000 && r2.headers.get('access-control-allow-origin') === '*', 'GET /top works from another site (CORS)');
  const r3 = await fetch('http://127.0.0.1:' + port + '/profile/nonsense'); ok(r3.status === 404, 'a bad address is a 404');
  const h = await (await fetch('http://127.0.0.1:' + port + '/health')).json(); ok(h.ratings && h.ratings.counted === 2, '/health shows the table state');
  s.close(); console.log(fails ? fails + ' FAILED' : 'ALL OK'); process.exit(fails ? 1 : 0);
})();
