'use strict';
// The production signer/verifier/chain reader, checked against the real Arena bytecode (via the JS EVM in /home/claude/evmtest).
const fs = require('fs'); const EV = '/home/claude/vaultseer-contracts/tests-evm/';
const { Chain, Contract, encodeCall } = require(EV + 'evm.js'); const secp = require(EV + 'secp.js');
const B = JSON.parse(fs.readFileSync(EV + 'build.json', 'utf8'));
const C = require('../src/crypto.js'), makeSigner = require('../src/signer.js'), makeChain = require('../src/chain.js');
let bad = 0; const ok = (c, m) => { console.log(c ? 'ok  ' : 'FAIL', m); if (!c) bad++; };
const KEY = 0x5160e005n, keyHex = '0x' + KEY.toString(16), ADDR = secp.addrOf(secp.mul(KEY));
const ch = new Chain(); ch.time = Math.floor(Date.now() / 1000); const OWN = secp.addrOf(secp.mul(0xa11ce001n)), TRE = secp.addrOf(secp.mul(0x7ea50004n));
function dep(name, args = []) { const abi = B[name].abi, c = abi.find((x) => x.type === 'constructor'); let init = Buffer.from(B[name].bin, 'hex'); if (c && c.inputs.length) init = Buffer.concat([init, encodeCall({ name: 'x', inputs: c.inputs }, args).subarray(4)]); return new Contract(ch, ch.deploy(OWN, init), abi); }
const usdt = dep('MockUSDT'); const arena = dep('Arena', [OWN, ADDR, TRE, [usdt.addr], [5000000n], [500000n]]);
const PA = secp.addrOf(secp.mul(0xa11ce00an)), PB = secp.addrOf(secp.mul(0xb0b0000bn));
for (const p of [PA, PB]) { usdt.send('mint', [p, 100000000n], OWN); usdt.as(p).send('approve', [arena.addr, 10n ** 12n]); }
arena.as(PA).send('open', [usdt.addr, 5000000n, 0, 2]); arena.as(PB).send('join', [1n]);
const signer = makeSigner({ privateKey: keyHex, chainId: 31337, arena: arena.addr });
ok(signer.address.toLowerCase() === ADDR.toLowerCase(), 'signer address derived from the key');
(async () => {
  const sig = await signer.sign(1, 1); const s = Buffer.from(sig.slice(2), 'hex');
  let settled = true; try { arena.as(PB).send('settle', [1n, 1, s]); } catch (e) { settled = false; }
  ok(settled, 'Arena accepts the production signature (match settled)');
  ok(Number(arena.view('getMatch', [1n])[5]) === 3, 'status is Settled');
  arena.as(PA).send('open', [usdt.addr, 5000000n, 0, 2]); arena.as(PB).send('join', [2n]);
  const other = await signer.sign(1, 1); try { arena.as(PB).send('settle', [2n, 1, Buffer.from(other.slice(2), 'hex')]); } catch (e) { /* reverts */ }
  ok(Number(arena.view('getMatch', [2n])[5]) === 2, 'a signature made for another match is refused (match 2 stays Active)');
  const wrongOutcome = await signer.sign(2, 2); try { arena.as(PB).send('settle', [2n, 1, Buffer.from(wrongOutcome.slice(2), 'hex')]); } catch (e) { /* reverts */ }
  ok(Number(arena.view('getMatch', [2n])[5]) === 2, 'a signature for another outcome is refused');
  const good = await signer.sign(2, 3); try { arena.as(PB).send('settle', [2n, 3, Buffer.from(good.slice(2), 'hex')]); } catch (e) { /* */ }
  ok(Number(arena.view('getMatch', [2n])[5]) === 3, 'the right signature for match 2 (draw) settles it');
  // hello signature recovery
  const msg = Buffer.from('Vaultseer match #7'), h = C.ethHash(msg), g = secp.sign(h, 0xa11ce00an);
  const hs = '0x' + g.r.toString(16).padStart(64, '0') + g.s.toString(16).padStart(64, '0') + g.v.toString(16);
  ok(C.recoverMessage('Vaultseer match #7', hs).toLowerCase() === PA.toLowerCase(), 'hello signature -> player address');
  let thr = false; try { C.recoverMessage('x', '0x12'); } catch (e) { thr = true; } ok(thr, 'garbage signature is rejected');
  // chain reader through a fake JSON-RPC
  const fetchFn = async (url, o) => { const p = JSON.parse(o.body).params[0]; const r = ch.call('0x' + '0'.repeat(40), p.to, Buffer.from(p.data.slice(2), 'hex')); return { json: async () => ({ result: '0x' + Buffer.from(r.ret).toString('hex') }) }; };
  const chain = makeChain({ rpcUrl: 'x', arena: arena.addr, fetchFn }); const m = await chain.getMatch(1);
  ok(m.players.length === 2 && m.players[0].toLowerCase() === PA.toLowerCase() && m.players[1].toLowerCase() === PB.toLowerCase() && m.game === 'chess' && m.status === 3 && m.stake === 5000000n && m.seats === 2, 'chain reader decodes a 2-seat match');
  // a 4-seat durak table settled with a production signature over a winners mask (seats c and a share? no: seat c wins alone -> mask 4)
  const P4 = [0xd1n, 0xd2n, 0xd3n, 0xd4n].map((k) => secp.addrOf(secp.mul(k)));
  for (const p of P4) { usdt.send('mint', [p, 100000000n], OWN); usdt.as(p).send('approve', [arena.addr, 10n ** 12n]); }
  arena.as(P4[0]).send('open', [usdt.addr, 5000000n, 4, 4]); for (let i = 1; i < 4; i++) arena.as(P4[i]).send('join', [3n]);
  const m3 = await chain.getMatch(3);
  ok(m3.players.length === 4 && m3.game === 'durak' && m3.seats === 4 && m3.status === 2 && m3.players.every((a, i) => a.toLowerCase() === P4[i].toLowerCase()), 'chain reader decodes a 4-seat table in seat order');
  const open = await chain.getMatch(9999).catch(() => 'err'); ok(open === 'err' || open.status === 0, 'unknown table reads as empty');
  const sig4 = await signer.sign(3, 4); arena.as(P4[3]).send('settle', [3n, 4, Buffer.from(sig4.slice(2), 'hex')]);
  ok(Number(arena.view('getMatch', [3n])[5]) === 3 && usdt.view('balanceOf', [P4[2]]) === 100000000n - 5500000n + 20000000n, 'mask 4 = seat c wins the whole pool of 4 x 5 = 20 (fee 0.50 paid on top)');
  // a bridge team (seats a and c) shares
  for (const p of P4) usdt.as(p).send('mint', [p, 0n]);
  arena.as(P4[0]).send('open', [usdt.addr, 5000000n, 12, 4]); for (let i = 1; i < 4; i++) arena.as(P4[i]).send('join', [4n]);
  const sig5 = await signer.sign(4, 5); arena.as(P4[1]).send('settle', [4n, 5, Buffer.from(sig5.slice(2), 'hex')]);
  ok(Number(arena.view('getMatch', [4n])[5]) === 3, 'bridge team mask 5 (seats a+c) settles');
  console.log(bad ? bad + ' FAILED' : 'PASS'); process.exit(bad ? 1 : 0);
})();
