'use strict';
// Runs every test.
const { spawnSync } = require('child_process');
const files = ['core', 'games2', 'games6', 'battleship', 'backgammon', 'cards4', 'chance', 'durakn', 'pokern', 'dominon', 'scopan', 'memoryn', 'bridgen', 'net', 'crypto', 'hardening', 'skill7', 'skill8', 'skill9', 'skill10', 'skillnet', 'age', 'ratings', 'ratings_evm', 'gas', 'events_providers'];
let bad = 0;
for (const f of files) {
  const code = "require('./test/" + f + ".test.js')";
  const r = spawnSync('node', ['-e', code], { cwd: __dirname + '/..', encoding: 'utf8' });
  const last = (r.stdout || '').trim().split('\n').pop();
  console.log((r.status === 0 ? 'PASS ' : 'FAIL ') + f + '  ' + last); if (r.status !== 0) { bad++; console.log(r.stdout.split('\n').filter((l) => l.startsWith('FAIL')).join('\n'), r.stderr.slice(0, 300)); }
}
process.exit(bad ? 1 : 0);
