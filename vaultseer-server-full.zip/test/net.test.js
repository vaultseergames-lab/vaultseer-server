'use strict';
// Network test with a fake chain and a fake signer (no ethers needed); signatures of the "hello" are faked by a custom verify.
const createServer = require('../src/server');
const WebSocket = require('ws');
const A = '0x' + 'a'.repeat(40), B = '0x' + 'b'.repeat(40), C = '0x' + 'c'.repeat(40);
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log('FAIL', m); } else console.log('ok  ', m); };
(async () => {
  const chain = { getMatch: async (id) => id === 7n ? { players: [A, B], game: 'chess', status: 2 } : id === 8n ? { players: [A, B], game: 'nonexistent', status: 2 } : { status: 1 } };
  const s = createServer({ chain, signer: { address: '0xsigner', sign: async (id, o) => 'SIG-' + id + '-' + o }, port: 0, verify: (id, sig) => sig });
  const port = await s.listen();
  const open = (who, id) => new Promise((res) => {
    const ws = new WebSocket('ws://127.0.0.1:' + port); const inbox = [];
    ws.on('message', (d) => inbox.push(JSON.parse(String(d))));
    ws.on('open', () => { ws.send(JSON.stringify({ t: 'hello', id: String(id), sig: who })); setTimeout(() => res({ ws, inbox }), 150); });
  });
  const last = (c) => c.inbox[c.inbox.length - 1];
  const a = await open(A, 7), b = await open(B, 7);
  ok(last(a).t === 'state' && last(a).you === 'a' && last(a).legal.length === 20, 'A joins, sees 20 legal moves');
  ok(last(b).you === 'b' && last(b).legal.length === 0, 'B joins, no moves yet');
  const c = await open(C, 7); ok(last(c).err === 'you are not in this match', 'stranger refused');
  const d = await open(A, 9); ok(/not active/.test(last(d).err), 'match not active on chain refused');
  const e = await open(A, 8); ok(/not available/.test(last(e).err), 'game not built yet refused');
  a.ws.send(JSON.stringify({ t: 'move', mv: { from: 52, to: 36 } })); await new Promise((r) => setTimeout(r, 150));
  ok(last(b).actors[0] === 'b' && last(b).legal.length === 20 && last(a).legal.length === 0, 'move reaches both players');
  b.ws.send(JSON.stringify({ t: 'leave' })); await new Promise((r) => setTimeout(r, 150));
  ok(last(a).over && last(a).outcome === 1 && last(a).sig === 'SIG-7-1', 'B leaves -> A wins, signed result pushed');
  const h = await fetch('http://127.0.0.1:' + port + '/health').then((r) => r.json()); ok(h.ok && h.signer === '0xsigner', '/health works');
  s.close(); console.log(fails ? fails + ' FAILED' : 'ALL OK'); process.exit(fails ? 1 : 0);
})();
