'use strict';
const crypto = require('crypto');
const B = require('../src/m_bridge.js');
const A = require('../src/adapters.js');
let fails = 0; const ok = (c, m, x) => { if (!c) { fails++; if (fails < 40) console.log('FAIL', m, x === undefined ? '' : JSON.stringify(x)); } };
// ---- scoring table (checked against the published scoring table) ----
const S = B.scoreDeal; // (level, strain 0..4, doubled 0..2, vul, tricks)
ok(S(1, 0, 0, false, 7) === 70, '1C made: 20 + 50 part-score', S(1, 0, 0, false, 7));
ok(S(1, 4, 0, false, 7) === 90, '1NT made: 40 + 50', S(1, 4, 0, false, 7));
ok(S(3, 4, 0, false, 9) === 400, '3NT made: 100 + 300', S(3, 4, 0, false, 9));
ok(S(3, 4, 0, true, 9) === 600, '3NT vulnerable: 100 + 500', S(3, 4, 0, true, 9));
ok(S(4, 3, 0, false, 10) === 420, '4S made: 120 + 300', S(4, 3, 0, false, 10));
ok(S(4, 3, 0, false, 11) === 450, '4S +1: 450', S(4, 3, 0, false, 11));
ok(S(5, 0, 0, false, 11) === 400, '5C made: 100 + 300', S(5, 0, 0, false, 11));
ok(S(6, 3, 0, false, 12) === 980, '6S: 180 + 300 + 500', S(6, 3, 0, false, 12));
ok(S(6, 3, 0, true, 12) === 1430, '6S vul: 180 + 500 + 750', S(6, 3, 0, true, 12));
ok(S(7, 4, 0, false, 13) === 1520, '7NT: 220 + 300 + 1000', S(7, 4, 0, false, 13));
ok(S(7, 4, 0, true, 13) === 2220, '7NT vul: 220 + 500 + 1500', S(7, 4, 0, true, 13));
ok(S(2, 2, 1, false, 8) === 470, '2H doubled made: 120 + 300 + 50 insult', S(2, 2, 1, false, 8));
ok(S(2, 2, 1, false, 9) === 570, '2H doubled +1: 120+300+50+100', S(2, 2, 1, false, 9));
ok(S(2, 2, 2, false, 8) === 640, '2H redoubled made: 240 + 300 + 100 insult', S(2, 2, 2, false, 8));
ok(S(1, 0, 1, false, 7) === 140, '1C doubled made: 40 + 50 + 50 = 140', S(1, 0, 1, false, 7));
ok(S(4, 3, 0, false, 9) === -50, 'down 1 undoubled non-vul = -50', S(4, 3, 0, false, 9));
ok(S(4, 3, 0, true, 8) === -200, 'down 2 undoubled vul = -200', S(4, 3, 0, true, 8));
ok(S(4, 3, 1, false, 9) === -100, 'down 1 doubled nv = -100', S(4, 3, 1, false, 9));
ok(S(4, 3, 1, false, 7) === -500, 'down 3 doubled nv = 100+200+200', S(4, 3, 1, false, 7));
ok(S(4, 3, 1, false, 6) === -800, 'down 4 doubled nv = 800', S(4, 3, 1, false, 6));
ok(S(4, 3, 1, true, 8) === -500, 'down 2 doubled vul = 200+300', S(4, 3, 1, true, 8));
ok(S(4, 3, 1, true, 7) === -800, 'down 3 doubled vul = 800', S(4, 3, 1, true, 7));
ok(S(4, 3, 2, false, 9) === -200, 'down 1 redoubled nv = -200', S(4, 3, 2, false, 9));
ok(S(4, 3, 2, true, 9) === -400, 'down 1 redoubled vul = -400', S(4, 3, 2, true, 9));
// ---- random games ----
let passedOut = 0, made = 0, down = 0, games = 0, ties = 0;
for (let g = 0; g < 400; g++) {
  const st = B.create(4); let moves = 0;
  while (!st.over && moves < 3000) {
    const who = B.actors(st)[0]; ok(who !== undefined, 'one actor');
    for (let s = 0; s < 4; s++) if (s !== who) ok(B.legal(st, s).length === 0, 'only the actor moves');
    const l = B.legal(st, who); ok(l.length > 0, 'actor has moves', { phase: st.phase });
    if (st.phase === 'bid') {
      // mostly pass, sometimes bid/double so contracts happen
      const r = Math.random(); let mv = { t: 'pass' };
      if (r < 0.25) { const bids = l.filter((x) => x.t === 'bid').slice(0, 6); if (bids.length) mv = bids[crypto.randomInt(0, bids.length)]; }
      else if (r < 0.32) mv = l.find((x) => x.t === 'double') || l.find((x) => x.t === 'redouble') || mv;
      ok(B.find(st, mv, who), 'bid is legal'); B.apply(st, mv);
    } else {
      const mv = l[crypto.randomInt(0, l.length)];
      const seatToPlay = st.turn; if (seatToPlay === st.contract.dummy) ok(who === st.contract.declarer, 'declarer plays the dummy');
      // follow suit check
      if (st.trick.length) { const led = B.suit(st.trick[0].card); const has = st.hands[seatToPlay].some((c) => B.suit(c) === led); if (has) ok(B.suit(mv.card) === led, 'must follow suit'); }
      ok(B.find(st, mv, who), 'card is legal'); B.apply(st, mv);
    }
    moves++;
    ok(st.hands.reduce((a, h) => a + h.length, 0) + st.played % 4 * 0 >= 0, 'sanity');
  }
  ok(st.over && st.winners, 'game ends'); games++;
  st.history.forEach((e) => { if (e.passedOut) passedOut++; else if (e.made) made++; else down++; });
  ok(st.history.length === 4, 'four deals'); if (st.winners.length === 4) ties++;
  const total = st.history.reduce((a, e) => [a[0] + e.delta[0], a[1] + e.delta[1]], [0, 0]); ok(total[0] === st.scores[0] && total[1] === st.scores[1], 'scores add up');
  ok(st.winners.length === 4 || (st.scores[st.winners[0] % 2] > st.scores[1 - st.winners[0] % 2]), 'winning team has more');
}
console.log('bridge playouts:', games, 'matches; deals: passed out', passedOut, 'made', made, 'down', down, 'tied matches', ties);
// trick rules on a fixed deal
{
  const st = B.create(4);
  st.phase = 'play'; st.contract = { level: 1, strain: 2, doubled: 0, declarer: 0, dummy: 2 }; st.turn = 1; st.trick = [];   // hearts are trumps
  const c = (r, su) => su * 13 + r;
  st.hands = [[c(5, 3), c(6, 3)], [c(12, 0), c(3, 0)], [c(0, 2), c(7, 2)], [c(1, 1), c(4, 1)]];    // b leads A club; c (no clubs) ruffs with the deuce of hearts; d discards; a (no clubs) discards
  st.tricksWon = [0, 0];
  ok(B.legal(st, 1).length === 2, 'leader may lead anything');
  B.apply(st, { t: 'play', card: c(12, 0) });
  ok(B.legal(st, 0).length === 2 && B.legal(st, 2).length === 0, 'c is dummy: declarer a chooses; c has no club so any card is legal');
  B.apply(st, { t: 'play', card: c(0, 2) });
  B.apply(st, { t: 'play', card: c(1, 1) });
  ok(st.turn === 0, 'seat a (declarer) to play');
  B.apply(st, { t: 'play', card: c(5, 3) });
  ok(st.lastTrick && st.lastTrick.winner === 2, 'the ruff wins the trick (c)', st.lastTrick);
  ok(st.turn === 2 && st.tricksWon[0] === 1, 'winner (c) leads next; a+c have 1 trick', { turn: st.turn, t: st.tricksWon });
  B.apply(st, { t: 'play', card: c(7, 2) }); B.apply(st, { t: 'play', card: c(4, 1) });
}
// adapter views
{ const ad = A.byId.bridge; ok(ad.seats[0] === 4 && ad.seats[1] === 4, 'bridge needs exactly 4'); const st = ad.init(4); const v = ad.view(st, 'b'); ok(v.hand.length === 13 && v.dummy === null, 'own hand only before the lead');
  ok(ad.team('a') === 'a' && ad.team('c') === 'a' && ad.team('b') === 'b' && ad.team('d') === 'b', 'teams'); ok(!JSON.stringify(v).includes('"hands"'), 'no leak'); }
// core with teams: both opponents leave -> partner team wins; one leaves -> auto-play
(async () => {
  const makeCore = require('../src/core');
  let t = 0; const core = makeCore({ now: () => t, sign: async (id, o) => 'sig:' + id + ':' + o });
  const P = ['0x' + '1'.repeat(40), '0x' + '2'.repeat(40), '0x' + '3'.repeat(40), '0x' + '4'.repeat(40)];
  core.start('x', 'bridge', P); await core.leave('x', P[1]); ok(!core.get('x').over, 'one player leaving does not end bridge (his partner sits on)');
  await core.leave('x', P[3]); ok(core.get('x').over && core.get('x').outcome === 5, 'both of b+d gone -> a+c win (mask 5)', core.get('x').outcome);
  // a full match where seat b leaves early: the server plays his hand, teams a+c can win; b,d never listed unless d wins alone? d may win as partner of a leaver
  for (let g = 0; g < 15; g++) {
    const id = 'b' + g; core.start(id, 'bridge', P); const m = core.get(id); let guard = 0;
    while (!m.over && guard++ < 3000) {
      t += 200; if (guard === 5) await core.leave(id, P[1]); if (m.over) break;
      const a = m.actors[0]; const addr = P['abcd'.indexOf(a)]; const l = core.view(id, addr).legal; if (!l.length) { ok(false, 'live actor without moves'); break; }
      const mv = m.st.phase === 'bid' ? (Math.random() < 0.3 ? l[crypto.randomInt(0, l.length)] : { t: 'pass' }) : l[crypto.randomInt(0, l.length)];
      const r = await core.move(id, addr, mv); ok(r.ok, 'accepted', r);
    }
    ok(m.over && m.sig, 'bridge match finished', { guard, why: m.why }); ok(!(m.outcome & 2), 'the player who left never gets paid', m.outcome);
  }
  console.log(fails ? fails + ' FAILED' : 'ALL OK'); process.exit(fails ? 1 : 0);
})();
