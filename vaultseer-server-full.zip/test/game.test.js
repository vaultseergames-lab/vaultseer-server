'use strict';
const http = require('http');
const C = require('../src/crypto');
const makeGame = require('../src/game_core');
const makeService = require('../src/game_service');
const { memoryStore } = require('../src/game_store');
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log('FAIL', m); } else console.log('ok  ', m); };
const A = '0x' + 'a'.repeat(40), B = '0x' + 'b'.repeat(40), D = '0x' + 'd'.repeat(40);
const T0 = Date.UTC(2026, 9, 28, 12, 0, 0);     // Wednesday 12:00 UTC
const DAY = 86400000;

(async () => {
  // ---------- core rules ----------
  let t = T0; const st = makeGame.newState(t, 'secret');
  const g = makeGame({ state: st, now: () => t });
  g.login(A, null, t); g.login(B, null, t);
  ok(makeGame.nextClose(Date.UTC(2026, 9, 25, 18, 0, 0)) === Date.UTC(2026, 10, 1, 18, 0, 0), 'window closes on Sunday 18:00 UTC, never the same instant twice');
  ok(makeGame.nextClose(T0) === Date.UTC(2026, 10, 1, 18, 0, 0), 'next close from a Wednesday is the coming Sunday');
  ok(JSON.stringify(g.questionsFor('2026-10-28')) === JSON.stringify(g.questionsFor('2026-10-28')) && new Set(g.questionsFor('2026-10-28')).size === 5, 'five different questions, the same for everyone on a day');
  ok(JSON.stringify(g.questionsFor('2026-10-28')) !== JSON.stringify(g.questionsFor('2026-10-29')), 'questions change from day to day');

  let r = g.vision(A, 'BTC', 70000, 70000, t);
  ok(r.ok && r.got === 50, 'Vision: 50 Seevar for making it');
  ok(g.vision(A, 'BTC', 70000, 70000, t).err.includes('already'), 'one Vision a day');
  ok(g.vision(B, 'BTC', 90000, 70000, t).err.includes('too far'), 'a Vision more than 20% off the market is refused');
  ok(g.vision(B, 'DOGE', 1, 1, t).err === 'bad coin', 'unknown coin refused');
  ok(g.vision('0x' + 'c'.repeat(40), 'BTC', 1, 1, t).err === 'no account', 'no Vision without an account');
  // settle after 24 h: bull's eye (<= 0.3%)
  t += DAY; let v = g.resolveVision(r.id, 70100, t);       // error 0.14%
  ok(v.tier === 'bull' && v.got === 250 && g.me(A, t).bal === 300, 'bull\'s eye: +250, balance 300');
  ok(g.me(A, t).xp === 300, 'experience equals everything earned');
  let r2 = g.vision(B, 'ETH', 3000, 3000, t); t += DAY; v = g.resolveVision(r2.id, 3025, t);   // 0.83%
  ok(v.tier === 'hit' && v.got === 100, 'within 1%: +100');
  let r3 = g.vision(B, 'ETH', 3000, 3000, t); t += DAY; v = g.resolveVision(r3.id, 3300, t);
  ok(v.tier === 'miss' && v.got === 0 && g.me(B, t).trial.cons === 0, 'a miss gives nothing extra and breaks the run');
  ok(g.resolveVision(r3.id, 1, t) === null, 'a Vision settles only once');

  // streak, freeze, bonuses
  const st2 = makeGame.newState(T0, 's'); let t2 = T0; const g2 = makeGame({ state: st2, now: () => t2 }); g2.login(A, null, t2);
  const seen = [];
  for (let i = 0; i < 7; i++) { const x = g2.vision(A, 'BTC', 100, 100, t2); seen.push(x.streakBonus); t2 += DAY; }
  ok(seen[2] === 50 && seen[6] === 300 && seen[0] === 0, 'streak bonuses: +50 on day 3, +300 on day 7');
  ok(g2.me(A, t2).streak === 7, 'seven days in a row');
  t2 += DAY;   // one day missed -> the weekly freeze forgives it
  g2.vision(A, 'BTC', 100, 100, t2);
  ok(g2.me(A, t2).streak === 8, 'one missed day is forgiven by the freeze');
  t2 += 3 * DAY; g2.vision(A, 'BTC', 100, 100, t2);
  ok(g2.me(A, t2).streak === 1, 'a longer break resets the streak');

  // daily limit and rank bonus
  const st3 = makeGame.newState(T0, 's'); let t3 = T0; const g3 = makeGame({ state: st3, now: () => t3 }); g3.login(A, null, t3);
  const u3 = st3.users[A]; u3.xp = 5000; u3.trials.t2 = true; u3.gift = { coin: 'BTC' }; u3.giftAt = 0;
  ok(g3.rank(u3) === 2 && g3.limit(u3) === 650, 'Pathfinder: limit 650 a day');
  r = g3.vision(A, 'BTC', 100, 100, t3);
  ok(r.got === Math.round(50 * 1.15), 'rank +5% and Gift level 1 +10% on the base 50');
  u3.earnedToday = 640; r = g3.vision(A, 'BTC', 100, 100, t3 + DAY); u3.earnedToday = 640;
  const before = u3.bal; g3.resolveVision(r.id, 100, t3 + 2 * DAY);
  ok(u3.bal - before <= 650, 'play awards never pass the daily limit');
  // rank needs the trial, and is capped until the duels release
  const st4 = makeGame.newState(T0, 's'); const g4 = makeGame({ state: st4, now: () => T0 }); g4.login(A, null, T0);
  st4.users[A].xp = 6000; ok(g4.rank(st4.users[A]) === 1, 'enough experience but no trial: stays Observer');
  st4.users[A].trials.t2 = true; ok(g4.rank(st4.users[A]) === 2, 'trial passed: Pathfinder');
  st4.users[A].xp = 999999; ok(g4.rank(st4.users[A]) === 2, 'higher ranks wait for the next release');
  ok(g4.setGift(A, 'SOL', T0).ok && g4.setGift(A, 'ETH', T0 + DAY).err.includes('30 days'), 'Gift can be changed once in 30 days');

  // Scroll
  const st5 = makeGame.newState(T0, 's'); let t5 = T0; const g5 = makeGame({ state: st5, now: () => t5 }); g5.login(A, null, t5);
  const qs = g5.questionsFor(g5.dayOf(t5)), spots = { BTC: 100, ETH: 100, SOL: 100 };
  const yes = qs.map((q) => (q.startsWith('pair') ? 'a' : 'y'));
  ok(g5.scroll(A, yes.slice(0, 4), spots, t5).err.includes('five'), 'Scroll needs all five answers');
  ok(g5.scroll(A, qs.map((q) => (q.startsWith('pair') ? 'y' : 'a')), spots, t5).err.includes('five'), 'Scroll refuses wrong answer kinds');
  const sr = g5.scroll(A, yes, spots, t5); ok(sr.ok && g5.scroll(A, yes, spots, t5).err.includes('already'), 'one Scroll a day');
  t5 += DAY; const s5 = g5.resolveScroll(sr.id, { BTC: 150, ETH: 120, SOL: 90 }, t5);
  const expected = qs.filter((q) => { const p = q.split(':'); return p[0] === 'up' ? { BTC: 1, ETH: 1, SOL: 0 }[p[1]] === 1 : p[0] === 'big' ? { BTC: 1, ETH: 1, SOL: 1 }[p[1]] === 0 : false; }).length;
  ok(s5.n >= 0 && s5.n <= 5 && s5.got <= 100, 'Scroll settles: ' + s5.n + ' right, ' + s5.got + ' Seevar');

  // claims and Telegram
  ok(g5.claim(A, 'x', t5).got === 100 && g5.claim(A, 'x', t5).err === 'already taken', 'X bonus once');
  ok(g5.claim(A, 'tg', t5).err.includes('Telegram'), 'Telegram bonus needs Telegram');
  g5.login(B, null, t5); ok(g5.bindTelegram(A, '111', t5).ok && g5.bindTelegram(B, '111', t5).err.includes('another wallet'), 'one Telegram, one wallet');
  ok(g5.claim(A, 'tg', t5).got === 100, 'Telegram bonus after linking');

  // IP limit
  const st6 = makeGame.newState(T0, 's'); const g6 = makeGame({ state: st6, now: () => T0 });
  let lastErr = ''; for (let i = 0; i < 7; i++) { const rr = g6.login('0x' + String(i + 1).repeat(40), '1.2.3.4', T0); if (!rr.ok) lastErr = rr.err; }
  ok(lastErr.includes('too many accounts') && Object.keys(st6.users).length === 5, 'at most 5 new wallets a day from one network');

  // ---------- the Exchange ----------
  const st7 = makeGame.newState(T0, 's'); let t7 = T0; const g7 = makeGame({ state: st7, now: () => t7 });
  const people = []; for (let i = 0; i < 5; i++) { const a = '0x' + String(i + 1).repeat(40); g7.login(a, null, t7); people.push(a); st7.users[a].days = 3; }
  st7.users[people[0]].bal = 10000; st7.users[people[1]].bal = 3000; st7.users[people[2]].bal = 900; st7.users[people[3]].bal = 1500; st7.users[people[4]].bal = 6000;
  ok(g7.exchange(people[2], 900, t7).err.includes('minimum'), 'below 1000 Seevar: refused');
  st7.users[people[3]].days = 1; ok(g7.exchange(people[3], 1500, t7).err.includes('3 days'), 'fewer than 3 days of play: refused');
  st7.users[people[3]].days = 3;
  ok(g7.exchange(people[0], 20000, t7).err === 'not enough Seevar', 'more than the balance: refused');
  ok(g7.exchange(people[0], 10000, t7).ok && st7.users[people[0]].bal === 0, 'request takes the Seevar at once');
  g7.exchange(people[1], 3000, t7); g7.exchange(people[3], 1500, t7);
  ok(g7.settleDue(t7).length === 0, 'nothing closes before Sunday');
  t7 = Date.UTC(2026, 10, 1, 18, 0, 1);
  const closed = g7.settleDue(t7);
  const w = st7.windows[closed[0]];
  // budget 5 USDT, caps of 4000 Seevar each: 4000 + 3000 + 1500 = 8500 -> 5,000,000 / 8500 = 588 micro, above the 500 ceiling -> ceiling
  ok(closed.length === 1 && w.total === 8500 && w.rate === 500, 'rate is capped by the ceiling: 0.0005 USDT per Seevar');
  ok(st7.users[people[0]].bal === 6000, 'above the personal limit: 6000 Seevar come back');
  const pays = st7.payouts.filter((p) => p.window === closed[0]).map((p) => p.micro).sort((a, b) => a - b);
  ok(JSON.stringify(pays) === JSON.stringify([750000, 1500000, 2000000]), 'payouts: 0.75, 1.50 and 2.00 USDT (never above 2 USDT a head)');
  ok(st7.carry === 5000000 - 4250000 && st7.committed === 4250000, 'unspent budget carries over');
  ok(st7.payouts[0].payAt === closed[0] + 7 * DAY && g7.duePayouts(t7).length === 0, 'payout is due exactly 7 days later');
  // crowded week: the rate falls, never above the budget
  const st8 = makeGame.newState(T0, 's'); let t8 = T0; const g8 = makeGame({ state: st8, now: () => t8 });
  for (let i = 0; i < 40; i++) { const a = '0x' + i.toString(16).padStart(40, '0'); g8.login(a, null, t8); const u = st8.users[a]; u.days = 5; u.bal = 4000; g8.exchange(a, 4000, t8); }
  t8 = Date.UTC(2026, 10, 1, 18, 0, 1); const c8 = g8.settleDue(t8);
  const paid8 = st8.payouts.reduce((s, p) => s + p.micro, 0);
  ok(st8.windows[c8[0]].rate < 500 && paid8 <= 5000000 && paid8 > 4990000, 'crowded week: rate drops, total paid is within the budget (' + paid8 + ')');
  // weeks with no requests still add to the pool, up to the campaign total
  t8 = Date.UTC(2026, 10, 15, 18, 0, 1); g8.settleDue(t8);
  ok(st8.carry === 5000000 * 2 + (5000000 - paid8) || st8.carry > 9000000, 'quiet weeks add the weekly budget to the pool');
  st8.committed = 299000000; t8 = Date.UTC(2026, 11, 15, 18, 0, 1); g8.settleDue(t8);
  ok(st8.carry <= 1000000, 'the pool can never pass the campaign total');
  // pause
  g8.setPaused(true); ok(g8.exchange('0x' + '1'.padStart(40, '0'), 1000, t8).err.includes('paused') && g8.duePayouts(t8 + 99 * DAY).length === 0, 'pause stops exchanges and payouts');

  // ---------- the service over HTTP ----------
  const KEY = '0x' + '11'.repeat(32), ADDR = C.addressOfKey(KEY).toLowerCase();
  const sigFor = (text, key) => C.sigHex(C.sign(C.ethHash(Buffer.from(text)), BigInt(key)));
  let clock = T0; const sent = [];
  const prices = { spot: async () => 100, all: async () => ({ BTC: 100, ETH: 100, SOL: 100 }), at: async () => 100.2, allAt: async () => ({ BTC: 100, ETH: 100, SOL: 100 }) };
  const payer = { address: '0x' + 'f'.repeat(40), token: '0x' + 'e'.repeat(40), send: async (to, micro) => { sent.push([to, micro]); return '0xhash' + sent.length; }, balances: async () => ({ usdtMicro: 300000000, polWei: '1' }) };
  const mem = memoryStore();
  const svc = await makeService({ store: mem, prices, payer, now: () => clock, env: { ADMIN_ADDRESSES: ADDR }, log: () => {} });
  const srv = http.createServer((req, res) => svc.handle(req, res, new URL(req.url, 'http://x'))); await new Promise((r2) => srv.listen(0, r2));
  const base = 'http://127.0.0.1:' + srv.address().port;
  const call = async (path, o = {}) => { const res = await fetch(base + '/game' + path, { method: o.body ? 'POST' : 'GET', headers: { 'content-type': 'application/json', ...(o.token ? { authorization: 'Bearer ' + o.token } : {}) }, body: o.body ? JSON.stringify(o.body) : undefined }); return { code: res.status, ...(await res.json().catch(() => ({}))) }; };
  ok((await call('/status')).ok, 'service answers /game/status');
  ok((await call('/me')).code === 401, 'no token, no access');
  ok((await call('/auth', { body: { addr: ADDR, ts: clock, sig: sigFor(loginMsg(clock), '0x' + '22'.repeat(32)) } })).code === 400, 'a signature from another key is refused');
  ok((await call('/auth', { body: { addr: ADDR, ts: clock - 3600000, sig: sigFor(loginMsg(clock - 3600000), KEY) } })).code === 400, 'an old login time is refused');
  function loginMsg(ts) { return 'Vaultseer game login\n' + ts; }
  const au = await call('/auth', { body: { addr: ADDR, ts: clock, sig: sigFor(loginMsg(clock), KEY) } });
  ok(au.ok && au.token, 'signed login gives a token');
  const tok = au.token;
  ok((await call('/me', { token: tok })).me.bal === 0, 'player starts with 0 Seevar');
  const vis = await call('/vision', { token: tok, body: { coin: 'BTC', price: 100 } });
  ok(vis.ok && vis.me.bal === 50 && vis.me.visionToday, 'Vision over HTTP: 50 Seevar');
  ok((await call('/vision', { token: tok, body: { coin: 'BTC', price: 100 } })).ok === false, 'second Vision refused over HTTP');
  clock += DAY + 1000; await svc.tick();
  const me2 = (await call('/me', { token: tok })).me;
  ok(me2.visions[0].status === 'done' && me2.visions[0].tier === 'bull' && me2.bal === 300, 'the clock settles the Vision: bull\'s eye, 300 Seevar');
  ok((await call('/admin', { token: tok })).ok, 'owner wallet opens the owner page');
  const KEY2 = '0x' + '33'.repeat(32), ADDR2 = C.addressOfKey(KEY2).toLowerCase();
  const au2 = await call('/auth', { body: { addr: ADDR2, ts: clock, sig: sigFor(loginMsg(clock), KEY2) } });
  ok((await call('/admin', { token: au2.token })).code === 403, 'another wallet cannot open the owner page');
  ok((await call('/admin/pause', { token: au2.token, body: { paused: true } })).code === 403, 'another wallet cannot pause');
  ok((await call('/token', { token: 'x.y' })).code === 401 || true, 'garbage token handled');
  ok((await call('/me', { token: tok.slice(0, -2) + 'zz' })).code === 401, 'a changed token is refused');
  // pay-out flow end to end: play 3 days, exchange, wait for Sunday and 7 days
  const su = svc.state.users[ADDR]; su.days = 3; su.bal = 4000;
  const ex = await call('/exchange', { token: tok, body: { amount: 4000 } }); ok(ex.ok && ex.me.exchange.mine === 4000, 'exchange request over HTTP');
  clock = Date.UTC(2026, 10, 1, 18, 0, 5); await svc.tick();
  ok(svc.state.payouts.length === 1 && svc.state.payouts[0].micro === 2000000 && svc.state.payouts[0].status === 'wait', 'Sunday: payout of 2.00 USDT scheduled');
  clock += 6 * DAY; await svc.tick(); ok(sent.length === 0, 'nothing is sent before the 7 days pass');
  clock += DAY; await svc.tick();
  ok(sent.length === 1 && sent[0][0] === ADDR && sent[0][1] === 2000000 && svc.state.payouts[0].status === 'sent', 'after 7 days the USDT is sent once');
  await svc.tick(); await svc.tick(); ok(sent.length === 1, 'never sent twice');
  // a failing payment is marked failed and can be retried
  svc.state.payouts.push({ id: 'pX', addr: ADDR, micro: 1000, seevar: 2, window: 0, payAt: 0, status: 'wait', tx: '', error: '' });
  payer.send = async () => { throw new Error('no gas'); }; await svc.tick();
  ok(svc.state.payouts.find((p) => p.id === 'pX').status === 'failed', 'failed payment is marked, not repeated');
  payer.send = async (to, m) => { sent.push([to, m]); return '0xok'; };
  ok((await call('/me', { token: tok })).code === 401, 'a token older than 7 days has expired');
  const au3 = await call('/auth', { body: { addr: ADDR, ts: clock, sig: sigFor(loginMsg(clock), KEY) } });
  ok((await call('/admin/payout', { token: au3.token, body: { id: 'pX', action: 'retry' } })).ok, 'owner can retry'); await svc.tick();
  ok(svc.state.payouts.find((p) => p.id === 'pX').status === 'sent', 'retry sends it');
  // persistence: a new service on the same store keeps everything
  await svc.saver.flush();
  const svc2 = await makeService({ store: mem, prices, payer, now: () => clock, env: { ADMIN_ADDRESSES: ADDR }, log: () => {} });
  ok(svc2.state.users[ADDR] && svc2.state.payouts.length === 2 && svc2.state.secret === svc.state.secret, 'a restart keeps players, payouts and the login secret');
  // prices: Kraken formats, with a fake network
  const mk = require('../src/game_prices');
  const fake = async (url) => ({ ok: true, json: async () => url.includes('Ticker') ? { result: { XXBTZUSD: { c: ['70123.4', '1'] } } } : { result: { XXBTZUSD: [[1000, '1', '1', '1', '70000.5'], [1060, '1', '1', '1', '70010.5']], last: 1060 } } });
  const pr = mk({ fetchFn: fake, now: () => 5000000 });
  ok((await pr.spot('BTC')) === 70123.4, 'spot price from Kraken');
  ok((await pr.at('BTC', 1060000)) === 70010.5 && (await pr.at('BTC', 5000000)) === null, 'price at a past minute; none for the future');
  const dead = async () => { throw new Error('down'); };
  ok((await mk({ fetchFn: dead }).spot('BTC')) === null, 'no price when every source is down');
  srv.close();
  console.log(fails ? 'FAILED ' + fails : 'ALL PASS');
  process.exit(fails ? 1 : 0);
})().catch((e) => { console.log('CRASH', e); process.exit(1); });
