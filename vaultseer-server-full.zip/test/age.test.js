'use strict';
// Stakes above $100 need an age confirmation signed by the attester; smaller stakes do not.
const createServer = require('../src/server'); const makeAge = require('../src/age'); const C = require('../src/crypto');
const WebSocket = require('ws');
const A = '0x' + 'a'.repeat(40), B = '0x' + 'b'.repeat(40);
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log('FAIL', m); } else console.log('ok  ', m); };
(async () => {
  const KEY = '0x' + (0x7a11ce5e17n).toString(16).padStart(64, '0'), attester = C.addressOfKey(KEY), age = makeAge({ attester });
  const sign = (addr) => { const h = C.ethHash(Buffer.from(age.message(addr))); return C.sigHex(C.sign(h, BigInt(KEY))); };
  const codeA = sign(A);
  ok(age.check(A, codeA), 'a code made by the attester for this address is accepted');
  ok(!age.check(B, codeA), 'the same code does not work for another address');
  ok(!age.check(A, 'nonsense') && !age.check(A, undefined) && !makeAge({}).check(A, codeA), 'garbage / no attester configured -> refused');
  const chain = { getMatch: async (id) => id === 1n ? { players: [A, B], game: 'chess', status: 2, stake: 500n * 1000000n } : id === 2n ? { players: [A, B], game: 'chess', status: 2, stake: 100n * 1000000n } : { status: 1 } };
  const s = createServer({ chain, signer: { address: '0xs', sign: async () => 'S' }, port: 0, verify: (id, sig) => sig, age });
  const port = await s.listen();
  const open = (who, id, code) => new Promise((res) => { const ws = new WebSocket('ws://127.0.0.1:' + port); const inbox = []; ws.on('message', (d) => inbox.push(JSON.parse(String(d)))); ws.on('open', () => { ws.send(JSON.stringify({ t: 'hello', id: String(id), sig: who, age: code })); setTimeout(() => res({ ws, inbox }), 150); }); });
  const last = (c) => c.inbox[c.inbox.length - 1];
  let x = await open(A, 1); ok(last(x).err === 'age verification required', '$500 match: no code -> refused');
  x = await open(A, 1, 'bad'); ok(last(x).err === 'age verification required', '$500 match: wrong code -> refused');
  x = await open(A, 1, codeA); ok(last(x).t === 'state', '$500 match: right code -> in');
  let y = await open(B, 1, codeA); ok(last(y).err === 'age verification required', '$500 match: the opponent needs his own code');
  y = await open(B, 1, sign(B)); ok(last(y).t === 'state', '$500 match: opponent with his own code -> in');
  x = await open(A, 2); ok(last(x).t === 'state', '$100 match: no code needed');
  s.close(); console.log(fails ? fails + ' FAILED' : 'ALL OK'); process.exit(fails ? 1 : 0);
})();
