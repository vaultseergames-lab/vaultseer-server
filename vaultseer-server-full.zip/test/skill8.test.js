'use strict';
// Rules tests for the skill games of part 8.
const VG = require('../src/games1.js'); require('../src/games7.js'); require('../src/games8.js');
const SK = VG.sk; const J = JSON.stringify;
let bad = 0, n = 0; const ok = (c, m, x) => { n++; if (!c) { bad++; console.log('FAIL', m, x === undefined ? '' : x); } };
const rngOf = (s) => VG.rng(s);

function playout(E, seed, maxPlies) {
  const r = rngOf(seed); let st = E.init(2, seed & 1), steps = 0;
  while (!st.over && steps < (maxPlies || 1500)) {
    const ms = E.moves(st); ok(ms.length > 0, E.id + ': an unfinished game has a move', steps); if (!ms.length) return null;
    const mv = ms[Math.floor(r() * ms.length)];
    const f = E.find(st, JSON.parse(J(mv))); ok(f && SK.sameMove(f, mv), E.id + ': find accepts every engine move', J(mv));
    const c = E.copy(st); ok(J(c) === J(st), E.id + ': copy equals state');
    E.apply(st, mv); steps++;
  }
  ok(st.over, E.id + ': ends (seed ' + seed + ', ' + steps + ')');
  const m = SK.mask(st); ok(m === 1 || m === 2 || m === 3, E.id + ': mask', m);
  return st;
}
const GAMES = { go: 8, amazons: 6, lines: 12, santorini: 25 };
for (const id of Object.keys(GAMES)) {
  const E = SK.games[id]; ok(!!E, id + ' registered');
  const ends = [0, 0, 0, 0];
  for (let s = 1; s <= GAMES[id]; s++) { const st = playout(E, s * 7919, id === 'amazons' ? 200 : 1500); if (st) ends[SK.mask(st)]++; }
  ok(ends[1] + ends[2] + ends[3] > 0, id + ': games finish', J(ends));
  const st = E.init(2, 0), snap = J(st);
  const junk = [null, undefined, 0, -1, 1e9, NaN, '', 'x', [], {}, { c: 'a' }, { c: -1 }, { c: 1e9 }, { c: 1.5 }, { c: 0, extra: 1 }, { f: 0, t: 0 }, { f: 1.5, t: 2, a: 3 }, { f: -1, t: 0, a: 0 }, { p: 99 }, { w: 5, m: 1, b: 2 }, { pass: 2 }, { pass: 1, c: 1 }];
  for (const bd of junk) { const f = E.find(st, bd); if (f) { ok(E.moves(st).map(J).indexOf(J(f)) >= 0, id + ': find returns only real moves', J(bd)); } }
  ok(J(st) === snap, id + ': find does not change state');
  for (let lv = 0; lv <= 2; lv++) {
    let s2 = E.init(2, 1); const r = rngOf(100 + lv); const t0 = Date.now();
    for (let k = 0; k < 8 && !s2.over; k++) {
      const mv = E.bot(s2, lv, r); const f = E.find(s2, JSON.parse(J(mv))); ok(!!f, id + ': bot level ' + lv + ' legal', J(mv)); if (!f) break; E.apply(s2, f);
    }
    ok(Date.now() - t0 < 20000, id + ': bot level ' + lv + ' is fast enough', Date.now() - t0);
  }
}

// ---- Go ----
{ const E = SK.games.go; const put = (st, cells, p) => cells.forEach((c) => { st.b[c] = p; });
  let st = E.init(2, 0); ok(E.moves(st).length === 82, 'go: 81 points + pass');
  // capture a corner stone: white at 0, black at 1 and 9 -> black plays the second
  st = E.init(2, 0); st.b[0] = 2; st.b[1] = 1; E.apply(st, { c: 9 }); ok(st.b[0] === 0 && st.cap[0] === 1, 'go: a stone without liberties is captured');
  // suicide is illegal, but a capturing move is fine
  st = E.init(2, 0); put(st, [1, 9], 2); st.turn = 0; ok(!E.find(st, { c: 0 }), 'go: suicide refused');
  st = E.init(2, 0); put(st, [1, 9], 2); put(st, [2, 10, 18], 1); put(st, [0], 0); st.turn = 0;
  // point 0 has white neighbours 1 and 9; 1 has liberty? neighbours of 1 are 0, 2, 10: black at 2, 10 -> only liberty 0; 9: neighbours 0,10,18 black -> only liberty 0
  ok(!!E.find(st, { c: 0 }), 'go: a move that captures is not suicide');
  E.apply(st, { c: 0 }); ok(st.b[1] === 0 && st.b[9] === 0 && st.b[0] === 1, 'go: both groups were captured');
  // ko
  st = E.init(2, 0);
  // black: 1, 9, 12 wait: standard ko diamond around points 10 (white) and 11 (empty/black)
  put(st, [2, 10, 20], 1); put(st, [3, 12, 21], 2); put(st, [11], 2); st.turn = 0; // white stone at 11 surrounded: 2,10,20 black; 12 white.. rebuild properly below
  st = E.init(2, 0);
  put(st, [1, 9, 11], 1);          // black around point 10... white stone at 10 has liberties 19 and... build a tiny ko on the top edge
  st = E.init(2, 0);
  // ko shape: black stones 1, 9, 11 | white stones 2, 12, 20 around empty 10? Use the classic: B at (0,1),(1,0),(2,1)  W at (0,2),(1,3),(2,2)  W stone at (1,1)->black to capture at (1,2)
  const rc = (r, c) => r * 9 + c;
  put(st, [rc(0, 1), rc(1, 0), rc(2, 1), rc(1, 2)], 1);                // black ring around (1,1) except... (1,2) is black stone
  st = E.init(2, 0);
  put(st, [rc(0, 1), rc(1, 0), rc(2, 1)], 2); st.b[rc(1, 2)] = 2;       // white around hole (1,1)
  put(st, [rc(0, 2), rc(1, 3), rc(2, 2)], 1); st.b[rc(1, 1)] = 1;       // black stone sits at (1,1), white stone at (1,2): black stone has one liberty? neighbours (0,1)W (1,0)W (2,1)W (1,2)W -> zero libs
  st.b[rc(1, 1)] = 0; st.turn = 1;                                       // white to play at (1,1)? instead test: black plays (1,1) capturing (1,2)
  st.turn = 0; ok(!!E.find(st, { c: rc(1, 1) }), 'go: ko capture is possible at first');
  E.apply(st, { c: rc(1, 1) }); ok(st.b[rc(1, 2)] === 0 && st.ko === rc(1, 2), 'go: ko point is marked after a single capture', st.ko);
  ok(!E.find(st, { c: rc(1, 2) }), 'go: immediate recapture in a ko is refused');
  E.apply(st, { c: 80 }); E.apply(st, { c: 79 }); ok(E.moves(st).length > 0, 'go: other moves still fine');
  // scoring
  st = E.init(2, 0); E.apply(st, { pass: 1 }); ok(!st.over, 'go: one pass does not end'); E.apply(st, { pass: 1 }); ok(st.over && J(st.winners) === '[1]' && st.score[1] === 7.5, 'go: empty board, white wins by komi');
  st = E.init(2, 0); put(st, [rc(4, 4)], 1); E.apply(st, { pass: 1 }); E.apply(st, { pass: 1 }); ok(st.over && J(st.winners) === '[0]' && st.score[0] === 81, 'go: one black stone owns the whole board', J(st.score));
  st = E.init(2, 0); for (let r = 0; r < 9; r++) { st.b[rc(r, 4)] = 1; } for (let r = 0; r < 9; r++) st.b[rc(r, 5)] = 2; E.apply(st, { pass: 1 }); E.apply(st, { pass: 1 });
  ok(J(st.score) === J([9 + 36, 9 + 27 + 7.5]) || J(st.score) === J([45, 43.5]), 'go: area scoring counts stones and territory', J(st.score));
  // a pass after a move resets the counter
  st = E.init(2, 0); E.apply(st, { pass: 1 }); E.apply(st, { c: 40 }); E.apply(st, { pass: 1 }); ok(!st.over, 'go: passes must be consecutive');
  // bots: after 90 plies the strong bot holds more area than the weak one
  let w = 0; for (let g = 0; g < 2; g++) { let s = E.init(2, g & 1); const r = rngOf(g + 5); let k = 0; const strong = g & 1 ? 1 : 0; while (!s.over && k < 90) { const lv = s.turn === strong ? 2 : 0; E.apply(s, E.bot(s, lv, r)); k++; } const a = E.area(s.b); if (s.over ? (s.winners[0] === strong) : a[strong] >= a[1 - strong]) w++; }
  ok(w >= 1, 'go: strong bot is not behind the weak one', w);
}

// ---- Amazons ----
{ const E = SK.games.amazons; let st = E.init(2, 0);
  ok(E.moves(st).length === 2176, 'amazons: 2176 opening moves', E.moves(st).length);
  ok(E.find(st, { f: 60, t: 50, a: 60 }) !== null, 'amazons: the arrow may go back to the square the queen left');
  ok(!E.find(st, { f: 60, t: 50, a: 50 }), 'amazons: the arrow cannot land on the queen');
  ok(!E.find(st, { f: 3, t: 13, a: 14 }), 'amazons: you cannot move the opponent queen');
  // blocked player loses
  const s = E.init(2, 0); s.b = s.b.map(() => 3); s.b[0] = 1; s.b[99] = 2; s.b[98] = 0; s.b[88] = 0; s.b[89] = 0; s.b[1] = 0; s.b[10] = 0; s.b[11] = 0;
  s.turn = 0; E.apply(s, { f: 0, t: 1, a: 0 }); ok(s.over || E.moves(s).length > 0, 'amazons: game goes on or ends cleanly');
  const t = E.init(2, 0); t.b = t.b.map(() => 3); t.b[0] = 1; t.b[1] = 0; t.b[99] = 2; t.turn = 0;
  E.apply(t, { f: 0, t: 1, a: 0 }); ok(t.over && J(t.winners) === '[0]', 'amazons: the player who cannot move loses', J([t.over, t.winners]));
  let w = 0; for (let g = 0; g < 4; g++) { let s2 = E.init(2, g & 1); const r = rngOf(g + 9); let k = 0; while (!s2.over && k < 150) { const lv = s2.turn === (g & 1 ? 1 : 0) ? 2 : 0; E.apply(s2, E.bot(s2, lv, r)); k++; } if (s2.over && s2.winners && s2.winners[0] === (g & 1 ? 1 : 0)) w++; }
  ok(w >= 3, 'amazons: strong bot beats the weak one', w);
}

// ---- Lines of Action ----
{ const E = SK.games.lines; let st = E.init(2, 0);
  ok(E.moves(st).length === 36, 'lines: 36 opening moves', E.moves(st).length);
  const c = (r, cc) => r * 8 + cc;
  // the move length equals the number of checkers on the line
  const s = E.init(2, 0); s.b = s.b.map(() => 0); s.b[c(0, 0)] = 1; s.b[c(0, 3)] = 1; s.b[c(7, 7)] = 2; s.b[c(5, 5)] = 2; s.turn = 0;
  ok(E.find(s, { f: c(0, 0), t: c(0, 2) }) && !E.find(s, { f: c(0, 0), t: c(0, 1) }) && E.find(s, { f: c(0, 3), t: c(0, 5) }) && E.find(s, { f: c(0, 3), t: c(0, 1) }), 'lines: exactly as many squares as checkers on the line');
  ok(E.find(s, { f: c(0, 0), t: c(2, 0) }) === null, 'lines: wrong length refused');
  // jumping own is fine, jumping the opponent is not, capturing by landing is allowed
  const j = E.init(2, 0); j.b = j.b.map(() => 0); j.b[c(0, 0)] = 1; j.b[c(0, 1)] = 1; j.b[c(0, 2)] = 2; j.b[c(7, 7)] = 2; j.b[c(6, 7)] = 1; j.turn = 0;
  ok(!E.find(j, { f: c(0, 0), t: c(0, 3) }), 'lines: cannot jump the opponent');
  const j2 = E.init(2, 0); j2.b = j2.b.map(() => 0); j2.b[c(0, 0)] = 1; j2.b[c(0, 1)] = 1; j2.b[c(0, 2)] = 2; j2.b[c(5, 5)] = 2; j2.turn = 0;
  ok(!!E.find(j2, { f: c(0, 1), t: c(0, 3) }) === false, 'lines: jump check');
  const j3 = E.init(2, 0); j3.b = j3.b.map(() => 0); j3.b[c(0, 0)] = 1; j3.b[c(0, 2)] = 2; j3.b[c(0, 1)] = 1; j3.b[c(7, 7)] = 2; j3.turn = 0;
  ok(!!E.find(j3, { f: c(0, 1), t: c(0, 3) }) === false, 'lines: need 3 steps and an opponent blocks');
  const k = E.init(2, 0); k.b = k.b.map(() => 0); k.b[c(0, 0)] = 1; k.b[c(0, 2)] = 2; k.b[c(7, 7)] = 2; k.b[c(4, 4)] = 1; k.turn = 0;
  E.apply(k, { f: c(0, 0), t: c(0, 2) }); ok(k.b[c(0, 2)] === 1 && k.b[c(0, 0)] === 0, 'lines: capture by landing');
  // win by connecting
  const w = E.init(2, 0); w.b = w.b.map(() => 0); w.b[c(3, 3)] = 1; w.b[c(3, 4)] = 1; w.b[c(3, 6)] = 1; w.b[c(0, 0)] = 2; w.b[c(7, 7)] = 2; w.turn = 0;
  // moving (3,6) two squares left?? needs count 3 on the row -> lands (3,4)? occupied own. use (3,6)->(3,3)? own. instead: connect through vertical
  const w2 = E.init(2, 0); w2.b = w2.b.map(() => 0); w2.b[c(3, 3)] = 1; w2.b[c(3, 4)] = 1; w2.b[c(5, 5)] = 1; w2.b[c(0, 0)] = 2; w2.b[c(7, 7)] = 2; w2.turn = 0;
  const mvList = E.moves(w2).filter((m) => { const t = E.copy(w2); E.apply(t, m); return t.over; });
  ok(E.connected(w2.b, 1) === false && E.connected(w.b, 2) === false, 'lines: connectivity');
  const cn = E.init(2, 0); cn.b = cn.b.map(() => 0); cn.b[c(3, 3)] = 1; cn.b[c(3, 4)] = 1; cn.b[c(4, 5)] = 1; ok(E.connected(cn.b, 1), 'lines: diagonal neighbours are connected');
  let wins = 0; for (let g = 0; g < 6; g++) { let s2 = E.init(2, g & 1); const r = rngOf(g + 9); let kk = 0; while (!s2.over && kk < 200) { const lv = s2.turn === (g & 1 ? 1 : 0) ? 2 : 0; E.apply(s2, E.bot(s2, lv, r)); kk++; } if (s2.over && s2.winners && s2.winners[0] === (g & 1 ? 1 : 0)) wins++; }
  ok(wins >= 4, 'lines: strong bot beats the weak one', wins);
}

// ---- Santorini ----
{ const E = SK.games.santorini; let st = E.init(2, 0);
  ok(E.moves(st).length === 25 && st.place === 4, 'santorini: 25 placement squares at the start');
  E.apply(st, { p: 12 }); ok(!E.find(st, { p: 12 }), 'santorini: occupied square refused'); E.apply(st, { p: 6 }); E.apply(st, { p: 18 }); E.apply(st, { p: 8 });
  ok(st.place === 0 && st.turn === 0 && J(st.w) === J([[12, 18], [6, 8]]), 'santorini: placement done, first player moves', J(st.w));
  ok(E.moves(st).every((m) => m.b >= 0), 'santorini: normal moves have a build square');
  // cannot climb two levels, cannot enter domes, win on level 3
  const s = E.init(2, 0); s.place = 0; s.w = [[12, 0], [24, 4]]; s.h[13] = 2; s.h[11] = 1; s.turn = 0;
  ok(!E.find(s, { w: 0, m: 13, b: 14 }) && !!E.find(s, { w: 0, m: 11, b: 10 }), 'santorini: one level up at most');
  s.h[12] = 2; s.h[13] = 3; ok(!!E.find(s, { w: 0, m: 13, b: -1 }), 'santorini: stepping onto level 3 wins');
  E.apply(s, { w: 0, m: 13, b: -1 }); ok(s.over && J(s.winners) === '[0]', 'santorini: win recorded');
  const d = E.init(2, 0); d.place = 0; d.w = [[12, 0], [24, 4]]; d.h[13] = 4; d.turn = 0; ok(!E.find(d, { w: 0, m: 13, b: 14 }), 'santorini: dome blocks');
  const b = E.init(2, 0); b.place = 0; b.w = [[12, 0], [24, 4]]; b.turn = 0; E.apply(b, { w: 0, m: 13, b: 12 }); ok(b.h[12] === 1 && b.w[0][0] === 13, 'santorini: you may build where you stood');
  const lv = E.init(2, 0); lv.place = 0; lv.w = [[12, 0], [24, 4]]; lv.turn = 0; ok(!E.find(lv, { w: 0, m: 13, b: 0 }), 'santorini: build must touch the moved builder');
  let wins = 0; for (let g = 0; g < 6; g++) { let s2 = E.init(2, g & 1); const r = rngOf(g + 9); let kk = 0; while (!s2.over && kk < 200) { const l = s2.turn === (g & 1 ? 1 : 0) ? 2 : 0; E.apply(s2, E.bot(s2, l, r)); kk++; } if (s2.over && s2.winners && s2.winners[0] === (g & 1 ? 1 : 0)) wins++; }
  ok(wins >= 4, 'santorini: strong bot beats the weak one', wins);
}
console.log(bad ? bad + ' FAILED of ' + n : 'ALL OK (' + n + ' checks)'); process.exit(bad ? 1 : 0);
