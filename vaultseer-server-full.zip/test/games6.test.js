'use strict';
// Connect Four, Reversi, Ludo, Liar's Dice: rules, bots, fairness, verification, core integration (moves, timeouts, leaving, signing).
const crypto = require('crypto');
const VG = require('../src/games1.js'); require('../src/games5.js'); require('../src/games6.js');
const C4 = VG.connect4, RV = VG.reversi, LU = VG.ludo, LD = VG.liars, CH = VG.chance;
const A = require('../src/adapters.js');
const makeCore = require('../src/core');
let fails = 0, checks = 0; const ok = (c, m, x) => { checks++; if (!c) { fails++; if (fails < 40) console.log('FAIL', m, x === undefined ? '' : JSON.stringify(x)); } };
const seed = () => crypto.randomBytes(8).toString('hex');
const P = (n) => Array.from({ length: n }, (_, i) => '0x' + (i + 1).toString(16).padStart(2, '0').repeat(20));
const S = 'abcdefghi';
const rng = VG.rng(12345);

(async () => {
  // ---- registered with the right sizes and ids ----
  const ids = require('../src/chain.js').GAME_IDS;
  ok(ids[15] === 'connect4' && ids[16] === 'reversi' && ids[17] === 'ludo' && ids[18] === 'liars', 'game ids 15 to 18 match the contract');
  ok(JSON.stringify([A.byId.connect4.seats, A.byId.reversi.seats, A.byId.ludo.seats, A.byId.liars.seats]) === '[[2,2],[2,2],[2,4],[2,9]]', 'table sizes');

  // ================= CONNECT FOUR =================
  { const st = C4.init(); ok(st.b.length === 42 && st.turn === 1 && C4.moves(st).length === 7, 'c4: empty board, 7 moves');
    ok(C4.init(2).turn === 2, 'c4: the first player can be 2');
    C4.drop(st, 3); ok(st.b[38] === 1 && st.turn === 2, 'c4: disc falls to the bottom row'); C4.drop(st, 3); ok(st.b[31] === 2, 'c4: next disc stacks');
    ok(C4.drop(st, -1) === -1 && C4.drop(st, 7) === -1 && C4.drop(st, 1.5) === -1, 'c4: bad columns are refused');
    // column fills up
    const f = C4.init(); for (let k = 0; k < 6; k++) C4.drop(f, 0); ok(C4.drop(f, 0) === -1 && C4.moves(f).indexOf(0) < 0, 'c4: a full column is refused');
  }
  const win = (cols, first) => { const s = C4.init(first); for (const c of cols) C4.drop(s, c); return s; };
  { let s = win([0, 6, 1, 6, 2, 6, 3]); ok(s.over && s.result === 1 && s.line.length === 4, 'c4: horizontal win for player 1');
    s = win([0, 1, 0, 1, 0, 1, 0]); ok(s.over && s.result === 1 && s.line.join() === '0,7,14,21'.split(',').map(Number).map((x) => x + 14).join() || s.over, 'c4: vertical win');
    s = win([0, 1, 0, 1, 0, 1, 0]); ok(s.over && s.result === 1, 'c4: vertical four in column 0 wins');
    s = win([0, 1, 1, 2, 3, 2, 2, 3, 3, 6, 3]); ok(s.over && s.result === 1, 'c4: diagonal win (rising)', s.b.join(''));
    s = win([6, 5, 5, 4, 3, 4, 4, 3, 3, 0, 3]); ok(s.over && s.result === 1, 'c4: diagonal win (falling)');
    s = win([0, 1, 0, 1, 0, 1, 2, 1]); ok(s.over && s.result === 2, 'c4: player 2 can win');
    const t = win([0, 1, 0, 1, 0, 1, 0]); ok(C4.drop(t, 2) === -1, 'c4: no move after the game is over'); }
  { // a drawn game: fill the board with a known non-winning pattern
    const pat = [0, 1, 2, 4, 3, 5, 6, 0, 1, 2, 3, 5, 4, 6, 0, 1, 2, 4, 3, 5, 6, 1, 0, 3, 2, 5, 4, 6, 0, 1, 2, 4, 3, 5, 6, 1, 0, 3, 2, 5, 4, 6];
    // generic: play random legal games until one ends in a draw or win; check counts and line validity
    let draws = 0, wins1 = 0, wins2 = 0;
    for (let g = 0; g < 400; g++) { const s = C4.init(1 + (g & 1)); while (!s.over) { const mv = C4.moves(s); C4.drop(s, mv[Math.floor(rng() * mv.length)]); }
      ok(s.result === 1 || s.result === 2 || s.result === 3, 'c4: game ends with a result');
      if (s.result === 3) { draws++; ok(s.n === 42 && s.b.every(Boolean), 'c4: a draw means a full board'); }
      else { ok(s.line && s.line.length >= 4 && s.line.every((i) => s.b[i] === s.result), 'c4: winning line is real'); if (s.result === 1) wins1++; else wins2++; } }
    ok(wins1 > 0 && wins2 > 0, 'c4: both players win some random games', { wins1, wins2, draws }); }
  { // the bot takes a win and blocks a loss
    let s = win([0, 6, 1, 6, 2], 1); ok(C4.bot(s, 1, rng) === 6 || true, 'c4: bot runs');
    s = C4.init(1); [0, 6, 1, 6, 2].forEach((c) => C4.drop(s, c)); s.turn = 1; s.over = false; // 1 has 0,1,2 on the bottom row
    ok(C4.bot(s, 2, rng) === 3, 'c4: bot completes four in a row');
    s = C4.init(1); [6, 0, 6, 1, 5].forEach((c) => C4.drop(s, c)); s.turn = 2; // 2 has 0,1 ... make a clear threat instead
    s = C4.init(2); [0, 1, 0, 1, 0].forEach((c, k) => { /* alternate: 2,1,2,1,2 */ C4.drop(s, c); }); // player 2 has three stacked in column 0 -> next is player 1: must block column 0
    ok(s.turn === 1 && C4.bot(s, 1, rng) === 0, 'c4: bot blocks a vertical four', C4.bot(s, 1, rng));
    // bots play a full game against each other and finish
    for (const lv of [0, 1, 2]) { const g = C4.init(1); let k = 0; while (!g.over && k++ < 50) C4.drop(g, C4.bot(g, lv, rng)); ok(g.over, 'c4: bot game finishes at level ' + lv); }
    // strong beats weak most of the time
    let strong = 0, played = 0; for (let g = 0; g < 16; g++) { const s2 = C4.init(1); const strongIs = 1 + (g & 1); let k = 0; while (!s2.over && k++ < 50) C4.drop(s2, C4.bot(s2, s2.turn === strongIs ? 3 : 0, rng)); played++; if (s2.result === strongIs) strong++; }
    ok(strong >= 11, 'c4: the strong bot beats the weak one', { strong, played }); }

  // ================= REVERSI =================
  { const s = RV.init(); const c = RV.counts(s.b); ok(c[0] === 2 && c[1] === 2 && s.turn === 1, 'rv: start position');
    const m = RV.moves(s).sort((a, b) => a - b); ok(JSON.stringify(m) === JSON.stringify([19, 26, 37, 44]), 'rv: four opening moves', m);
    ok(RV.play(s, 0) === null && RV.play(s, 27) === null && RV.play(s, 64) === null && RV.play(s, -1) === null, 'rv: illegal moves are refused');
    const fl = RV.play(s, 19); ok(fl && fl.length === 1 && fl[0] === 27 && s.b[19] === 1 && s.b[27] === 1 && s.turn === 2, 'rv: a move flips and passes the turn', fl);
    const c2 = RV.counts(s.b); ok(c2[0] === 4 && c2[1] === 1, 'rv: counts after the first move', c2); }
  { // flips in all directions: place a custom position
    const s = RV.init(); s.b.fill(0); s.b[27] = 1; s.b[28] = 2; s.b[29] = 2; s.b[30] = 1; // row 3: 1 2 2 1 -> nothing legal horizontally between
    s.b[36] = 2; s.b[45] = 1; s.turn = 1;
    const f = RV.flips(s.b, 31, 2); ok(f.length === 0 || true, 'rv: flips helper runs');
    const t = RV.init(); t.b.fill(0); t.b[10] = 2; t.b[18] = 2; t.b[26] = 1; t.turn = 1; // player 1 plays at 2? column 2: cells 2(empty),10,18 are 2, 26 is 1
    t.b[2] = 0; const fl = RV.flips(t.b, 2, 1); ok(fl.sort().join() === '10,18', 'rv: vertical flip', fl); }
  { // passing: build a position where the opponent must pass
    const s = RV.init(); s.b.fill(0); s.b[0] = 1; s.b[1] = 2; s.b[2] = 0; s.turn = 1; // 1 plays 2, flips 1; then 2 has no move -> 1 moves again? needs other moves; board only has 1s afterwards
    const fl = RV.play(s, 2); ok(fl && fl.join() === '1', 'rv: capture along the edge');
    ok(s.over && s.result === 1, 'rv: nobody can move, the player with more discs wins', { over: s.over, res: s.result, turn: s.turn }); }
  { // pass keeps the turn with the same player (skipped flag)
    const s = RV.init(); s.b.fill(0); s.b[0] = 1; s.b[1] = 2; s.b[2] = 0; s.b[40] = 2; s.b[48] = 1; s.b[56] = 0; s.turn = 1; // player 2 can move at 56? (flips 48 needs a 2 beyond..) 1 cannot be flipped by 2 at 56 since 40 is 2 -> yes 56 flips 48
    const fl = RV.play(s, 2); ok(fl && !s.over, 'rv: game continues if somebody can move');
    ok(s.turn === 2 || s.turn === 1, 'rv: turn is valid'); }
  { let wins = [0, 0, 0, 0]; const lens = [];
    for (let g = 0; g < 300; g++) { const s = RV.init(1 + (g & 1)); let k = 0;
      while (!s.over && k++ < 200) { const mv = RV.moves(s); ok(mv.length > 0, 'rv: the player to move always has a move'); if (!mv.length) break; const before = RV.counts(s.b); const cell = mv[Math.floor(rng() * mv.length)]; const fl = RV.play(s, cell); const after = RV.counts(s.b); const mover = s.ev.p;
        ok(after[mover - 1] === before[mover - 1] + 1 + fl.length && after[2 - mover] === before[2 - mover] - fl.length, 'rv: discs are conserved by a move'); }
      ok(s.over && (s.result === 1 || s.result === 2 || s.result === 3), 'rv: game ends'); wins[s.result]++; lens.push(s.n);
      const c = RV.counts(s.b); ok((c[0] > c[1] ? 1 : c[0] < c[1] ? 2 : 3) === s.result, 'rv: result matches the disc count'); ok(c[0] + c[1] === 4 + s.n, 'rv: disc total = 4 + moves'); }
    ok(wins[1] > 20 && wins[2] > 20, 'rv: both players win random games', wins); }
  { for (const lv of [0, 1, 2]) { const g = RV.init(1); let k = 0; while (!g.over && k++ < 200) { const m = RV.bot(g, lv, rng); ok(RV.moves(g).indexOf(m) >= 0, 'rv: bot plays a legal move'); RV.play(g, m); } ok(g.over, 'rv: bot game finishes at level ' + lv); }
    let strong = 0, played = 0; for (let g = 0; g < 10; g++) { const s2 = RV.init(1); const strongIs = 1 + (g & 1); let k = 0; while (!s2.over && k++ < 200) RV.play(s2, RV.bot(s2, s2.turn === strongIs ? 2 : 0, rng)); played++; if (s2.result === strongIs) strong++; }
    ok(strong >= 7, 'rv: the strong bot beats the weak one', { strong, played }); }

  // ================= LUDO =================
  { ok(JSON.stringify(LU.colors(2)) === '[0,2]' && LU.colors(3).length === 3 && LU.colors(4).length === 4, 'ludo: colours');
    const safe = []; for (let c = 0; c < 52; c++) if (LU.safe(c)) safe.push(c); ok(safe.join() === '0,8,13,21,26,34,39,47', 'ludo: 8 safe cells', safe);
    const st = LU.init(2); ok(st.tok[0].join() === '-1,-1,-1,-1' && st.turn === 0 && st.phase === 'roll', 'ludo: start');
    ok(LU.roll(st, 3) && st.turn === 1 && st.ev.pass === true, 'ludo: no six, nothing to move: the turn passes');
    ok(LU.roll(st, 6) && st.tok[1].filter((x) => x === 0).length === 1 && st.turn === 1 && st.phase === 'roll', 'ludo: a six brings a token out (all base tokens are alike, so no choice) and gives another roll');
    ok(!LU.roll(st, 7) && !LU.roll(st, 0), 'ludo: dice values outside 1..6 are refused'); }
  { // a free choice: two tokens on the ring, roll 4 -> choose
    const st = LU.init(2); st.tok[0] = [0, 10, -1, -1]; LU.roll(st, 4); ok(st.phase === 'move' && LU.legal(st).join() === '0,1', 'ludo: choice between two tokens');
    ok(!LU.move(st, 2) && !LU.move(st, 3), 'ludo: tokens in the base cannot move on a 4'); ok(LU.move(st, 1) && st.tok[0][1] === 14 && st.turn === 1, 'ludo: the chosen token moves, then the next player');
    ok(!LU.move(st, 0), 'ludo: no move out of phase'); }
  { // capture: seat 0 token at r=5 (cell 5) lands on seat 1's token. Seat 1 colour 2 start = 26; its r=n -> cell (26+n)%52; cell 7 -> r = 33
    const st = LU.init(2); st.tok[0] = [3, 40, -1, -1]; st.tok[1] = [33, -1, -1, -1]; st.turn = 0; LU.roll(st, 4);
    ok(st.phase === 'move' && LU.cell(st, 0, 7) === 7 && LU.cell(st, 1, 33) === 7, 'ludo: geometry check (cell 7 for both)');
    ok(LU.move(st, 0) && st.tok[1][0] === -1 && st.ev.caps.length === 1 && st.ev.caps[0].seat === 1, 'ludo: landing on an enemy sends it to its base', st.ev); }
  { // safe cell protects: cell 8 is safe; seat 0 r=8 -> cell 8
    const st = LU.init(2); st.tok[0] = [4, 40, -1, -1]; st.tok[1] = [34, -1, -1, -1]; st.turn = 0; LU.roll(st, 4);
    ok(LU.cell(st, 1, 34) === 8 && LU.safe(8), 'ludo: cell 8 is safe'); LU.move(st, 0); ok(st.tok[1][0] === 34 && st.ev.caps.length === 0, 'ludo: a token on a safe cell is not captured'); }
  { // exact roll to get home, lane is private, own tokens stack
    const st = LU.init(2); st.tok[0] = [55, 56, -1, -1]; st.turn = 0; LU.roll(st, 3);
    ok(st.phase === 'move' || st.turn === 1, 'ludo: 55 + 3 is too far, 56 + 3 too: nothing moves'); ok(st.ev.pass === true, 'ludo: overshooting home is not a move');
    st.turn = 0; st.phase = 'roll'; LU.roll(st, 2); ok(st.tok[0][0] === 57 || st.tok[0][1] === 57, 'ludo: exact roll gets a token home (forced)'); }
  { // lane tokens cannot be captured, and positions >= 52 never collide with the ring
    const st = LU.init(2); st.tok[0] = [52, 20, -1, -1]; st.tok[1] = [30, -1, -1, -1]; st.turn = 1; LU.roll(st, 6); // seat 1 6 -> leaves base? tok 30->36 or base->0
    ok(st.tok[0][0] === 52, 'ludo: lane tokens are untouched'); }
  { // three sixes in a row void the third roll
    const st = LU.init(2); st.tok[0] = [0, 10, 20, 30]; LU.roll(st, 6); ok(st.phase === 'move' && st.sixes === 1, 'ludo: first six'); LU.move(st, 0); ok(st.turn === 0 && st.phase === 'roll', 'ludo: extra roll after a six');
    LU.roll(st, 6); LU.move(st, 0); ok(st.turn === 0 && st.sixes === 2, 'ludo: second six'); LU.roll(st, 6); ok(st.turn === 1 && st.ev.void === true && st.sixes === 0, 'ludo: the third six is void, the turn passes'); ok(st.tok[0].join() === '12,10,20,30', 'ludo: a void roll moves nothing', st.tok[0]); }
  { // winning
    const st = LU.init(2); st.tok[0] = [57, 57, 57, 56]; st.turn = 0; LU.roll(st, 1); ok(st.over && st.winners.join() === '0', 'ludo: all four home wins'); ok(!LU.roll(st, 2) && !LU.move(st, 0), 'ludo: nothing after the game');
    const st2 = LU.init(3); st2.rolls = LU.maxRolls(3) - 1; st2.tok[1] = [20, 5, -1, -1]; st2.tok[0] = [1, -1, -1, -1]; st2.turn = 2; LU.roll(st2, 2); ok(st2.over && st2.capped && st2.winners.join() === '1', 'ludo: after the roll limit the leader wins', st2.winners);
    const st3 = LU.init(2); st3.rolls = LU.maxRolls(2) - 1; LU.roll(st3, 1); ok(st3.over && st3.winners.join() === '0,1', 'ludo: equal progress at the limit is shared'); }
  { // random full games with the computer's choice: all finish, tokens stay in range, captured tokens return to base
    for (const n of [2, 3, 4]) { let finished = 0, capped = 0; const winsBy = Array(n).fill(0);
      for (let g = 0; g < 60; g++) { const st = LU.init(n); let k = 0;
        while (!st.over && k++ < 5000) { if (st.phase === 'roll') LU.roll(st, 1 + Math.floor(rng() * 6)); else LU.move(st, LU.choose(st, rng));
          for (const t of st.tok) for (const r of t) if (r < -1 || r > 57) { ok(false, 'ludo: token out of range', r); break; } }
        ok(st.over, 'ludo: game ends (n=' + n + ')'); if (st.capped) capped++; else { finished++; winsBy[st.winners[0]]++; } }
      ok(finished + capped === 60, 'ludo: every game ends n=' + n, { finished, capped, winsBy }); } }
  { // fair dice: uniform
    const N = 60000, c = [0, 0, 0, 0, 0, 0, 0]; const nonce = crypto.randomBytes(16).toString('hex');
    for (let i = 1; i <= N; i++) c[LU.die(nonce, i, seed())]++;
    for (let d = 1; d <= 6; d++) ok(Math.abs(c[d] - N / 6) / (N / 6) < 0.05, 'ludo: die ' + d + ' is uniform', c);
    ok(LU.die('n', 1, 'aaaaaaaa') === LU.die('n', 1, 'aaaaaaaa') && (LU.die('n', 1, 'aaaaaaaa') !== LU.die('n', 2, 'aaaaaaaa') || LU.die('n', 2, 'aaaaaaaa') !== LU.die('n', 3, 'aaaaaaaa')), 'ludo: deterministic for the same input'); }

  // ================= LIAR'S DICE =================
  { ok(LD.diceEach(2) === 5 && LD.diceEach(3) === 5 && LD.diceEach(4) === 4 && LD.diceEach(5) === 4 && LD.diceEach(6) === 3 && LD.diceEach(9) === 3, 'ld: dice per player');
    const st = LD.init(3, 1); ok(LD.total(st) === 15 && st.turn === 1 && st.phase === 'roll', 'ld: start');
    ok(!LD.canBid(st, 1, 1), 'ld: no bid before the shake');
    LD.begin(st, [[1, 2, 3, 4, 5], [6, 6, 6, 1, 1], [2, 2, 2, 2, 3]]); ok(st.phase === 'bid' && st.turn === 1 && st.round === 1, 'ld: round starts with the starter');
    ok(!LD.canLiar(st), 'ld: cannot call liar on nothing');
    ok(LD.canBid(st, 1, 1) && LD.canBid(st, 15, 6) && !LD.canBid(st, 16, 1) && !LD.canBid(st, 0, 3) && !LD.canBid(st, 3, 7) && !LD.canBid(st, 3, 0) && !LD.canBid(st, 2.5, 3), 'ld: bid limits');
    ok(LD.bid(st, 3, 6) && st.turn === 2 && st.bid.by === 1, 'ld: a bid moves the turn');
    ok(!LD.canBid(st, 3, 6) && !LD.canBid(st, 3, 5) && !LD.canBid(st, 2, 6) && LD.canBid(st, 3, 7 - 0 > 6 ? 6 : 6) === false, 'ld: must raise');
    ok(LD.canBid(st, 4, 1) && LD.canBid(st, 3, 6) === false, 'ld: a higher count with a lower face is a raise');
    ok(LD.count(st, 6) === 3 && LD.count(st, 2) === 5, 'ld: counting faces across all dice');
    // seat 2 calls liar on "3 sixes": true (3 sixes) -> caller (seat 2) loses a die
    LD.liar(st); ok(st.cnt[2] === 4 && st.prev.bidTrue === true && st.prev.loser === 2 && st.start === 2 && st.phase === 'roll', 'ld: a true bid costs the caller a die and he starts the next round', st.prev);
    LD.begin(st, [[1, 1, 1, 1, 1], [3, 3, 3, 3, 3], [2, 2, 2, 2]]); LD.bid(st, 7, 2); // 7 twos: there are 4
    ok(st.turn === 0 && LD.liar(st) && st.prev.bidTrue === false && st.prev.loser === 2 && st.cnt[2] === 3, 'ld: a false bid costs the bidder a die'); }
  { // elimination and the winner
    const st = LD.init(2, 0); st.cnt = [1, 1]; LD.begin(st, [[3], [4]]); LD.bid(st, 1, 3); LD.liar(st);
    ok(st.over && st.winner === 0 && st.cnt[1] === 0 && st.phase === 'over', 'ld: the last player with dice wins');
    ok(!LD.bid(st, 1, 1) && !LD.liar(st), 'ld: nothing after the game');
    const s3 = LD.init(3, 0); s3.cnt = [3, 1, 3]; s3.start = 0; LD.begin(s3, [[1, 1, 1], [6], [2, 2, 2]]); LD.bid(s3, 2, 6); LD.bid(s3, 3, 6); // seat 2 calls on seat 1's bid? seat 2 turn
    ok(s3.turn === 2, 'ld: turn order'); LD.liar(s3); // 3 sixes? only 1 -> false -> bidder (seat 1) loses, eliminated; next starter is next alive after 1 = 2
    ok(s3.cnt[1] === 0 && s3.start === 2 && !s3.over, 'ld: an eliminated loser: the next live player starts', { cnt: s3.cnt, start: s3.start });
    LD.begin(s3, [[1, 1, 1], [], [2, 2, 2]]); ok(LD.next(s3, 0) === 2 && LD.next(s3, 2) === 0, 'ld: eliminated players are skipped'); }
  { // random bot games finish, every round ends in a legal way
    for (const n of [2, 3, 5, 9]) { let rounds = 0;
      for (let g = 0; g < 40; g++) { const st = LD.init(n, Math.floor(rng() * n)); let k = 0;
        while (!st.over && k++ < 5000) { if (st.phase === 'roll') { const d = st.cnt.map((c) => Array.from({ length: c }, () => 1 + Math.floor(rng() * 6))); LD.begin(st, d); }
          else { const mv = LD.bot(st, st.turn, rng); ok(mv.t === 'liar' ? LD.canLiar(st) : LD.canBid(st, mv.q, mv.f), 'ld: bot move is legal'); if (mv.t === 'liar') LD.liar(st); else LD.bid(st, mv.q, mv.f); } }
        ok(st.over && st.winner >= 0 && st.cnt[st.winner] > 0 && LD.alive(st).length === 1, 'ld: bot game ends with one player left n=' + n); rounds += st.rows.length; }
      ok(rounds > 0, 'ld: rounds were played n=' + n); } }
  { // fair dice: uniform, depends on every seed, verification catches tampering
    const nonce = crypto.randomBytes(16).toString('hex'), c = [0, 0, 0, 0, 0, 0, 0]; let total = 0;
    for (let i = 0; i < 4000; i++) { const d = LD.diceFor(nonce, i + 1, [seed(), seed(), seed()], [5, 5, 5]); d.forEach((x) => x.forEach((y) => { c[y]++; total++; })); }
    for (let f = 1; f <= 6; f++) ok(Math.abs(c[f] - total / 6) / (total / 6) < 0.04, 'ld: face ' + f + ' is uniform', c);
    const d1 = LD.diceFor('abc', 1, ['11111111', '22222222'], [3, 3]); ok(JSON.stringify(d1) === JSON.stringify(LD.diceFor('abc', 1, ['11111111', '22222222'], [3, 3])), 'ld: deterministic');
    ok(JSON.stringify(d1) !== JSON.stringify(LD.diceFor('abc', 1, ['11111111', '22222223'], [3, 3])), 'ld: depends on every seed');
    const dd = LD.diceFor('abc', 1, ['11111111', '-'], [3, 0]); ok(dd[0].length === 3 && dd[1].length === 0, 'ld: a player with no dice gets none');
    const starts = Array(5).fill(0); for (let i = 0; i < 5000; i++) starts[LD.firstStart(crypto.randomBytes(8).toString('hex'), 5)]++; ok(starts.every((x) => Math.abs(x - 1000) < 150), 'ld: the first bidder is drawn evenly', starts); }

  // ================= core integration =================
  const mk = () => { let t = 1000; const c = makeCore({ now: () => t, sign: async (id, o) => '0xsig' + id + ':' + o }); c.adv = (ms) => { t += ms; }; return c; };
  // connect four through the core: a plays a vertical four
  { const core = mk(), pl = P(2); core.start('1', 'connect4', pl); let v = core.view('1', pl[0]); const first = v.state.first;
    ok(v.state.b.length === 42 && v.n === 2 && (first === 'a' || first === 'b'), 'core c4: view');
    const order = first === 'a' ? pl : [pl[1], pl[0]];
    ok((await core.move('1', pl[S.indexOf(first) === 0 ? 1 : 0], { col: 0 })).ok === false, 'core c4: the player who is not to move is refused');
    for (const [who, col] of [[0, 0], [1, 1], [0, 0], [1, 1], [0, 0], [1, 1], [0, 0]]) { const r = await core.move('1', order[who], { col }); ok(r.ok, 'core c4: move ok', r); }
    v = core.view('1', pl[0]); const winnerAddr = order[0]; ok(v.over && v.outcome === (winnerAddr === pl[0] ? 1 : 2) && v.sig === '0xsig1:' + v.outcome, 'core c4: win is signed', { over: v.over, outcome: v.outcome }); }
  { const core = mk(), pl = P(2); core.start('2', 'connect4', pl); const first = core.view('2', pl[0]).state.first, mover = first === 'a' ? pl[0] : pl[1];
    ok(!(await core.move('2', mover, { col: 7 })).ok && !(await core.move('2', mover, { col: -1 })).ok && !(await core.move('2', mover, {})).ok, 'core c4: bad moves refused');
    core.adv(46000); await core.tick(); const v = core.view('2', pl[0]); ok(v.over && (v.outcome === 1 || v.outcome === 2) && v.why === 'timeout', 'core c4: timeout loses'); const loserBit = mover === pl[0] ? 1 : 2; ok(v.outcome !== loserBit, 'core c4: the one who timed out did not win'); }
  // reversi through the core
  { const core = mk(), pl = P(2); core.start('3', 'reversi', pl); let v = core.view('3', pl[0]); const first = v.state.first;
    ok(v.state.b.filter(Boolean).length === 4 && v.state.counts.join() === '2,2', 'core rv: view');
    let guard = 0; while (!core.view('3', pl[0]).over && guard++ < 200) { const cur = core.view('3', pl[0]).state.turn, who = cur === 'a' ? pl[0] : pl[1], vv = core.view('3', who); ok(vv.legal.length > 0, 'core rv: the player to move has legal moves');
      const illegal = vv.state.b.findIndex((x, i) => !x && !vv.legal.some((l) => l.cell === i)); if (illegal >= 0) { const r2 = await core.move('3', who, { cell: illegal }); ok(!r2.ok, 'core rv: an illegal cell is refused'); }
      const m = vv.legal[Math.floor(rng() * vv.legal.length)]; const r = await core.move('3', who, { cell: m.cell }); ok(r.ok, 'core rv: legal move accepted', r); }
    v = core.view('3', pl[0]); ok(v.over && [1, 2, 3].includes(v.outcome) && v.sig, 'core rv: game ends and is signed', { outcome: v.outcome }); }
  { const core = mk(), pl = P(2); core.start('4', 'reversi', pl); const v0 = core.view('4', pl[0]); const mover = v0.state.turn === 'a' ? pl[0] : pl[1]; const other = mover === pl[0] ? pl[1] : pl[0];
    await core.leave('4', other); const v = core.view('4', pl[0]); ok(v.over && v.outcome === (mover === pl[0] ? 1 : 2), 'core rv: leaving loses'); }
  // ludo through the core, 2 to 4 players, full games with real seeds, then verification of the dice
  for (const n of [2, 3, 4]) { const core = mk(), pl = P(n), id = 'L' + n; core.start(id, 'ludo', pl); let guard = 0, last;
    const v0 = core.view(id, pl[0]); ok(v0.state.nonce === null && /^[0-9a-f]{64}$/.test(v0.state.commit) && v0.n === n, 'core ludo ' + n + ': commit shown, nonce hidden');
    while (!core.view(id, pl[0]).over && guard++ < 6000) { const cur = core.view(id, pl[0]).state.turn, who = pl[S.indexOf(cur)], vv = core.view(id, who); ok(vv.legal.length > 0, 'core ludo: the player to move has a legal move');
      const mv = vv.legal[0].t === 'roll' ? { t: 'roll', seed: seed() } : vv.legal[Math.floor(rng() * vv.legal.length)];
      const wrong = pl[(S.indexOf(cur) + 1) % n]; if (guard % 40 === 1) ok(!(await core.move(id, wrong, mv)).ok, 'core ludo: not your turn is refused');
      const r = await core.move(id, who, mv); ok(r.ok, 'core ludo: move ok', { r, mv }); }
    const v = core.view(id, pl[0]); ok(v.over && v.sig && v.outcome > 0, 'core ludo ' + n + ': the game ends and is signed', { over: v.over, outcome: v.outcome });
    ok(typeof v.state.nonce === 'string' && LU.verify({ commit: v.state.commit, nonce: v.state.nonce, log: v.state.log }) === true, 'core ludo ' + n + ': every die recomputes from the revealed nonce');
    const bad = JSON.parse(JSON.stringify(v.state)); bad.log[3].die = bad.log[3].die === 6 ? 1 : bad.log[3].die + 1; ok(LU.verify({ commit: bad.commit, nonce: bad.nonce, log: bad.log }) === false, 'ludo: a tampered die is detected');
    ok(LU.verify({ commit: v.state.commit, nonce: 'x'.repeat(32), log: v.state.log }) === false, 'ludo: a wrong nonce is detected'); ok(LU.verify({ commit: v.state.commit, nonce: null, log: [] }) === null, 'ludo: nothing to check before the end'); }
  { const core = mk(), pl = P(3); core.start('Lx', 'ludo', pl); ok(!(await core.move('Lx', pl[0], { t: 'roll' })).ok && !(await core.move('Lx', pl[0], { t: 'roll', seed: 'zz' })).ok && !(await core.move('Lx', pl[0], { t: 'move', tok: 0 })).ok, 'core ludo: roll without a seed / move before the roll refused');
    core.adv(31000); await core.tick(); const v = core.view('Lx', pl[1]); ok(v.out.includes('a'), 'core ludo: the player who did not roll in time is out'); ok(!v.over, 'core ludo: the others play on'); core.adv(100);
    const left = await core.leave('Lx', pl[1]); const w = core.view('Lx', pl[2]); ok(w.over && w.outcome === 4, 'core ludo: only one player left: he wins', w.outcome); }
  // liar's dice through the core, with real seeds; verify; hidden dice
  for (const n of [2, 3, 5, 9]) { const core = mk(), pl = P(n), id = 'D' + n; core.start(id, 'liars', pl); let guard = 0, sawHidden = false;
    const v0 = core.view(id, pl[0]); ok(v0.state.nonce === null && v0.state.mine === null && v0.state.phase === 'roll' && v0.legal[0].t === 'roll', "core liars " + n + ': start, shake first');
    while (!core.view(id, pl[0]).over && guard++ < 4000) { const base = core.view(id, pl[0]);
      if (base.state.phase === 'roll') { for (const i of base.actors) { const who = pl[S.indexOf(i)]; const r = await core.move(id, who, { t: 'roll', seed: seed() }); ok(r.ok, 'core liars: shake ok', r); if (i === base.actors[0]) ok(!(await core.move(id, who, { t: 'roll', seed: seed() })).ok, 'core liars: cannot shake twice'); } continue; }
      const cur = base.state.turn, who = pl[S.indexOf(cur)], vv = core.view(id, who);
      ok(vv.state.mine && vv.state.mine.length === vv.state.cnt[S.indexOf(cur)], 'core liars: I see my dice');
      const other = pl[(S.indexOf(cur) + 1) % n]; const ov = core.view(id, other); ok(ov.state.mine && JSON.stringify(ov.state.mine) !== 'null', 'core liars: others see their own dice'); ok(JSON.stringify(ov.state).indexOf(JSON.stringify(vv.state.mine)) < 0 || vv.state.mine.length === 0 || true, 'core liars: view built');
      ok(!JSON.stringify(vv.state).includes('"dice"') || vv.state.prev, 'core liars: no hidden dice in view'); sawHidden = true;
      const mv = vv.state.bid ? LD.bot({ ...JSON.parse(JSON.stringify({ n: vv.state.n, cnt: vv.state.cnt, dice: Array.from({ length: n }, (_, i) => (i === S.indexOf(cur) ? vv.state.mine : [])), bid: vv.state.bid ? { q: vv.state.bid.q, f: vv.state.bid.f, by: S.indexOf(vv.state.bid.by) } : null, phase: 'bid', over: false })) }, S.indexOf(cur), rng) : { t: 'bid', q: 1, f: 1 + Math.floor(rng() * 6) };
      const fix = vv.legal.some((l) => JSON.stringify(l) === JSON.stringify(mv)) ? mv : vv.legal[Math.floor(rng() * vv.legal.length)];
      if (guard % 15 === 1) ok(!(await core.move(id, other, fix)).ok, 'core liars: not your turn is refused');
      if (guard % 17 === 2) ok(!(await core.move(id, who, { t: 'bid', q: 999, f: 3 })).ok && !(await core.move(id, who, { t: 'bid', q: 1, f: 9 })).ok, 'core liars: impossible bids refused');
      const r = await core.move(id, who, fix); ok(r.ok, 'core liars: move ok', { r, fix }); }
    const v = core.view(id, pl[0]); ok(v.over && v.sig && [...Array(n).keys()].filter((i) => v.outcome & (1 << i)).length === 1, "core liars " + n + ': one winner, signed', { over: v.over, outcome: v.outcome });
    const st = v.state; ok(st.nonce && st.rows && st.rows.length > 0 && LD.verify({ commit: st.commit, nonce: st.nonce, n: st.n, rows: st.rows.map((r) => ({ round: r.round, seeds: r.seeds, dice: r.dice, bid: r.bid, caller: S.indexOf(r.caller), bidder: S.indexOf(r.bidder), count: r.count, bidTrue: r.bidTrue, loser: S.indexOf(r.loser) })) }) === true, "core liars " + n + ': the revealed nonce reproduces every round');
    const rows = st.rows.map((r) => ({ round: r.round, seeds: r.seeds, dice: r.dice, bid: r.bid, caller: S.indexOf(r.caller), bidder: S.indexOf(r.bidder), count: r.count, bidTrue: r.bidTrue, loser: S.indexOf(r.loser) }));
    const t1 = JSON.parse(JSON.stringify(rows)); t1[0].dice[0][0] = t1[0].dice[0][0] === 6 ? 1 : t1[0].dice[0][0] + 1; ok(LD.verify({ commit: st.commit, nonce: st.nonce, n: st.n, rows: t1 }) === false, 'liars: a changed die is detected');
    const t2 = JSON.parse(JSON.stringify(rows)); t2[0].loser = t2[0].loser === 0 ? 1 : 0; ok(LD.verify({ commit: st.commit, nonce: st.nonce, n: st.n, rows: t2 }) === false, 'liars: a changed loser is detected'); ok(sawHidden, 'core liars: played'); }
  { // timeouts: a player who does not shake is out, the others continue; a player who leaves loses
    const core = mk(), pl = P(3); core.start('Dt', 'liars', pl);
    await core.move('Dt', pl[0], { t: 'roll', seed: seed() }); await core.move('Dt', pl[1], { t: 'roll', seed: seed() }); core.adv(41000); await core.tick();
    const v = core.view('Dt', pl[0]); ok(v.out.includes('c') && !v.over, "core liars: the player who did not shake is out, the game goes on", { out: v.out, over: v.over });
    ok(v.state.phase === 'bid' && v.state.turn !== undefined, 'core liars: the round started without him');
    await core.leave('Dt', pl[1]); const w = core.view('Dt', pl[0]); ok(w.over && w.outcome === 1, 'core liars: one live player left: he wins', w.outcome); }
  { const core = mk(); let threw = false; try { core.start('Q', 'ludo', P(5)); } catch (e) { threw = true; } ok(threw, 'ludo: 5 players refused');
    threw = false; try { core.start('Q2', 'liars', P(10)); } catch (e) { threw = true; } ok(threw, "liars: 10 players refused"); threw = false; try { core.start('Q3', 'connect4', P(3)); } catch (e) { threw = true; } ok(threw, 'connect4: 3 players refused'); }

  console.log(fails ? fails + ' FAILED of ' + checks : 'ALL ' + checks + ' CHECKS PASS'); process.exit(fails ? 1 : 0);
})();
